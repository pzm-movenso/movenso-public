/**
 * GARDE DE COUVERTURE DES ACTIONS (D-430) — le jugement, pur, éprouvé dans
 * chacun de ses refus. La mesure (sonde du harnais e2e) est exercée par
 * `npm run verifier:couverture` lui-même ; ici, ce que la garde décide d'un
 * relevé donné.
 */
import { test } from "node:test";
import assert from "node:assert/strict";
import { juger, lireReleve } from "../outils/couverture-actions.mjs";

const releve = (methodes: string[], atteintes: string[]) => ({ methodes: new Set(methodes), atteintes: new Set(atteintes) });
const RAISON = "une raison assez longue pour passer le seuil";

test("vert : tout ce qui n'est pas atteint est déclaré avec sa raison", () => {
  assert.deepEqual(juger(releve(["a", "b", "c"], ["a", "b"]), { c: RAISON }), []);
});

test("une action jamais atteinte et NON déclarée est refusée, nommée", () => {
  const p = juger(releve(["a", "b"], ["a"]), {});
  assert.equal(p.length, 1);
  assert.match(p[0]!, /« b » n'est jamais atteinte/);
});

test("une action déclarée mais désormais atteinte est refusée : le cliquet se resserre", () => {
  const p = juger(releve(["a", "b"], ["a", "b"]), { b: RAISON });
  assert.equal(p.length, 1);
  assert.match(p[0]!, /« b » est désormais atteinte/);
});

test("une entrée orpheline (méthode retirée de la façade) est refusée", () => {
  const p = juger(releve(["a"], ["a"]), { disparue: RAISON });
  assert.equal(p.length, 1);
  assert.match(p[0]!, /« disparue » est déclarée mais n'existe plus/);
});

test("une raison trop courte ne vaut pas déclaration", () => {
  const p = juger(releve(["a", "b"], ["a"]), { b: "parce que" });
  assert.equal(p.length, 1);
  assert.match(p[0]!, /sans raison suffisante/);
});

test("un relevé VIDE est un refus : une sonde muette ne vaut pas « tout est atteint »", () => {
  const p = juger(releve([], []), {});
  assert.equal(p.length, 1);
  assert.match(p[0]!, /aucune méthode relevée/);
});

test("lireReleve : population et atteintes, doublons de pages fusionnés", () => {
  const r = lireReleve(['__METHODES__["a","b","c"]', "__APPEL__a", '__METHODES__["a","b","c"]', "__APPEL__a", "__APPEL__c", "bruit"].join("\n"));
  assert.deepEqual([...r.methodes].sort(), ["a", "b", "c"]);
  assert.deepEqual([...r.atteintes].sort(), ["a", "c"]);
});
