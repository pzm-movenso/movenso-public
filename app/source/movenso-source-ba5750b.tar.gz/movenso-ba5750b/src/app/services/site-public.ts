/**
 * ADRESSE DU SITE PUBLIC — un seul lieu (D-253).
 *
 * Sortie de `packs-officiels.ts` en D-363 : deux écrans lisent maintenant des
 * ressources du site (les packs officiels, et les vignettes de l'aide). Deux
 * copies de cette résolution auraient divergé au premier changement d'adresse.
 */

/** Racine du site public — servie par GitHub Pages sous le propriétaire du
 *  dépôt `movenso-public`, l'organisation `pzm-movenso` depuis le transfert.
 *  Pages ne redirige pas l'adresse de l'ancien propriétaire : l'APK ne joignait
 *  plus le catalogue (D-423). La CSP d'`index.html` ouvre cette origine et
 *  elle seule — `verifier:references` refuse tout écart entre les deux. */
const SITE_PUBLIC = "https://pzm-movenso.github.io/movenso-public/";

/** URL d'une ressource du site public. En WEB, relative à l'emplacement de
 *  l'app (`app/` sur le site → `../<chemin>`) — même origine, donc
 *  `connect-src 'self'` suffit, et l'e2e peut router. En NATIF (Capacitor),
 *  absolue vers `SITE_PUBLIC` : l'app y est servie depuis l'appareil, le
 *  relatif ne mènerait nulle part (D-219).
 *
 *  Conséquence à ne pas oublier, parce qu'elle a failli passer pour acquise :
 *  une ressource servie par le site demande le réseau **dans l'APK aussi**.
 *  « L'APK embarque tout » est vrai du code, pas de ce qui vit ici. */
export function urlSite(chemin: string): string {
  const capacitor = (window as { Capacitor?: { getPlatform?: () => string } }).Capacitor;
  const natif = (capacitor?.getPlatform?.() ?? "web") !== "web";
  return natif ? new URL(chemin, SITE_PUBLIC).toString() : new URL(`../${chemin}`, location.href).toString();
}
