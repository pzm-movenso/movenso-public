/** Types de `couverture-actions.mjs` — pour les tests TypeScript uniquement. */
export interface Releve { methodes: Set<string>; atteintes: Set<string> }
export declare const FICHIER_DETTE: string;
export declare function lireReleve(texte: string): Releve;
export declare function juger(releve: Releve, dette: Record<string, unknown>): string[];
