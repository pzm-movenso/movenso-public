/**
 * COUVERTURE DES ACTIONS par l'e2e (D-430) — un cliquet sur ce que le parcours
 * n'exerce JAMAIS.
 *
 *   node outils/couverture-actions.mjs --verifier   joue l'e2e en mesurant, puis juge
 *   node outils/couverture-actions.mjs --mesurer    joue l'e2e, imprime le constat
 *
 * L'INCIDENT. L'audit du 2026-10-16 a mesuré, en instrumentant à la main une
 * copie jetable, que 22 des 133 actions de la façade `MovensoApp` n'étaient
 * jamais atteintes par l'e2e — et que 4 d'entre elles étaient du code MORT que
 * rien ne signalait (`knip` ne voit pas les méthodes de classe). La mesure
 * existait une fois, sur un poste ; rien ne la rejouait.
 *
 * LA MESURE. Le harnais (`tests-navigateur/harnais.mjs`) enveloppe chaque
 * méthode de la façade au moment où l'élément est déclaré, si
 * `MOVENSO_COUVERTURE` nomme un fichier. La population est lue AU MÊME
 * ENDROIT, à l'exécution (les méthodes réellement présentes sur le prototype) :
 * la garde déclare donc sa couverture — population et atteintes — et ne peut
 * pas sous-compter en silence (D-417).
 *
 * LE JUGEMENT, une fonction pure (`juger`) :
 *  - une action jamais atteinte et NON déclarée dans `couverture-actions.json`
 *    est refusée : écrire son épreuve, la retirer si elle est morte, ou la
 *    déclarer avec sa RAISON (seuil `raison-minimale.mjs`) ;
 *  - une action déclarée mais désormais atteinte est refusée aussi : le
 *    cliquet se resserre, la dette ne se reconstitue pas en silence ;
 *  - une action déclarée qui n'existe plus sur la façade est refusée : une
 *    entrée orpheline est une dette mal tenue.
 *
 * Ce que la garde ne dit PAS : qu'une action atteinte est VÉRIFIÉE. Atteindre
 * une méthode prouve que le parcours l'exécute, pas qu'une assertion tient son
 * effet. C'est une borne basse honnête, pas une preuve de comportement.
 */
import { execFileSync } from "node:child_process";
import { readFileSync, rmSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { tmpdir } from "node:os";
import { fileURLToPath } from "node:url";
import { RAISON_MINIMALE } from "./raison-minimale.mjs";

const RACINE = join(dirname(fileURLToPath(import.meta.url)), "..");
export const FICHIER_DETTE = "outils/couverture-actions.json";

/** Lit le relevé brut du harnais : la population et les actions atteintes. */
export function lireReleve(texte) {
  const methodes = new Set();
  const atteintes = new Set();
  for (const ligne of texte.split("\n")) {
    if (ligne.startsWith("__METHODES__")) for (const n of JSON.parse(ligne.slice(12))) methodes.add(n);
    else if (ligne.startsWith("__APPEL__")) atteintes.add(ligne.slice(9).trim());
  }
  return { methodes, atteintes };
}

/** Le jugement, pur : relevé + dette déclarée → problèmes (vide = vert). */
export function juger({ methodes, atteintes }, dette) {
  const problemes = [];
  if (methodes.size === 0) return ["aucune méthode relevée : la sonde du harnais n'a rien vu (MOVENSO_COUVERTURE ignoré ?)"];
  const jamais = [...methodes].filter((n) => !atteintes.has(n)).sort();
  for (const n of jamais) {
    if (!(n in dette)) problemes.push(`« ${n} » n'est jamais atteinte par l'e2e — écrire son épreuve, la retirer si elle est morte, ou la déclarer avec sa raison dans ${FICHIER_DETTE}`);
    else if (typeof dette[n] !== "string" || dette[n].trim().length < RAISON_MINIMALE) problemes.push(`« ${n} » est déclarée sans raison suffisante (≥ ${RAISON_MINIMALE} caractères)`);
  }
  for (const n of Object.keys(dette).sort()) {
    if (!methodes.has(n)) problemes.push(`« ${n} » est déclarée mais n'existe plus sur la façade — retirer l'entrée`);
    else if (atteintes.has(n)) problemes.push(`« ${n} » est désormais atteinte — retirer l'entrée de ${FICHIER_DETTE} (le cliquet se resserre)`);
  }
  return problemes;
}

function jouerE2e() {
  const releve = join(tmpdir(), `couverture-actions-${process.pid}.txt`);
  rmSync(releve, { force: true });
  execFileSync("node", ["tests-navigateur/parcours.mjs"], { cwd: RACINE, stdio: "inherit", env: { ...process.env, MOVENSO_COUVERTURE: releve } });
  const texte = existsSync(releve) ? readFileSync(releve, "utf8") : "";
  rmSync(releve, { force: true });
  return lireReleve(texte);
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const mode = process.argv.includes("--verifier") ? "verifier" : process.argv.includes("--mesurer") ? "mesurer" : null;
  if (!mode) {
    console.error("usage : node outils/couverture-actions.mjs --verifier | --mesurer");
    process.exit(2);
  }
  const releve = jouerE2e();
  const dette = JSON.parse(readFileSync(join(RACINE, FICHIER_DETTE), "utf8")).jamais_atteintes ?? {};
  const jamais = [...releve.methodes].filter((n) => !releve.atteintes.has(n)).sort();
  const bilan = `${releve.methodes.size} actions sur la façade, ${releve.methodes.size - jamais.length} atteintes par l'e2e, ${jamais.length} jamais (dette déclarée : ${Object.keys(dette).length})`;
  if (mode === "mesurer") {
    console.log(`couverture-actions : ${bilan}`);
    for (const n of jamais) console.log(`  · ${n}${n in dette ? "" : "  ← non déclarée"}`);
    process.exit(0);
  }
  const problemes = juger(releve, dette);
  if (problemes.length) {
    console.error(`verifier:couverture : ${bilan}\n`);
    for (const p of problemes) console.error(`  ✕ ${p}`);
    process.exit(1);
  }
  console.log(`verifier:couverture : ${bilan} — chacune déclarée avec sa raison (D-430).`);
}
