/**
 * CHAPITRE e2e (D-427) — les RÉGLAGES d'Apparence survivent au redémarrage,
 * et l'écran de démarrage choisi est celui qui s'ouvre (workflow L).
 *
 * `workflows.md` donnait le réglage de démarrage pour « manuel » ; thème,
 * tonalité et pseudo n'avaient aucun parcours. Chaque réglage est posé par
 * son bouton, puis l'app redémarre — une fois le fichier de préférences
 * réellement écrit — et l'effet est relu À L'ÉCRAN (attribut du document,
 * couleur d'accent, champ, écran ouvert), pas seulement dans l'état.
 */
import assert from "node:assert/strict";
import { surveiller, navigateur, rendu, finit } from "../harnais.mjs";

export async function run() {
  const ctx = await navigateur.newContext({ viewport: { width: 420, height: 900 } });
  const p = await ctx.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");
  const [sel] = await Promise.all([p.waitForEvent("filechooser"), p.locator(".action-douce", { hasText: "Importer" }).first().click()]);
  await sel.setFiles(new URL("../../donnees/kodokan.json", import.meta.url).pathname);
  await p.locator(".feuille .actions .bouton.principal").click();
  await p.locator(".feuille[aria-label=\"Rapport d'import\"] .actions .bouton.principal").click();
  await rendu(p);

  const apparence = async () => { await p.evaluate(() => document.querySelector("movenso-app").ouvrirPlusSection("apparence")); await rendu(p); };
  // Redémarrer quand le fichier de préférences porte ce que l'app croit avoir écrit.
  const redemarrer = async () => {
    await finit(async () => assert.ok(await p.evaluate(async () => {
      const racine = await navigator.storage.getDirectory();
      const disque = JSON.parse(await (await (await racine.getFileHandle("preferences.json")).getFile()).text());
      const cle = (x) => JSON.stringify([x.theme, x.tonalite, x.pseudo, x.demarrage]);
      return cle(disque) === cle(document.querySelector("movenso-app").preferences);
    }), "le fichier de préférences rattrape l'état"));
    await p.reload();
    await p.waitForFunction(() => document.querySelector("movenso-app")?.bibliotheque);
    await rendu(p);
  };
  const accent = () => p.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue("--accent").trim());

  await apparence();
  const accentDefaut = await accent();
  await p.fill('input[aria-label="Ton pseudo"]', "Pratiquant du chapitre");
  await p.locator('input[aria-label="Ton pseudo"]').blur();
  const discipline = await p.evaluate(() => document.querySelector("movenso-app").bibliotheque.disciplines[0]);
  await p.locator(".chips-filtres .chip-filtre", { hasText: new RegExp(`^${discipline.nom}$`) }).click();
  // Thème et tonalité EN DERNIER : chaque réglage réécrit tout le fichier de
  // préférences, donc un réglage posé avant serait sauvé par celui d'après —
  // et l'épingle passerait même si le thème ne s'enregistrait plus (mesuré).
  await p.locator(".chip-filtre", { hasText: "Nuit" }).click();
  const tonalites = p.locator(".carte-atelier", { hasText: "Tonalité" }).locator(".chip-filtre");
  await tonalites.nth(1).click();
  await rendu(p);
  const tonalite = await p.evaluate(() => document.documentElement.dataset.tonalite);
  assert.ok(tonalite, "préambule : une tonalité non par défaut est posée");

  await redemarrer();
  assert.equal(await p.evaluate(() => document.documentElement.dataset.theme), "sombre", "le thème Nuit survit au redémarrage");
  assert.equal(await p.evaluate(() => document.documentElement.dataset.tonalite), tonalite, "la tonalité survit au redémarrage");
  assert.notEqual(await accent(), accentDefaut, "la couleur d'accent RENDUE est celle de la tonalité choisie");
  assert.equal(await p.evaluate(() => document.querySelector("movenso-app").ecran.type), "discipline", "l'app redémarre sur la discipline choisie (workflow L)");
  await apparence();
  assert.equal(await p.locator('input[aria-label="Ton pseudo"]').inputValue(), "Pratiquant du chapitre", "le pseudo survit au redémarrage");

  // Retour aux défauts : Auto efface l'attribut, l'accent d'origine revient.
  await p.locator(".chip-filtre", { hasText: "Auto" }).click();
  await tonalites.nth(0).click();
  await p.locator(".chip-filtre", { hasText: "Toutes" }).click();
  await rendu(p);
  assert.equal(await p.evaluate(() => document.documentElement.dataset.theme), undefined, "Auto rend la main au système");
  await finit(async () => assert.equal(await accent(), accentDefaut, "la tonalité par défaut revient"));
  await redemarrer();
  assert.equal(await p.evaluate(() => document.querySelector("movenso-app").ecran.type), "bibliotheques", "« Toutes » rouvre la Bibliothèque");
  await ctx.close();
}
