/**
 * CHAPITRE e2e (D-427) — la CORBEILLE de bout en bout (workflow E, retrait).
 *
 * `workflows.md` donnait le retrait d'une technique pour « manuel » ; les
 * écritures de la corbeille ont des tests UNITAIRES (D-416, en panne), mais
 * aucun parcours ne les jouait par l'interface. Ce chapitre tient le cycle :
 * retirer (confirmation) → restaurer (survit au redémarrage) → supprimer
 * définitivement (aucun lien ne pointe dans le vide) → vider la corbeille.
 */
import assert from "node:assert/strict";
import { surveiller, navigateur, rendu, finit } from "../harnais.mjs";

export async function run() {
  const ctx = await navigateur.newContext({ viewport: { width: 420, height: 900 } });
  const p = await ctx.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");
  const [sel] = await Promise.all([p.waitForEvent("filechooser"), p.locator(".action-douce", { hasText: "Importer" }).first().click()]);
  await sel.setFiles(new URL("../../donnees/kodokan.json", import.meta.url).pathname);
  await p.locator(".feuille .actions .bouton.principal").click();
  await p.locator(".feuille[aria-label=\"Rapport d'import\"] .actions .bouton.principal").click();
  await rendu(p);

  const etat = () => p.evaluate(() => {
    const b = document.querySelector("movenso-app").bibliotheque;
    const ids = new Set(b.techniques.map((t) => t.id));
    return {
      ids: b.techniques.map((t) => t.id),
      corbeille: (b.corbeille ?? []).map((e) => e.technique.id),
      pendants: b.techniques.flatMap((t) => t.relations).filter((r) => !ids.has(r.cibleId)).length,
    };
  });
  const section = async (s) => { await p.evaluate((x) => document.querySelector("movenso-app").ouvrirPlusSection(x), s); await rendu(p); };
  // Redémarrer seulement quand le DISQUE dit l'état en mémoire : l'écriture
  // suit la mutation (persister est asynchrone), et un rechargement dans la
  // même milliseconde mesurerait la course du test, pas le produit.
  const recharger = async () => {
    await finit(async () => assert.ok(await p.evaluate(async () => {
      const memoire = document.querySelector("movenso-app").bibliotheque;
      const racine = await navigator.storage.getDirectory();
      const disque = JSON.parse(await (await (await racine.getFileHandle("bibliotheque.json")).getFile()).text());
      const cle = (b) => JSON.stringify([b.techniques.map((t) => t.id).sort(), (b.corbeille ?? []).map((e) => e.technique.id).sort()]);
      return cle(memoire) === cle(disque);
    }), "le disque rattrape la mémoire"));
    await p.reload(); await p.waitForFunction(() => document.querySelector("movenso-app")?.bibliotheque); await rendu(p);
  };
  const confirmer = async () => { await p.waitForSelector(".feuille-confirmation"); await p.locator(".feuille-confirmation .bouton.principal").click(); await rendu(p); };
  const retirerPremiere = async () => { await section("techniques"); await p.locator(".supprimer-technique").first().click(); await confirmer(); };
  const total = (await etat()).ids.length;

  // Retirer : confirmation, puis la fiche quitte la bibliothèque pour la corbeille.
  await retirerPremiere();
  const jetee = (await etat()).corbeille[0];
  assert.ok(jetee, "la fiche retirée est en corbeille");
  assert.ok(!(await etat()).ids.includes(jetee), "la fiche retirée n'est plus dans la bibliothèque");

  // Restaurer : à l'identique, et l'état survit au redémarrage.
  await section("corbeille");
  await p.locator(".chip-filtre", { hasText: "Restaurer" }).first().click();
  await finit(async () => assert.equal((await etat()).corbeille.length, 0, "la corbeille se vide à la restauration"));
  await recharger();
  assert.ok((await etat()).ids.includes(jetee), "la fiche restaurée survit au redémarrage");
  assert.equal((await etat()).ids.length, total, "rien n'a été perdu");

  // Supprimer définitivement : la fiche disparaît, aucun lien ne pointe dans le vide.
  await retirerPremiere();
  await section("corbeille");
  await p.locator('button[aria-label^="Supprimer définitivement"]').first().click();
  await confirmer();
  await finit(async () => assert.equal((await etat()).corbeille.length, 0, "la fiche détruite quitte la corbeille"));
  await recharger();
  assert.equal((await etat()).ids.length, total - 1, "la destruction persiste");
  assert.equal((await etat()).pendants, 0, "aucun lien ne pointe vers la fiche détruite");

  // Vider : deux fiches d'un geste, après confirmation.
  await retirerPremiere();
  await retirerPremiere();
  assert.equal((await etat()).corbeille.length, 2, "préambule : deux fiches en corbeille");
  await section("corbeille");
  await p.locator(".chip-filtre.danger", { hasText: "Vider la corbeille" }).click();
  await confirmer();
  await finit(async () => assert.equal((await etat()).corbeille.length, 0, "la corbeille est vidée"));
  await recharger();
  assert.equal((await etat()).corbeille.length, 0, "le vidage persiste");
  assert.equal((await etat()).ids.length, total - 3, "les deux fiches vidées sont détruites");
  assert.equal((await etat()).pendants, 0, "aucun lien pendant après le vidage");
  await ctx.close();
}
