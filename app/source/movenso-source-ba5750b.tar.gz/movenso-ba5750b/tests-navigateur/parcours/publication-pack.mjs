/**
 * CHAPITRE e2e (D-427) — PUBLIER un pack (workflow H), jusqu'au destinataire.
 *
 * `workflows.md` donnait ce parcours pour « test unitaire + manuel, pas de
 * e2e » : l'audit du 2026-10-16 l'a joué à la main, ce chapitre le fige.
 * Trois garanties, sur le chemin réel (Plus › Créer / exporter un pack) :
 *   1. le fichier produit est un `.movpack` lisible et complet ;
 *   2. le carnet PERSONNEL ne part jamais (D-127) ;
 *   3. il s'installe chez un destinataire vierge, par le circuit d'import.
 * Le voisin : « Partager » sans partage natif retombe sur un téléchargement.
 */
import assert from "node:assert/strict";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { surveiller, navigateur, rendu, finit } from "../harnais.mjs";

const NOTE = "NOTE-PRIVEE-PUBLICATION";

async function ouvrir() {
  const ctx = await navigateur.newContext({ viewport: { width: 420, height: 900 }, acceptDownloads: true });
  const p = await ctx.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");
  return p;
}

/** Import par le circuit réel (état vide) : proposition → installer → rapport. */
async function importer(p, chemin) {
  const [sel] = await Promise.all([p.waitForEvent("filechooser"), p.locator(".action-douce", { hasText: "Importer" }).first().click()]);
  await sel.setFiles(chemin);
  // Une proposition d'import, ou un refus DIT (toast) — jamais une attente muette.
  await p.waitForSelector('.feuille .actions .bouton.principal, .toast:has-text("Import impossible")');
  if (!(await p.locator(".feuille .actions .bouton.principal").count()))
    assert.fail(`le fichier est refusé à l'import : « ${await p.locator(".toast").last().innerText()} »`);
  await p.locator(".feuille .actions .bouton.principal").click();
  const rapport = p.locator(".feuille[aria-label=\"Rapport d'import\"]");
  await rapport.waitFor();
  await rapport.locator(".actions .bouton.principal").click();
  await rendu(p);
}

export async function run() {
  const p = await ouvrir();
  await importer(p, new URL("../../donnees/kodokan.json", import.meta.url).pathname);
  const publiees = await p.evaluate(async (note) => {
    const a = document.querySelector("movenso-app");
    await a.ajouterNote(a.bibliotheque.techniques[0].id, note);
    a.ouvrirPlusSection("publier");
    return a.bibliotheque.techniques.length;
  }, NOTE);
  await rendu(p);

  // 1. Préparer puis enregistrer : un vrai téléchargement .movpack.
  await p.fill('input[aria-label="Auteur du pack"]', "Chapitre publication");
  await p.locator(".bouton.principal", { hasText: "Valider" }).click();
  const enregistrer = p.locator(".bouton.principal", { hasText: "Enregistrer localement" });
  await enregistrer.waitFor();
  const [telechargement] = await Promise.all([p.waitForEvent("download"), enregistrer.click()]);
  assert.match(telechargement.suggestedFilename(), /\.movpack$/, "le pack publié est un .movpack");
  const fichier = join(tmpdir(), `publication-${Date.now()}.movpack`);
  await telechargement.saveAs(fichier);

  // Voisin : « Partager » sans partage natif → téléchargement, et le message le dit.
  await p.locator(".bouton.principal", { hasText: "Valider" }).click();
  await enregistrer.waitFor();
  const [partage] = await Promise.all([p.waitForEvent("download"), p.locator(".bouton", { hasText: "Partager" }).last().click()]);
  assert.match(partage.suggestedFilename(), /\.movpack$/, "sans partage natif, « Partager » télécharge le pack");
  await finit(async () => assert.match(await p.locator(".toast").last().innerText(), /téléchargements/, "le repli dit où trouver le fichier"));
  await p.locator(".action-douce", { hasText: "Préparer un autre pack" }).click();
  await p.locator(".bouton.principal", { hasText: "Valider" }).waitFor();

  // 2 + 3. Chez un destinataire vierge : tout arrive, rien de personnel.
  const q = await ouvrir();
  await importer(q, fichier);
  const recu = await q.evaluate((note) => {
    const b = document.querySelector("movenso-app").bibliotheque;
    return { techniques: b.techniques.length, note: JSON.stringify(b).includes(note) };
  }, NOTE);
  assert.equal(recu.techniques, publiees, "le destinataire reçoit toutes les techniques publiées");
  assert.equal(recu.note, false, "le carnet personnel ne part jamais dans un pack publié (D-127)");
  await p.context().close();
  await q.context().close();
}
