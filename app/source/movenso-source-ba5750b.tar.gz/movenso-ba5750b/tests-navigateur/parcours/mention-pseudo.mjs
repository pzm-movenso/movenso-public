/**
 * CHAPITRE e2e (D-428) — la mention du pseudo se LIT comme une mention.
 *
 * Constat D2 de l'audit du 2026-10-16 : `.mention-pseudo` (D-420) n'avait
 * aucune règle de style — elle tombait à la taille par défaut du navigateur
 * (16 px, gras), deux crans au-dessus des aides qui l'entourent, et dans
 * « À propos » sa fin passait SOUS l'illustration de la carte. Mesuré en
 * géométrie et en style RENDUS, sur les deux écrans qui la montrent.
 */
import assert from "node:assert/strict";
import { surveiller, navigateur, rendu } from "../harnais.mjs";

export async function run() {
  const ctx = await navigateur.newContext({ viewport: { width: 412, height: 900 } });
  const p = await ctx.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");
  await p.evaluate(async () => { const a = document.querySelector("movenso-app"); await a.creerDiscipline("Judo"); });
  const taille = () => p.locator(".mention-pseudo").first().evaluate((e) => parseFloat(getComputedStyle(e).fontSize));

  for (const section of ["apparence", "apropos"]) {
    await p.evaluate((s) => document.querySelector("movenso-app").ouvrirPlusSection(s), section);
    await rendu(p);
    assert.ok((await taille()) <= 13.5, `la mention a la taille d'une aide, pas d'un titre (${section} : ${await taille()} px)`);
  }
  // À propos : le texte ne passe pas sous l'illustration de sa carte.
  const recouvrement = await p.locator(".apropos-majeure", { has: p.locator(".mention-pseudo") }).evaluate((carte) => {
    const t = carte.querySelector(".mention-pseudo").getBoundingClientRect();
    const i = carte.querySelector(".apropos-majeure-art").getBoundingClientRect();
    const l = Math.max(0, Math.min(t.right, i.right) - Math.max(t.left, i.left));
    const h = Math.max(0, Math.min(t.bottom, i.bottom) - Math.max(t.top, i.top));
    return l * h;
  });
  assert.equal(recouvrement, 0, `la mention ne passe pas sous l'illustration (${Math.round(recouvrement)} px² recouverts)`);
  await ctx.close();
}
