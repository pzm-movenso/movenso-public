/**
 * CHAPITRE e2e (D-430) — deux gestes de curation que l'e2e n'exerçait pas :
 * la VIGNETTE d'une fiche tirée d'une vidéo en ligne (puis retirée), et la
 * NATURE de lecture d'un type de lien (orienté ⇄ symétrique).
 *
 * Mesurés par la garde de couverture des actions (D-430) : « jamais atteints ».
 * Le voisin qui compte pour les types de lien : un type DÉJÀ utilisé refuse de
 * changer de nature, et le dit — sinon les relations existantes se liraient
 * à l'envers.
 */
import assert from "node:assert/strict";
import { surveiller, navigateur, rendu, finit } from "../harnais.mjs";

export async function run() {
  const ctx = await navigateur.newContext({ viewport: { width: 420, height: 900 } });
  const p = await ctx.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");
  const [sel] = await Promise.all([p.waitForEvent("filechooser"), p.locator(".action-douce", { hasText: "Importer" }).first().click()]);
  await sel.setFiles(new URL("../../donnees/kodokan.json", import.meta.url).pathname);
  await p.locator(".feuille .actions .bouton.principal").click();
  await p.locator(".feuille[aria-label=\"Rapport d'import\"] .actions .bouton.principal").click();
  await rendu(p);

  // Vignette : la miniature d'une vidéo en ligne, posée puis retirée en édition.
  const id = await p.evaluate(() => {
    const a = document.querySelector("movenso-app");
    const c = a.bibliotheque.contributions.find((x) => x.medias.some((m) => m.type === "plateforme" && m.service === "youtube"));
    a.ouvrirFiche(c.techniqueId);
    a.entrerEditionFiche(c.techniqueId);
    return c.techniqueId;
  });
  await rendu(p);
  const couverture = () => p.evaluate((t) => document.querySelector("movenso-app").bibliotheque.techniques.find((x) => x.id === t).couverture ?? null, id);
  await p.locator(".couverture-edition .chip-filtre", { hasText: "Miniature" }).first().click();
  await finit(async () => assert.equal((await couverture())?.type, "media", "la miniature de la vidéo devient la vignette de la fiche"));
  await p.locator(".couverture-edition .chip-filtre.danger", { hasText: "Retirer la vignette" }).click();
  await finit(async () => assert.equal(await couverture(), null, "« Retirer la vignette » la retire"));
  await p.evaluate(() => document.querySelector("movenso-app").validerEditionFiche());
  await rendu(p);

  // Types de lien : un type utilisé refuse de changer de nature, et le dit.
  await p.evaluate(() => document.querySelector("movenso-app").ouvrirPlusSection("relations"));
  await rendu(p);
  const utilise = await p.evaluate(() => { const a = document.querySelector("movenso-app"); return a.bibliotheque.typesRelation.find((t) => !t.symetrique && a.usagesTypeRelation(t.id) > 0); });
  const blocUtilise = p.locator(".type-relation-bloc", { hasText: utilise.libelle }).first();
  await blocUtilise.locator('button[aria-label="Modifier ce lien"]').click();
  await rendu(p);
  await p.locator(".edition-type-relation .chip-filtre", { hasText: /Rendre/ }).click();
  await finit(async () => assert.match(await p.locator(".toast").last().innerText(), /ne peut plus changer/, "un type déjà utilisé refuse, et le dit"));
  assert.ok(!(await p.evaluate((i) => document.querySelector("movenso-app").bibliotheque.typesRelation.find((t) => t.id === i).symetrique, utilise.id)), "sa nature n'a pas changé");

  // … un type neuf, lui, devient symétrique.
  await p.evaluate(() => document.querySelector("movenso-app").ouvrirPlusSection("relations"));
  await rendu(p);
  await p.fill('input[placeholder^="Nouveau lien"]', "Variante de");
  await p.fill('input[placeholder^="Lecture inverse"]', "A pour variante");
  await p.locator(".bouton", { hasText: "Ajouter" }).last().click();
  await rendu(p);
  const neuf = await p.evaluate(() => document.querySelector("movenso-app").bibliotheque.typesRelation.find((t) => t.libelle === "Variante de")?.id);
  assert.ok(neuf, "préambule : le type neuf existe");
  await p.locator(".type-relation-bloc", { hasText: "Variante de" }).locator('button[aria-label="Modifier ce lien"]').click();
  await rendu(p);
  await p.locator(".edition-type-relation .chip-filtre", { hasText: "Rendre symétrique" }).click();
  await finit(async () => assert.equal(await p.evaluate((i) => document.querySelector("movenso-app").bibliotheque.typesRelation.find((t) => t.id === i).symetrique, neuf), true, "un type neuf devient symétrique"));
  await ctx.close();
}
