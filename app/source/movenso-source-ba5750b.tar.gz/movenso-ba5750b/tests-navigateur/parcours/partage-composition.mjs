/**
 * CHAPITRE e2e (D-427) — PARTAGER une composition (workflow I′), et la
 * rejouer chez quelqu'un qui n'a PAS le pack d'origine.
 *
 * `workflows.md` donnait l'export pour « manuel » : l'audit du 2026-10-16 l'a
 * joué à la main, ce chapitre le fige. La promesse tenue est celle de D-127 :
 * le fichier embarque les techniques que la composition enchaîne et leurs
 * disciplines, donc chez un destinataire VIERGE chaque bloc pointe une
 * technique qui existe — la composition est jouable, pas une coquille.
 */
import assert from "node:assert/strict";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { surveiller, navigateur, rendu, finit } from "../harnais.mjs";

async function ouvrir() {
  const ctx = await navigateur.newContext({ viewport: { width: 420, height: 900 }, acceptDownloads: true });
  const p = await ctx.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");
  return p;
}

async function importer(p, chemin) {
  const [sel] = await Promise.all([p.waitForEvent("filechooser"), p.locator(".action-douce", { hasText: "Importer" }).first().click()]);
  await sel.setFiles(chemin);
  // Une proposition d'import, ou un refus DIT (toast) — jamais une attente muette.
  await p.waitForSelector('.feuille .actions .bouton.principal, .toast:has-text("Import impossible")');
  if (!(await p.locator(".feuille .actions .bouton.principal").count()))
    assert.fail(`le fichier est refusé à l'import : « ${await p.locator(".toast").last().innerText()} »`);
  await p.locator(".feuille .actions .bouton.principal").click();
  const rapport = p.locator(".feuille[aria-label=\"Rapport d'import\"]");
  await rapport.waitFor();
  await rapport.locator(".actions .bouton.principal").click();
  await rendu(p);
}

export async function run() {
  const p = await ouvrir();
  await p.evaluate(() => document.querySelector("movenso-app").basculerReglage("compositionsBeta"));
  await importer(p, new URL("../../donnees/kodokan.json", import.meta.url).pathname);
  // Une composition de trois pas, construite par l'éditeur comme le ferait l'utilisateur.
  const { id, noms } = await p.evaluate(async () => {
    const a = document.querySelector("movenso-app");
    await a.creerComposition("Enchaînement partagé");
    const c = a.bibliotheque.compositions.find((x) => x.nom === "Enchaînement partagé");
    return { id: c.id, noms: a.bibliotheque.techniques.slice(0, 3).map((t) => t.nom) };
  });
  await p.evaluate((cid) => document.querySelector("movenso-app").ouvrirComposition(cid), id);
  await p.waitForSelector(".fiche-compo-tete");
  // Une composition neuve s'ouvre déjà en édition ; sinon on y entre.
  if (!(await p.locator(".ajouter-pas-inline").count())) await p.locator(".basculer-edition").click();
  await p.locator(".ajouter-pas-inline").waitFor();
  const feuille = p.locator('.feuille[aria-label="Ajouter un élément"]');
  for (const nom of noms) {
    await p.locator(".ajouter-pas-inline").click();
    await feuille.waitFor();
    await feuille.locator(".chip-choix", { hasText: "Une technique" }).click();
    await feuille.locator(".recherche input").fill(nom);
    await rendu(p);
    await feuille.locator(".resultat", { hasText: nom }).first().click();
    await rendu(p);
    await feuille.locator(".ajout-valider", { hasText: "Ajouter" }).click();
    await rendu(p);
    await feuille.locator(".actions .bouton", { hasText: "Terminer" }).click();
    await rendu(p);
  }
  const blocs = await p.evaluate((cid) => document.querySelector("movenso-app").bibliotheque.compositions.find((c) => c.id === cid).blocs.length, id);
  assert.equal(blocs, 3, "préambule : la composition enchaîne trois techniques");
  await p.locator(".compo-terminer").click(); // sortir de l'édition : « Partager » vit en lecture
  await rendu(p);
  const [telechargement] = await Promise.all([p.waitForEvent("download"), p.locator(".partager-composition").click()]);
  const fichier = join(tmpdir(), `composition-${Date.now()}.movpack`);
  await telechargement.saveAs(fichier);

  const q = await ouvrir();
  await importer(q, fichier);
  const recu = await q.evaluate(() => {
    const b = document.querySelector("movenso-app").bibliotheque;
    const c = b.compositions.find((x) => x.nom === "Enchaînement partagé");
    const ids = new Set(b.techniques.map((t) => t.id));
    return c ? { blocs: c.blocs.length, resolus: c.blocs.filter((x) => x.techniqueId && ids.has(x.techniqueId)).length, disciplines: b.disciplines.length } : null;
  });
  assert.ok(recu, "la composition arrive chez le destinataire");
  assert.equal(recu.blocs, 3, "les trois pas arrivent");
  assert.equal(recu.resolus, 3, "chaque pas pointe une technique présente : la composition est jouable (D-127)");
  assert.ok(recu.disciplines >= 1, "la discipline des techniques voyage avec elles");

  // D-428 (constat D3) : une composition SANS technique ne produit pas un
  // fichier que tout import refuserait — le refus vient au partage, et il est dit.
  const vide = await p.evaluate(async () => {
    const a = document.querySelector("movenso-app");
    await a.creerComposition("Rien encore");
    const c = a.bibliotheque.compositions.find((x) => x.nom === "Rien encore");
    a.ouvrirComposition(c.id);
    return c.id;
  });
  await p.waitForSelector(".fiche-compo-tete");
  if (await p.locator(".compo-terminer").count()) await p.locator(".compo-terminer").click();
  await rendu(p);
  let telechargementVide = false;
  p.on("download", () => (telechargementVide = true));
  await p.locator(".partager-composition").click();
  await finit(async () => assert.match(await p.locator(".toast").last().innerText(), /au moins une technique/, "le partage d'une composition vide est refusé, et le refus est dit"));
  await p.waitForTimeout(300);
  assert.equal(telechargementVide, false, "aucun fichier inimportable n'est produit");
  assert.ok(vide, "préambule");
  await p.context().close();
  await q.context().close();
}
