/**
 * CHAPITRE e2e (D-428) — annuler une demande de PIN laisse l'ÉCRAN dire la
 * donnée, pas la saisie refusée.
 *
 * Constat D1 de l'audit du 2026-10-16 : sous protection, renommer une
 * discipline puis annuler la demande de PIN gardait bien la donnée intacte…
 * mais le champ continuait d'afficher la saisie annulée (« Judo X »).
 * L'écran contredisait la donnée. La même liaison sert aux noms de catégorie
 * et de niveau : elles sont tenues ici aussi.
 */
import assert from "node:assert/strict";
import { surveiller, navigateur, rendu, finit } from "../harnais.mjs";

export async function run() {
  const ctx = await navigateur.newContext({ viewport: { width: 420, height: 900 } });
  const p = await ctx.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");
  const [sel] = await Promise.all([p.waitForEvent("filechooser"), p.locator(".action-douce", { hasText: "Importer" }).first().click()]);
  await sel.setFiles(new URL("../../donnees/kodokan.json", import.meta.url).pathname);
  await p.locator(".feuille .actions .bouton.principal").click();
  await p.locator(".feuille[aria-label=\"Rapport d'import\"] .actions .bouton.principal").click();
  await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    await app.activerProtection("modifications", { pin: "246813", confirmation: "246813" });
    app.verrouiller();
    app.ouvrirPlusSection("packs");
  });
  await rendu(p);

  const annulerPin = async () => {
    await p.waitForSelector('.feuille[aria-label="Action protégée"]');
    await p.locator('.feuille[aria-label="Action protégée"] .actions .bouton', { hasText: "Annuler" }).click();
    await rendu(p);
  };

  // Nom de discipline : la saisie refusée ne reste pas affichée.
  const nom = await p.evaluate(() => document.querySelector("movenso-app").bibliotheque.disciplines[0].nom);
  const champ = p.locator(".chip-gestion").first();
  await champ.fill(nom + " refusé");
  await champ.blur();
  await annulerPin();
  assert.equal(await p.evaluate(() => document.querySelector("movenso-app").bibliotheque.disciplines[0].nom), nom, "la donnée reste intacte");
  await finit(async () => assert.equal(await champ.inputValue(), nom, "le champ revient au nom réel après l'annulation (D1)"));

  // Le voisin : un nom de catégorie, même liaison, même règle.
  await p.locator("details.sous-volet summary", { hasText: "Catégories" }).click();
  await rendu(p);
  const categorie = p.locator('details[open] input[aria-label="Nom de la catégorie"]').first();
  const avant = await categorie.inputValue();
  await categorie.fill(avant + " refusé");
  await categorie.blur();
  await annulerPin();
  await finit(async () => assert.equal(await categorie.inputValue(), avant, "le nom de catégorie revient aussi après l'annulation"));

  // Et le chemin heureux tient toujours : PIN correct → le renommage s'applique.
  await champ.fill(nom + " accepté");
  await champ.blur();
  await p.waitForSelector('.feuille[aria-label="Action protégée"]');
  await p.fill(".feuille .champ-pin", "246813");
  await p.keyboard.press("Enter");
  await finit(async () => assert.equal(await p.evaluate(() => document.querySelector("movenso-app").bibliotheque.disciplines[0].nom), nom + " accepté", "PIN correct : le renommage s'applique"));
  await finit(async () => assert.equal(await p.locator(".chip-gestion").first().inputValue(), nom + " accepté", "et le champ dit le nouveau nom"));

  // D-430 : la durée de session déverrouillée se choisit et s'enregistre.
  await p.evaluate(() => document.querySelector("movenso-app").ouvrirPlusSection("securite"));
  await rendu(p);
  await p.locator(".chip-filtre", { hasText: "15 min" }).click();
  await finit(async () => assert.equal(await p.evaluate(async () => {
    const disque = JSON.parse(await (await (await (await navigator.storage.getDirectory()).getFileHandle("preferences.json")).getFile()).text());
    return disque.protections?.verrouillage;
  }), "15min", "la durée de session choisie est écrite"));

  // D-430 : modifier le contenu d'un PACK sous protection — PIN, puis le geste
  // REPREND et s'applique, signé « Modifié par » (D-027 révisé).
  const tid = await p.evaluate(() => {
    const a = document.querySelector("movenso-app");
    a.verrouiller();
    const c = a.bibliotheque.contributions.find((x) => x.origine && x.description);
    a.ouvrirFiche(c.techniqueId);
    a.entrerEditionFiche(c.techniqueId);
    return c.techniqueId;
  });
  await rendu(p);
  const zone = p.locator('textarea[aria-label="Description"]');
  await zone.fill("Description amendée sous PIN");
  await zone.blur();
  await p.waitForSelector('.feuille[aria-label="Action protégée"]');
  await p.fill(".feuille .champ-pin", "246813");
  await p.keyboard.press("Enter");
  await finit(async () => assert.deepEqual(await p.evaluate((id) => {
    const c = document.querySelector("movenso-app").bibliotheque.contributions.find((x) => x.techniqueId === id && x.origine);
    return [c.description, Boolean(c.modifiePar), Boolean(c.origine)];
  }, tid), ["Description amendée sous PIN", true, true], "le contenu du pack est amendé après le PIN, signé, et garde son origine"));
  await ctx.close();
}
