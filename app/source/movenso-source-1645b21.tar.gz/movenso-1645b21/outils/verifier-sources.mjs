// Garde-fou statique des sources — quatre contrôles :
// (1) injection HTML (S1.11, D-166) : aucun nouveau vecteur ne doit entrer
//     dans src/ — innerHTML/outerHTML en écriture, insertAdjacentHTML,
//     document.write, eval. La liste des exceptions JUSTIFIÉES est vide
//     depuis la conversion de la Mindmap en éléments SVG typés.
// (2) ordre des COUCHES (S3.A6, D-176) : le domaine est PUR — il n'importe
//     jamais app/echange/stockage/securite ; echange/stockage/securite
//     n'importent jamais app. Sens autorisé : app → (echange|stockage|
//     securite) → domaine.
// (3) CYCLES d'import (S3.A10, D-198) : aucun cycle d'import RUNTIME entre
//     modules de src/ — `import type` (liaison effacée à la compilation) est
//     ignoré, `export … from` compte comme une arête. Les cycles hérités des
//     découpages A3/A4 ont été cassés par les modules *-commun.
// (4) BUDGET de taille (S3.A10, D-198 — l'esprit d'A11) : aucun fichier de
//     src/ ne dépasse 2 000 lignes — empêche la dette des fichiers-monde
//     (racine.ts, 4 018 l. avant A1) de se reformer.
import { readdir, readFile } from "node:fs/promises";
import { join, relative, dirname, normalize } from "node:path";
import { ecrituresSansFilet, ecartsEcriture } from "./ecriture-protegee.mjs";
import { lignesDeCode } from "./analyse-ts.mjs";

/** Plafond dur pour un fichier source hors cliquet, en lignes de CODE —
 *  commentaires exclus, comme le cliquet depuis D-417 : un fichier peut grossir
 *  en explication, pas en code.
 *
 *  1 450 et non 2 000 : l'unité a changé, donc le seuil est RECALCULÉ pour
 *  garder la même exigence (2 000 × 0,729, le ratio code/total mesuré). Le
 *  laisser à 2 000 aurait desserré le plafond d'un tiers en silence.
 *
 *  QUI PEUT LE BOUGER : le porteur. Arbitrage issu de A1 (racine.ts pesait
 *  4 018 lignes avant), déplaçable ICI en une ligne. Ne pas concevoir autour de
 *  lui en silence (D-364). */
const LIGNES_MAX = 1450;
/** Fichiers déjà structurels : leur taille relève du CLIQUET, pas du plafond —
 *  elle ne peut que descendre (D-278). Les lire ici évite de refuser deux fois
 *  la même chose avec deux messages différents. */
const PLAFONDS = JSON.parse(await readFile(new URL("plafonds.json", import.meta.url), "utf8"));

const RACINE = new URL("../src", import.meta.url).pathname;
const MOTIFS = [
  { motif: /\.innerHTML\s*=|\.outerHTML\s*=/, nom: "affectation innerHTML/outerHTML" },
  { motif: /insertAdjacentHTML\s*\(/, nom: "insertAdjacentHTML" },
  { motif: /document\.write\s*\(/, nom: "document.write" },
  { motif: /\beval\s*\(|new Function\s*\(/, nom: "eval / new Function" },
];
/** Exceptions justifiées : chemin relatif → motif toléré. VIDE aujourd'hui. */
const EXCEPTIONS = new Map();

async function lister(dossier) {
  const resultat = [];
  for (const e of await readdir(dossier, { withFileTypes: true })) {
    const chemin = join(dossier, e.name);
    if (e.isDirectory()) resultat.push(...(await lister(chemin)));
    else if (/\.(ts|tsx|js|mjs)$/.test(e.name)) resultat.push(chemin);
  }
  return resultat;
}

/** Couches interdites par dossier source (S3.A6/D-176) : depuis la clé, on
 *  n'importe JAMAIS un des dossiers listés. */
const COUCHES_INTERDITES = new Map([
  ["domaine", ["app", "echange", "stockage", "securite"]],
  ["echange", ["app"]],
  ["stockage", ["app"]],
  ["securite", ["app"]],
]);

function coucheDe(rel) {
  const m = rel.match(/^src\/([^/]+)\//);
  return m ? m[1] : null;
}

/** Arêtes d'import RUNTIME d'un fichier : `import ... from "./x.ts"` et
 *  `export ... from "./x.ts"`, en ignorant les liaisons type-only
 *  (`import type`, `export type { } from`). Cibles relatives seulement. */
function aretesRuntime(chemin, texte) {
  const aretes = [];
  for (const ligne of texte.split("\n")) {
    const m = ligne.match(/^\s*(import|export)\s+(type\s+)?[^"']*from\s+["'](\.[^"']+)["']/);
    if (!m || m[2]) continue;
    aretes.push(normalize(join(dirname(chemin), m[3])));
  }
  return aretes;
}

const erreurs = [];
const graphe = new Map();
for (const chemin of await lister(RACINE)) {
  const rel = "src/" + relative(RACINE, chemin);
  const texte = await readFile(chemin, "utf8");
  for (const { motif, nom } of MOTIFS) {
    if (motif.test(texte) && EXCEPTIONS.get(rel) !== nom)
      erreurs.push(`${rel} : ${nom} — interdit sans justification (S1.11)`);
  }
  const interdits = COUCHES_INTERDITES.get(coucheDe(rel)) ?? [];
  for (const cible of interdits) {
    const motifImport = new RegExp(`from\\s+["'](?:\\.\\./)+${cible}/`);
    if (motifImport.test(texte))
      erreurs.push(`${rel} : import depuis src/${cible}/ — sens de couche interdit (S3.A6 : app → echange|stockage|securite → domaine)`);
  }
  // UN SEUL ÉCRIVAIN de la bibliothèque (S4.4/D-258) : `sauvegarder` porte la
  // bascule protégée (temporaire → relecture → revalidation) ET la file de
  // sérialisation. Toute autre écriture directe du fichier courant contourne
  // les deux — c'est ce que faisait la restauration, seul chemin d'écriture
  // sans protection, et il s'exerce quand l'utilisateur récupère d'un
  // problème. Une garde vaut mieux qu'une relecture : la prochaine écriture
  // directe se signalera d'elle-même.
  for (const [i, ligne] of texte.split("\n").entries()) {
    if (/\becrireTexte\s*\(\s*FICHIER_BIBLIOTHEQUE\b(?!_TMP)/.test(ligne) && !/dans `sauvegarder`/.test(ligne))
      erreurs.push(
        `${rel}:${i + 1} : écriture DIRECTE de bibliotheque.json — seule « sauvegarder » écrit l'état courant`
        + ` (bascule protégée + file, S4.4/D-258)`,
      );
  }

  // Plafond ABSOLU — pour les fichiers hors cliquet seulement (D-278) : rien
  // n'autorise à faire NAÎTRE un fichier de 3 000 lignes. Les fichiers
  // structurels, eux, relèvent du cliquet (`npm run verifier:cliquet`), qui
  // est plus exigeant : leur taille ne peut que descendre.
  const lignes = lignesDeCode(texte);
  if (lignes > LIGNES_MAX && !(rel in PLAFONDS))
    erreurs.push(`${rel} : ${lignes} lignes > budget ${LIGNES_MAX} (S3.A10 — découper avant que la dette ne se reforme)`);
  graphe.set(chemin, aretesRuntime(chemin, texte));
}

// Détection de cycles (DFS sur pile) — chaque cycle rapporté une seule fois.
{
  const vus = new Set();
  const cyclesVus = new Set();
  const dfs = (n, pile) => {
    vus.add(n);
    pile.push(n);
    for (const d of graphe.get(n) ?? []) {
      const i = pile.indexOf(d);
      if (i >= 0) {
        const cycle = pile.slice(i);
        const cle = [...cycle].sort().join("|");
        if (!cyclesVus.has(cle)) {
          cyclesVus.add(cle);
          const noms = [...cycle, d].map((x) => "src/" + relative(RACINE, x));
          erreurs.push(`cycle d'import runtime : ${noms.join(" → ")} (S3.A10 — extraire le partagé vers un module commun)`);
        }
      } else if (!vus.has(d)) dfs(d, pile);
    }
    pile.pop();
  };
  for (const n of graphe.keys()) if (!vus.has(n)) dfs(n, []);
}

// --- Noms de classe CSS partagés entre feuilles thématiques (D-232) ---
// Un nom de classe est une ressource GLOBALE : réemployer `.carte-technique`
// (grille de la bibliothèque) pour une carte de composition a rétréci toutes
// les vignettes de l'app. Les partages ci-dessous sont VOULUS (composants
// communs) ; tout partage NOUVEAU doit être un choix, pas un accident.
const PARTAGES_ATTENDUS = new Set([
  "action-douce", "actions", "bouton", "bouton-icone", "bouton-video", "champ-mini",
  "chip-filtre", "chips-filtres", "creation-discipline", "details", "ecran", "fil", "jp",
  "liaisons", "ligne-atelier", "media-legende", "media-principal", "media-video",
  "pastille", "points", "recherche", "resultat", "resultats", "titre-atelier",
  "vignette", "vignette-initiale", "voix-corps",
]);
{
  const dossier = join(RACINE, "styles");
  const parClasse = new Map();
  for (const nom of await readdir(dossier)) {
    if (!nom.endsWith(".css") || nom === "app.css") continue;
    const texte = (await readFile(join(dossier, nom), "utf8")).replace(/\/\*[\s\S]*?\*\//g, "");
    for (const m of texte.matchAll(/(^|[\s,>+~])\.([A-Za-z_][\w-]*)/g)) {
      const cle = m[2];
      if (!parClasse.has(cle)) parClasse.set(cle, new Set());
      parClasse.get(cle).add(nom);
    }
  }
  for (const [classe, feuilles] of parClasse)
    if (feuilles.size > 1 && !PARTAGES_ATTENDUS.has(classe))
      erreurs.push(
        `classe CSS « .${classe} » définie dans ${[...feuilles].sort().join(" et ")} — ` +
        `collision probable (D-232) : préfixer, ou l'ajouter à PARTAGES_ATTENDUS si le partage est voulu`,
      );
}

// ---------- le CONTRAT ne connaît pas le codec (D-274) ----------
//
// `movpack-contrat.ts` dit ce qu'on EXIGE d'un conteneur ; `movpack.ts`
// l'ouvre. La coupure ne tient que si la première ne dépend pas de la
// seconde : une règle qui aurait besoin de `fflate` pour s'énoncer prouverait
// que la frontière est mal placée. Une consigne ne l'aurait pas tenue.
{
  const contrat = "src/echange/movpack-contrat.ts";
  const src = await readFile(contrat, "utf8").catch(() => null);
  if (src !== null) {
    for (const interdit of ["fflate", "./movpack.ts"])
      if (new RegExp(`from\\s+["']${interdit.replace(".", "\\.")}["']`).test(src))
        erreurs.push(`${contrat} : importe « ${interdit} » — le contrat doit s'énoncer SANS le codec (D-274).`);
  }
}

// ---------- « efface tout » efface VRAIMENT tout (audit 2026-08-13, P1-1) ----------
//
// `images/` a été ajouté au stockage (schéma 6, D-269) sans être rattaché à
// `reinitialiser()`. Toutes les gardes restaient vertes, et l'écran promettait
// « Tout sera supprimé de cet appareil » pendant que les couvertures
// survivaient en octets orphelins. C'est le défaut TRANSVERSE type : chaque
// pièce est correcte, c'est le lien entre elles qui manque.
//
// La garde est donc structurelle : tout dossier de premier niveau déclaré dans
// `opfs.ts` doit apparaître dans le corps de `reinitialiser()`. Une exemption
// reste possible, mais elle doit être ÉCRITE ici avec sa raison — jamais
// silencieuse.
{
  const opfs = "src/stockage/opfs.ts";
  const src = await readFile(opfs, "utf8").catch(() => null);
  if (src !== null) {
    // `import` est un SOUS-dossier de staging : la suppression récursive de
    // `staging` l'emporte déjà. C'est la seule exemption, et elle se lit.
    const exempts = new Set(["DOSSIER_IMPORT"]);
    const declares = [...src.matchAll(/^const (DOSSIER_[A-Z_]+)\s*=/gm)].map((m) => m[1]);
    const corps = src.slice(src.indexOf("async reinitialiser("));
    const fin = corps.indexOf("\n  }");
    const dansReinit = fin > 0 ? corps.slice(0, fin) : corps;
    for (const nom of declares)
      if (!exempts.has(nom) && !dansReinit.includes(nom))
        erreurs.push(
          `${opfs} : « ${nom} » n'est pas effacé par reinitialiser() — l'écran promet que RIEN ne survit (audit P1-1). ` +
            `L'ajouter, ou l'exempter EXPLICITEMENT dans outils/verifier-sources.mjs avec sa raison.`,
        );
  }
}

// UNE ÉCRITURE MÉTIER DOIT DIRE SON ÉCHEC (D-415) — cliquet de dette. La règle
// vit à la DÉFINITION, pas à l'appel : un gestionnaire Lit ne peut pas attendre,
// donc `void` y est l'idiome ; mais si chaque fonction qui écrit rapporte son
// propre échec, ce `void` devient sans danger. L'accident et le choix du cliquet
// sont dans `outils/ecriture-protegee.mjs`.
const ecritures = await ecrituresSansFilet();
erreurs.push(...ecartsEcriture(ecritures));

if (erreurs.length) {
  console.error(`verifier-sources : ${erreurs.length} problème(s) dans src/ :`);
  for (const e of erreurs) console.error("  - " + e);
  process.exit(1);
}
// Le message ÉNUMÈRE ce qui a été contrôlé : il ne mentionnait pas les
// écritures, alors que la garde les vérifiait — un message plus ÉTROIT que sa
// mesure, l'erreur symétrique de celle que cette passe corrige (relecture
// D-417, mineur a). Et il dit la COUVERTURE, pas seulement le verdict.
console.log(`verifier-sources : aucun vecteur d'injection HTML ; couches respectées (domaine pur) ; zéro cycle d'import runtime (${graphe.size} fichiers) ; aucun fichier hors cliquet au-delà de ${LIGNES_MAX} lignes de code ; aucune collision de classe CSS entre feuilles ; le contrat movpack ignore le codec ; « efface tout » couvre tous les dossiers du stockage ; toutes les mentions de persister/snapshot sont des écritures reconnues ou la définition (D-419), ${ecritures.population} écritures examinées, ${ecritures.sansFilet.length} sans filet, toutes déclarées.`);
