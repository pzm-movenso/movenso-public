/**
 * CLIQUET de taille des fichiers structurels (D-278).
 *
 *   node outils/cliquet.mjs              resserre les plafonds au réel
 *   node outils/cliquet.mjs --verifier   échoue si un fichier a grossi,
 *                                        ou si un plafond n'a pas été resserré
 *
 * Un plafond ABSOLU (2 000 lignes) a un défaut que le porteur a nommé : à
 * 1 968 lignes, il ne dit pas « ce fichier est trop gros », il dit « tu as
 * encore droit à 32 lignes ». Un cliquet dit autre chose — **on peut
 * améliorer, on ne peut pas revenir en arrière.**
 *
 * D'où deux refus, et le second est celui qui rend le mécanisme vivant :
 *  - un fichier qui GROSSIT au-delà de son plafond est refusé ;
 *  - un fichier qui a MAIGRI sans que son plafond suive l'est aussi. Sinon la
 *    marge regagnée se reconstituerait en silence, et le cliquet redeviendrait
 *    un seuil. Le resserrement est donc committé avec le gain : l'architecture
 *    s'améliore dans l'historique, lisiblement.
 *
 * Le plafond ABSOLU reste, pour les fichiers non listés : rien n'autorise à
 * faire naître un fichier de 3 000 lignes.
 *
 * ─── LE CLIQUET COMPTE LE CODE, PAS LES COMMENTAIRES (D-417) ───
 *
 * L'ACCIDENT, mesuré : dans la seule passe d'audit externe, ce cliquet a bloqué
 * CINQ fois, et chaque fois la sortie a été de compresser une explication pour
 * faire entrer un correctif de perte de données. Or le dépôt EXIGE qu'une règle
 * nomme l'incident qui l'a produite (`CLAUDE.md`, consignes locales) : le
 * cliquet pénalisait donc structurellement ce que le projet valorise le plus, et
 * D-400/D-404 avaient déjà nommé le risque — « plutôt que couper des
 * commentaires porteurs de décisions ».
 *
 * La mesure porte donc sur les lignes qui portent du CODE (`lignesDeCode`, par
 * le PARSEUR TypeScript). Un fichier peut grossir en EXPLICATION sans limite ;
 * il ne peut pas grossir en CODE. C'est plus exigeant sur ce qui compte, et
 * gratuit sur ce qu'on veut encourager.
 *
 * LE SEUIL D'ENTRÉE A ÉTÉ RECALCULÉ, pas laissé en place : changer d'unité sans
 * y toucher aurait desserré la porte d'un tiers **en silence** — exactement le
 * contournement que D-364 interdit. Ratio code/total mesuré sur les fichiers de
 * plus de 200 lignes : 0,729. 400 × 0,729 ≈ 290.
 *
 * ─── QUAND UN PLAFOND PEUT MONTER (D-417) ───
 *
 * Un cliquet qui ne monte JAMAIS punit l'honnêteté de l'instrument : le jour où
 * la mesure s'améliore — un parseur là où il y avait une regex — elle voit plus
 * de choses, et le cliquet lit ce progrès comme une régression. Deux raisons
 * distinctes de monter, donc, et le journal doit dire LAQUELLE :
 *   · « j'ai écrit du code » → ce n'est pas un recalage, c'est une dette :
 *     dégraisser, extraire, ou demander au porteur (le refus reste) ;
 *   · « la MESURE a changé » → recalage autorisé, à journaliser comme tel, avec
 *     l'ancienne et la nouvelle unité. Ce n'est pas le code qui a empiré.
 * Aucune garde ne sait distinguer les deux : c'est le journal qui le tient, et
 * c'est dit ici plutôt que sous-entendu.
 */
import { execFileSync } from "node:child_process";
import { readFileSync, writeFileSync } from "node:fs";
import { lignesDeCode } from "./analyse-ts.mjs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const RACINE = join(dirname(fileURLToPath(import.meta.url)), "..");
export const FICHIER_PLAFONDS = "outils/plafonds.json";

/** Au-delà de ce nombre de lignes de CODE, un fichier entre au cliquet et n'en
 *  sort plus. En deçà, il vit librement — un fichier de 80 lignes qui en gagne
 *  10 n'est pas une dette.
 *
 *  290, et non 400 : l'unité a changé (code, plus total), donc le seuil est
 *  RECALCULÉ pour garder la même exigence pratique — 400 × 0,729 (ratio
 *  code/total mesuré) ≈ 290. Le laisser à 400 aurait desserré la porte d'un
 *  tiers sans qu'aucun diff ne le montre.
 *
 *  QUI PEUT LE BOUGER : le porteur (D-278). C'est un arbitrage, pas une
 *  mesure — et il se déplace ICI, en une ligne. Ne pas concevoir autour de lui
 *  en silence : si ce seuil pousse à découper un module qui n'avait pas besoin
 *  de l'être, la question se pose au porteur (D-364). */
const SEUIL = 290;

export function mesurer() {
  const suivis = execFileSync("git", ["ls-files", "src"], { cwd: RACINE, encoding: "utf8" })
    .split("\n").filter((f) => f.endsWith(".ts"));
  const tailles = new Map();
  for (const f of suivis) tailles.set(f, lignesDeCode(readFileSync(join(RACINE, f), "utf8")));
  return tailles;
}

export function plafonds() {
  return JSON.parse(readFileSync(join(RACINE, FICHIER_PLAFONDS), "utf8"));
}

/** Les plafonds attendus : le minimum entre l'existant et le réel — jamais
 *  au-dessus. Un fichier qui franchit le seuil entre au cliquet ; un fichier
 *  déjà entré y reste, même s'il repasse sous le seuil (c'est le principe). */
export function attendus(tailles, actuels) {
  const cible = {};
  for (const [f, n] of [...tailles].sort()) {
    const connu = actuels[f];
    if (connu === undefined && n < SEUIL) continue;
    cible[f] = Math.min(connu ?? Infinity, n);
  }
  // Un fichier supprimé quitte le cliquet : garder son plafond n'aurait pas de sens.
  return cible;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const tailles = mesurer();
  const actuels = plafonds();
  const cible = attendus(tailles, actuels);

  if (process.argv.includes("--verifier")) {
    const ecarts = [];
    for (const [f, n] of tailles) {
      const max = actuels[f];
      if (max === undefined) continue;
      if (n > max) ecarts.push(
        `${f} : ${n} lignes de CODE > plafond ${max} — le cliquet ne remonte pas.`
        + " Les commentaires ne comptent pas : compresser une explication ne débloque plus rien (D-417)."
        + " Deux issues, et le journal doit dire laquelle : du code en trop (dégraisser, extraire, ou décision du porteur),"
        + " ou la MESURE qui a changé (recalage, à journaliser comme tel).",
      );
      if (n < max) ecarts.push(`${f} : ${n} lignes de code < plafond ${max} — resserrer le cliquet (\`npm run cliquet\`) pour que la marge regagnée ne se reconstitue pas.`);
    }
    for (const f of Object.keys(actuels)) if (!tailles.has(f)) ecarts.push(`${f} : plafond déclaré pour un fichier absent — \`npm run cliquet\`.`);
    for (const f of Object.keys(cible)) if (actuels[f] === undefined) ecarts.push(`${f} : ${tailles.get(f)} lignes, entre au cliquet — \`npm run cliquet\`.`);
    if (ecarts.length) {
      console.error(`verifier:cliquet : ${ecarts.length} écart(s)\n`);
      for (const e of ecarts) console.error(`  ✕ ${e}`);
      process.exit(1);
    }
    console.log(`verifier:cliquet : ${Object.keys(actuels).length} fichiers structurels, aucun n'a grossi en CODE (les commentaires ne comptent pas, D-417).`);
  } else {
    const avant = actuels;
    writeFileSync(join(RACINE, FICHIER_PLAFONDS), JSON.stringify(cible, null, 2) + "\n");
    const gains = Object.entries(cible).filter(([f, n]) => avant[f] !== undefined && n < avant[f]);
    const neufs = Object.keys(cible).filter((f) => avant[f] === undefined);
    console.log(`cliquet : ${Object.keys(cible).length} fichiers structurels.`);
    for (const [f, n] of gains) console.log(`  ↓ ${f} : ${avant[f]} → ${n}`);
    for (const f of neufs) console.log(`  + ${f} : ${cible[f]} (entre au cliquet)`);
    if (!gains.length && !neufs.length) console.log("  (aucun changement)");
  }
}
