/**
 * UNE ÉCRITURE MÉTIER DOIT DIRE SON ÉCHEC — cliquet de dette (D-415, D-416,
 * réécrite sur l'AST en D-417).
 *
 * ─── TROIS TOURS DE RUSTINE, ET POURQUOI ÇA NE POUVAIT PAS CONVERGER ───
 *
 * D-410 a posé une garde contre `void app.persister(b)` : elle ne matchait rien
 * dès son propre commit. D-415 l'a déplacée à la définition : `!/\bcatch\b/` sur
 * le corps, donc un `catch` sans rapport absolvait. D-416 a mesuré l'écriture
 * elle-même, par comptage d'accolades et énumération des formes : le tour
 * suivant a trouvé `const f = function`, `async function` anonyme, la méthode
 * raccourcie d'objet, une accolade dans un littéral — et surtout une accolade de
 * TYPE EN LIGNE dans une signature multi-lignes, qui tronquait **15
 * déclarations** et rendait **deux écritures réelles INVISIBLES**
 * (`creerTechnique`, `modifierRelation`).
 *
 * Le diagnostic n'est pas « il fallait mieux rustiner ». C'est qu'on posait une
 * question de STRUCTURE à un outil de TEXTE : **une expression régulière ne peut
 * pas énumérer la grammaire de TypeScript**, donc un tour de plus était garanti
 * à chaque fois. La garde vit désormais sur l'AST (`analyse-ts.mjs`) — le
 * parseur est déjà payé (`typescript` est déclaré dans `dependances.json`), et
 * ce module est PLUS COURT que la version qu'il remplace : on retire du
 * mécanisme, on n'en ajoute pas (l'argument D-324 joue ici POUR l'AST, parce que
 * personne n'a à maintenir la grammaire à la main).
 *
 * ─── CE QU'ELLE MESURE, ET SA COUVERTURE (règle D-417) ───
 *
 * Une ÉCRITURE est un appel à `app.persister` / `this.persister`, ou à
 * `<…>.stockage.snapshot` — qui LÈVE depuis D-407. Elle est PROTÉGÉE si elle est
 * dans la portée d'un `try { … } catch` de sa propre fonction (on s'arrête à la
 * première frontière de fonction), ou si son expression porte un `.catch(`.
 *
 * Et — c'est la nouveauté de procédé — **la garde déclare sa COUVERTURE** : deux
 * nombres, la population d'écritures trouvées et celle rattachée à une
 * déclaration. Un écart est un REFUS, avec les lignes nommées. C'est le seul
 * contrôle qui aurait attrapé les deux écritures invisibles de D-416 : elles
 * existaient, la garde ne les regardait pas, et rien ne disait qu'elle ne les
 * regardait pas. Une garde qui rapporte ce qu'elle a trouvé sans dire ce qu'elle
 * n'a pas examiné est une garde qui s'annonce plus large que sa mesure.
 *
 * ─── LE CLIQUET, ET QUAND IL PEUT MONTER ───
 *
 * La dette est DÉCLARÉE (`ecritures-sans-filet.json`) et ne peut que décroître :
 * une fonction neuve sans filet est refusée, une entrée devenue inutile aussi.
 * MAIS une mesure qui s'améliore voit plus de choses — le passage à l'AST fait
 * apparaître des écritures que les regexes rataient. Le cliquet punirait alors
 * l'honnêteté de l'instrument. Deux raisons de monter, et le journal doit dire
 * laquelle : « j'ai écrit du code sans filet » (refus, c'est une dette) ou « je
 * vois mieux » (recalage autorisé, journalisé comme tel). Aucune garde ne sait
 * distinguer les deux.
 */
import { readdir, readFile } from "node:fs/promises";
import { join, relative } from "node:path";
import { RAISON_MINIMALE } from "./raison-minimale.mjs";
import { lireSource, nomDe, fonctionEnglobante, protege, noeuds, ts } from "./analyse-ts.mjs";

const RACINE = new URL("../src/app", import.meta.url).pathname;
const DETTE = new URL("ecritures-sans-filet.json", import.meta.url);

/** Les noms d'appels qui écrivent la bibliothèque. Un seul lieu (D-253) : la
 *  RECONNAISSANCE d'une écriture (`estEcriture`) et le contrôle de COUVERTURE
 *  (`mentionsSuspectes`) doivent parler du même ensemble, sinon l'un voit ce
 *  que l'autre ignore. */
const NOMS_ECRITURE = new Set(["persister", "snapshot"]);

/** Un appel qui ÉCRIT la bibliothèque : `app.persister(…)`, `this.persister(…)`
 *  ou `<…>.stockage.snapshot(…)`. Reconnu sur la FORME de l'arbre, donc quelle
 *  que soit la mise en page. */
function estEcriture(n) {
  if (!ts.isCallExpression(n) || !ts.isPropertyAccessExpression(n.expression)) return false;
  const acces = n.expression;
  const cible = acces.expression;
  if (acces.name.text === "persister")
    return cible.kind === ts.SyntaxKind.ThisKeyword || (ts.isIdentifier(cible) && cible.text === "app");
  if (acces.name.text === "snapshot")
    return ts.isPropertyAccessExpression(cible) && cible.name.text === "stockage";
  return false;
}

/**
 * Toute MENTION du nom `persister`/`snapshot` qui n'est PAS une écriture
 * reconnue ni une exception structurelle connue (D-419).
 *
 * Le trou que ça ferme : `estEcriture` reconnaît la notation POINTÉE-et-appelée,
 * et la couverture (population vs rattachées) compte en AVAL d'elle — donc
 * aucun des deux nombres ne peut signaler une écriture existant sous une forme
 * non reconnue (`app["persister"](b)`, `const p = app.persister; p(b)`,
 * `const {persister} = app`). « N examinées sur N trouvées » était alors un
 * sous-compte des formes RECONNUES présenté comme la mesure complète — la
 * classe même que D-416/D-417 combattent, relevée par le checker. La règle
 * D-417 (3) veut que la population à examiner soit TOUTES les mentions, pas les
 * formes structurellement reconnues : ce contrôle est ce cran-là.
 *
 * Une mention est LÉGITIME dans deux cas seulement : elle est le nom d'un accès
 * pointé effectivement APPELÉ (donc déjà comptée comme écriture), ou c'est la
 * DÉFINITION de la méthode (`async persister(b)`). Tout le reste — accès
 * indexé, alias non appelé, déstructuration — est rendu, avec sa ligne : si
 * c'est une écriture, la rendre pointée-et-appelée ; sinon, c'est un usage à
 * regarder à la main. Aucune occurrence vivante aujourd'hui (les 60 mentions
 * sont pointées-appelées, plus la seule définition) : c'est un filet, pas une
 * réparation.
 */
function mentionsSuspectes(source) {
  const suspectes = [];
  const nomVaut = (n) => n && (ts.isIdentifier(n) || ts.isStringLiteral(n) || ts.isPrivateIdentifier(n)) && NOMS_ECRITURE.has(n.text);
  const visiter = (n) => {
    if (nomVaut(n)) {
      const p = n.parent;
      const pointeAppele = ts.isPropertyAccessExpression(p) && p.name === n
        && ts.isCallExpression(p.parent) && p.parent.expression === p;
      const definition = (ts.isMethodDeclaration(p) || ts.isFunctionDeclaration(p)) && p.name === n;
      if (!pointeAppele && !definition)
        suspectes.push({ ligne: source.getLineAndCharacterOfPosition(n.getStart(source)).line + 1, forme: ts.SyntaxKind[p.kind] });
    }
    ts.forEachChild(n, visiter);
  };
  visiter(source);
  return suspectes;
}

async function fichiers(dossier) {
  const sortie = [];
  for (const e of await readdir(dossier, { withFileTypes: true })) {
    const chemin = join(dossier, e.name);
    if (e.isDirectory()) sortie.push(...(await fichiers(chemin)));
    else if (chemin.endsWith(".ts")) sortie.push(chemin);
  }
  return sortie;
}

/**
 * Rend `{ sansFilet, dette, ailleurs, population, rattachees, orphelines }`.
 * `sansFilet` et `population` sont COMPTÉS, jamais écrits (leçon du « 41 »).
 */
export async function ecrituresSansFilet() {
  const sansFilet = new Set();
  const orphelines = [];
  const suspectes = [];
  let population = 0;
  let rattachees = 0;
  for (const f of await fichiers(RACINE)) {
    const source = lireSource(f);
    const rel = relative(RACINE, f).replaceAll("\\", "/");
    for (const m of mentionsSuspectes(source)) suspectes.push(`${rel}:${m.ligne} (${m.forme})`);
    for (const appel of noeuds(source, estEcriture)) {
      population++;
      const fonction = fonctionEnglobante(appel);
      const ligne = source.getLineAndCharacterOfPosition(appel.getStart(source)).line + 1;
      if (!fonction) {
        orphelines.push(`${rel}:${ligne}`); // écriture au niveau module : anormal, donc dit
        continue;
      }
      rattachees++;
      if (!protege(appel)) sansFilet.add(`${rel}:${nomDe(fonction, source)}`);
    }
  }
  const declaree = JSON.parse(await readFile(DETTE, "utf8"));
  return {
    sansFilet: [...sansFilet].sort(),
    dette: (declaree.dette ?? []).slice().sort(),
    ailleurs: declaree.protegees_ailleurs ?? {},
    population,
    rattachees,
    orphelines,
    suspectes: suspectes.sort(),
  };
}

export function ecartsEcriture({ sansFilet, dette, ailleurs, population, rattachees, orphelines, suspectes }) {
  const ecarts = [];
  // RECONNAISSANCE avant couverture (D-419) : la couverture compte les formes
  // reconnues ; ce contrôle-ci vérifie qu'aucune écriture n'existe sous une
  // forme QUE la reconnaissance ignore — sinon les deux nombres de couverture
  // s'accordent sur un sous-compte.
  for (const m of suspectes ?? [])
    ecarts.push(
      `${m} : mention de \`persister\`/\`snapshot\` sous une forme que la garde ne reconnaît`
      + " PAS comme écriture (accès indexé, alias, déstructuration). Si c'en est une, la rendre"
      + " pointée-et-appelée pour qu'elle soit jugée ; sinon, usage à vérifier à la main (D-419).",
    );
  // COUVERTURE ensuite : une garde dit ce qu'elle n'a pas regardé (D-417).
  if (population !== rattachees) {
    ecarts.push(
      `couverture INCOMPLÈTE : ${population} écritures trouvées, ${rattachees} rattachées à une déclaration.`
      + ` Non rattachées : ${orphelines.join(", ")}. Une écriture hors de toute fonction n'est pas jugeable —`
      + " la garde refuse plutôt que de faire passer un sous-compte pour une mesure (D-417).",
    );
  }
  const couverte = new Set([...dette, ...Object.keys(ailleurs)]);
  const connue = new Set(sansFilet);
  for (const e of sansFilet) {
    if (!couverte.has(e))
      ecarts.push(
        `${e} écrit la bibliothèque (ou prend un snapshot) sans que l'écriture soit dans la portée d'un`
        + " try/catch : ses appelants sont des `void`, donc une panne muterait la mémoire, afficherait un ✓ et"
        + " perdrait le geste au prochain démarrage. Attraper l'erreur (patron de `modifierComposition`), ou"
        + " déclarer dans outils/ecritures-sans-filet.json — la dette ne peut que DÉCROÎTRE (D-415 → D-417).",
      );
  }
  for (const e of dette) {
    if (!connue.has(e))
      ecarts.push(`${e} est déclaré sans filet mais ne l'est plus — retirer l'entrée de outils/ecritures-sans-filet.json (le cliquet se resserre).`);
  }
  for (const [e, raison] of Object.entries(ailleurs)) {
    if (!connue.has(e))
      ecarts.push(`${e} est exempté mais n'écrit plus sans filet — retirer l'entrée « protegees_ailleurs ».`);
    if (typeof raison !== "string" || raison.trim().length < RAISON_MINIMALE)
      ecarts.push(`${e} : exemption sans raison recevable (${RAISON_MINIMALE} caractères minimum) — une exemption non justifiée est un trou, pas une décision.`);
  }
  return ecarts;
}
