/**
 * ANALYSE TypeScript PARTAGÉE — le socle des gardes qui posent une question de
 * STRUCTURE (D-417).
 *
 * L'ACCIDENT, en trois tours de relecture. La garde des écritures sans filet
 * posait une question de structure — « cet appel est-il dans la portée d'un
 * try/catch ? » — à un outil de TEXTE : comptage d'accolades, énumération des
 * formes de déclaration, coup d'œil de 80 caractères en arrière. Chaque tour a
 * rustiné les formes auxquelles l'auteur avait pensé, et le tour suivant en a
 * trouvé d'autres : fléchée, `const f = function`, `async function` anonyme,
 * méthode raccourcie d'objet, accolade dans un littéral de chaîne, accolade
 * d'un type en ligne dans une signature multi-lignes — cette dernière tronquant
 * **15 déclarations** et rendant deux écritures réelles INVISIBLES.
 *
 * Ce n'est pas une suite de malchances : **une expression régulière ne peut pas
 * énumérer la grammaire de TypeScript**, donc le tour suivant était garanti.
 * C'est ça, la boucle — et on n'en sort pas en rustinant mieux, on en sort en
 * changeant de niveau.
 *
 * POURQUOI CE N'EST PAS UNE COMPLICATION AJOUTÉE (D-324, la question que le
 * dépôt pose toujours) : `typescript` est déjà déclaré dans
 * `outils/dependances.json` — le parseur est **déjà payé**. Et le « qui la
 * maintiendra ? » favorise l'AST : personne n'a à tenir la grammaire à la main.
 * Ce module RETIRE du mécanisme, il n'en ajoute pas.
 *
 * Il sert deux gardes, qui posaient la même question à deux niveaux différents :
 * le cliquet de taille (`cliquet.mjs`) et la protection des écritures
 * (`ecriture-protegee.mjs`).
 */
import { readFileSync } from "node:fs";
import ts from "typescript";

export function lireSource(chemin) {
  return ts.createSourceFile(chemin, readFileSync(chemin, "utf8"), ts.ScriptTarget.Latest, true);
}

/**
 * Nombre de lignes portant du CODE — commentaires et lignes vides exclus.
 *
 * C'est la mesure du cliquet depuis D-417, et le changement est un arbitrage,
 * pas un détail : compter les lignes TOTALES faisait payer la documentation.
 * Or le dépôt EXIGE qu'une règle nomme l'incident qui l'a produite
 * (`CLAUDE.md`, consignes locales) — le cliquet pénalisait donc structurellement
 * ce que le projet valorise le plus, et cinq fois dans la seule passe d'audit il
 * a fallu compresser une explication pour faire entrer un correctif de perte de
 * données. Un fichier peut désormais grossir en EXPLICATION sans limite ; il ne
 * peut pas grossir en CODE.
 *
 * Un littéral de gabarit multi-lignes compte pour toutes ses lignes : c'est du
 * code (des gabarits Lit, ici), pas du commentaire.
 *
 * LIMITE ASSUMÉE (D-419, mineur ④ du checker) : un fichier VIDE ou 100 %
 * commentaires rend 1, pas 0 (la feuille `SyntaxList`/EOF). Sans effet : aucun
 * fichier `.ts` du dépôt n'est dans ce cas — dès qu'il porte un jeton de code
 * il est compté juste — et 1 est loin des plafonds de 290/1450. Signalé pour
 * complétude, pas corrigé.
 */
export function lignesDeCode(texte) {
  // Le PARSEUR, pas le scanner — et c'est une leçon payée : ma première version
  // utilisait `ts.createScanner`, qui n'a pas le contexte grammatical pour
  // trancher entre une division et une regex. Il a pris un `/` pour le début
  // d'une expression régulière, avalé le reste du fichier en un seul token de
  // gabarit, et compté 751 lignes de commentaire comme du code. Un scanner est
  // un demi-parseur : c'était la même erreur de niveau, un cran plus bas.
  const source = ts.createSourceFile("mesure.ts", texte, ts.ScriptTarget.Latest, true);
  const lignes = new Set();
  const marquer = (noeud) => {
    // Un JSDoc est un NŒUD de l'arbre, feuille parmi les enfants du statement
    // qu'il documente : sans cette exclusion, un en-tête de quatre lignes
    // comptait pour quatre lignes de code. Et `EndOfFileToken` marque la ligne
    // vide finale. Les deux ont été trouvés en instrumentant un échantillon de
    // neuf lignes dont on connaissait la réponse — deux — avant de mesurer les
    // 15 fichiers du cliquet. Mesurer d'abord ce qu'on sait déjà.
    if (noeud.kind === ts.SyntaxKind.EndOfFileToken) return;
    if (noeud.kind >= ts.SyntaxKind.FirstJSDocNode && noeud.kind <= ts.SyntaxKind.LastJSDocNode) return;
    if (noeud.getChildCount(source) === 0) {
      // Une FEUILLE est un token : son étendue commence APRÈS la trivia (donc
      // après les commentaires) et peut couvrir plusieurs lignes — un gabarit
      // Lit multi-lignes est du code, et compte pour toutes ses lignes.
      const d = source.getLineAndCharacterOfPosition(noeud.getStart(source)).line;
      const f = source.getLineAndCharacterOfPosition(Math.max(noeud.getStart(source), noeud.getEnd() - 1)).line;
      for (let l = d; l <= f; l++) lignes.add(l);
      return;
    }
    for (const enfant of noeud.getChildren(source)) marquer(enfant);
  };
  marquer(source);
  return lignes.size;
}

/** Le nom PORTABLE d'une fonction, quelle que soit sa forme syntaxique — c'est
 *  précisément ce que les regexes énuméraient une par une. Une fonction sans nom
 *  déclarable est désignée par sa ligne : elle reste NOMMÉE, donc adressable. */
export function nomDe(noeud, source) {
  const ligne = source.getLineAndCharacterOfPosition(noeud.getStart(source)).line + 1;
  const brut = (n) => (n && ts.isIdentifier(n) ? n.text : n && ts.isPrivateIdentifier(n) ? n.text : n && ts.isStringLiteral(n) ? n.text : null);
  if (ts.isFunctionDeclaration(noeud) || ts.isMethodDeclaration(noeud)) {
    const n = brut(noeud.name);
    if (n) return n;
  }
  const p = noeud.parent;
  if (p && (ts.isVariableDeclaration(p) || ts.isPropertyAssignment(p) || ts.isPropertyDeclaration(p))) {
    const n = brut(p.name);
    if (n) return n;
  }
  return `<anonyme@${ligne}>`;
}

/** La fonction ENGLOBANTE la plus proche, ou `null` au niveau module. */
export function fonctionEnglobante(noeud) {
  for (let n = noeud.parent; n; n = n.parent) if (ts.isFunctionLike(n)) return n;
  return null;
}

/**
 * L'appel est-il dans la PORTÉE d'un `try { … } catch` ?
 *
 * On remonte les parents et on s'arrête à la première frontière de fonction :
 * un `try` situé au-delà n'attrape pas ce qui se passe dans une fonction
 * imbriquée. C'est exactement la phrase de la doctrine, écrite UNE fois au lieu
 * d'être approchée par un regard en arrière de 80 caractères.
 *
 * Le `.catch(…)` chaîné compte aussi : `await x.persister(b).catch(…)` protège
 * son écriture sans `try`, et c'est l'idiome de `enregistrerReordre`.
 *
 * LIMITE ASSUMÉE (D-419, mineur ② du checker) : `x.persister(b).then(ok, onErr)`
 * — la gestion du rejet par le SECOND argument de `then` — n'est PAS reconnue,
 * donc signalée « sans filet » à tort. C'est un faux positif, pas un trou : la
 * garde crie sur une forme valide, elle ne laisse pas passer une écriture nue.
 * `.catch` est l'idiome unique du dépôt (vérifié) ; le jour où `.then(ok, onErr)`
 * apparaîtrait, on l'ajoute ici — pas avant (D-324 : on ne construit pas pour un
 * cas non constaté).
 */
export function protege(appel) {
  // `.catch()` chaîné sur l'expression de l'appel.
  for (let n = appel; n && !ts.isFunctionLike(n); n = n.parent) {
    if (ts.isCallExpression(n) && ts.isPropertyAccessExpression(n.expression) && n.expression.name.text === "catch") return true;
    if (ts.isExpressionStatement(n)) break;
  }
  let enfant = appel;
  for (let n = appel.parent; n; enfant = n, n = n.parent) {
    if (ts.isFunctionLike(n)) return false; // frontière : au-delà, le try n'attrape plus
    if (ts.isTryStatement(n) && n.catchClause && n.tryBlock === enfant) return true;
  }
  return false;
}

/** Tous les nœuds satisfaisant `predicat`, avec leur ligne. */
export function noeuds(source, predicat) {
  const trouves = [];
  const visiter = (n) => {
    if (predicat(n)) trouves.push(n);
    ts.forEachChild(n, visiter);
  };
  visiter(source);
  return trouves;
}

export { ts };
