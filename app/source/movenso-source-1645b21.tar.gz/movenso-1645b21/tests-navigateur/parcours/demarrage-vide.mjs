/**
 * CHAPITRE e2e (S3.A7) — Scénario A — vide mais jamais bloqué (D-017).
 * Contexte(s) Playwright propre(s) : OPFS isolé, lançable après tout chapitre.
 * Code déménagé tel quel de parcours.mjs.
 */
import assert from "node:assert/strict";
import { writeFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { surveiller, lent, ouvrirPlus, revelerCreation, ouvrirSection, ouvrirCreationSection, ouvrirDisc, gesteCapture, navigateur, rendu, finit } from "../harnais.mjs";

export async function run() {
/* ===== Scénario A — vide mais jamais bloqué (D-017) : créer sa discipline,
   capturer, sans aucun contenu installé. Contexte isolé (OPFS propre). ===== */
const ctxA = await navigateur.newContext({ viewport: { width: 400, height: 850 } });
{
  const page = await ctxA.newPage();
  surveiller(page);
  await page.goto("http://localhost:4517/");
  await page.waitForSelector(".action-douce");
  assert.equal(await page.locator(".chip-discipline").count(), 0, "aucun contenu ne doit être embarqué");
  assert.ok((await page.locator(".ecran").innerText()).includes("Elle démarre vide, choisis comment commencer"), "état vide inexplicite");
  assert.equal(await page.locator(".ecran-vierge").count(), 1, "l'écran de première ouverture est celui de l'état VIERGE (D-328)");
  // D-329 : cet écran se rendait BORD À BORD, seul de toute l'app. Il porte
  // maintenant la gouttière commune — la bande de marque, elle, reste pleine.
  assert.deepEqual(
    await page.evaluate(() => {
      // le CONTENU, pas le conteneur : la gouttière est un padding, elle ne
      // déplace pas le rectangle de la boîte qui la porte.
      const c = document.querySelector(".depart-majeur").getBoundingClientRect();
      return { gauche: Math.round(c.left), droite: Math.round(document.documentElement.clientWidth - c.right) };
    }),
    { gauche: 18, droite: 18 },
    "l'écran de première ouverture porte les gouttières de l'app (D-329)",
  );
  // D-084/D-223 : TROIS destinations par défaut — « Relations » ET « Compositions »
  // sont des options bêta (Plus › Fonctions avancées, section propre depuis D-234).
  // D-336 : Favoris n'est plus un onglet mais un filtre de la Bibliothèque.
  // Il reste DEUX destinations par défaut, les deux bêtas restant opt-in.
  assert.equal(await page.locator(".barre-nav .nav-onglet").count(), 2, "exactement deux onglets attendus par défaut (D-336)");
  assert.deepEqual(await page.locator(".barre-nav .nav-onglet span").allInnerTexts(), ["Bibliothèque", "Plus"], "ordre des onglets");
  // D-223 : l'interrupteur révèle l'onglet Compositions, et le masque à nouveau.
  await page.evaluate(() => document.querySelector("movenso-app").basculerReglage("compositionsBeta"));
  await rendu(page);
  assert.deepEqual(await page.locator(".barre-nav .nav-onglet span").allInnerTexts(), ["Bibliothèque", "Compositions", "Plus"], "l'opt-in révèle l'onglet Compositions (D-223)");
  await page.evaluate(() => document.querySelector("movenso-app").basculerReglage("compositionsBeta"));
  await rendu(page);
  assert.equal(await page.locator(".barre-nav .nav-onglet").count(), 2, "l'opt-out masque l'onglet à nouveau (D-223)");
  // D-084 : par défaut, les outils de curation sont MASQUÉS (mode avancé off)
  await page.locator(".barre-nav .nav-onglet", { hasText: "Plus" }).click();
  await page.waitForSelector(".ecran.plus");
  for (const cache of ["Médias", "Doublons potentiels", "Diagnostic et maintenance"])
    assert.equal(await page.locator(".ligne-menu-titre", { hasText: new RegExp(`^${cache}$`) }).count(), 0, `« ${cache} » doit être masqué hors mode avancé`);
  // D-296 : la GESTION des relations (arbitrages, retraits) n'est plus
  // derrière un drapeau — le rapport d'import y pointe, elle existe pour tous.
  assert.equal(await page.locator(".ligne-menu-titre", { hasText: /^Types de relations$/ }).count(), 1,
    "« Types de relations » est visible sans mode avancé ni bêta (D-296)");
  // D-234 : « Fonctions avancées » est une SECTION à part entière, toujours
  // visible (c'est elle qui allume le reste) — et elle dit ce qui est actif.
  assert.equal(await page.locator(".ligne-menu-titre", { hasText: /^Fonctions avancées$/ }).count(), 1,
    "« Fonctions avancées » a sa propre entrée dans Plus (D-234)");
  await page.locator(".ligne-menu", { hasText: "Fonctions avancées" }).click();
  await page.waitForSelector(".interrupteur");
  assert.equal(await page.locator(".interrupteur").count(), 4,
    "mode avancé + vignettes distantes (S4.3) + les deux bêtas, hors d'Apparence");
  // Le réglage réseau est ÉTEINT à l'arrivée : c'est la promesse « rien ne
  // part sans geste » (D-260), et elle se vérifie ici, sur une installation
  // neuve, pas seulement dans son chapitre dédié.
  assert.equal(
    await page.locator('.interrupteur[aria-checked="true"]').count(), 0,
    "sur une installation neuve, aucun interrupteur avancé n'est actif");
  await page.locator(".interrupteur", { hasText: "Mode avancé" }).click();
  await rendu(page);
  await page.locator('.barre .bouton-icone[aria-label="Retour"]').click();
  await finit(async () => assert.equal(
    await page.locator(".ligne-menu-titre", { hasText: /^Diagnostic et maintenance$/ }).count(), 1,
    "le mode avancé révèle les outils de curation depuis sa nouvelle section"));
  await page.locator(".ligne-menu", { hasText: "Fonctions avancées" }).click();
  await page.waitForSelector(".interrupteur");
  await page.locator(".interrupteur", { hasText: "Mode avancé" }).click();
  await rendu(page);
  await page.locator('.barre .bouton-icone[aria-label="Retour"]').click();
  await rendu(page);
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click();
  await rendu(page);
  // plus de bouton global Capturer (lot 1 §7) ; sur une bibliothèque VIERGE,
  // l'action contextuelle « Ajouter » est MASQUÉE (D-328) : l'écran de
  // première ouverture porte déjà « Créer ta première technique ». Le panneau
  // court se vérifie plus bas, dès qu'il existe un contenu.
  assert.equal(await page.locator(".fab").count(), 0, "aucune action flottante sur une bibliothèque vierge (D-328)");
  // État vide : QUATRE départs nommés (D-311) — le catalogue, un fichier reçu,
  // une sauvegarde à restaurer, ou la bibliothèque vierge. « Importer un pack »
  // seul cachait les deux chemins les plus utiles, dont le retour d'une
  // sauvegarde quand on change d'appareil.
  assert.equal(await page.locator(".action-depart").count(), 4, "quatre départs attendus sur l'état vide (D-311)");
  for (const libelle of ["Installer un pack", "Importer un pack depuis un fichier", "Restaurer une sauvegarde", "Créer ta première technique"])
    assert.equal(await page.locator(".action-depart", { hasText: libelle }).count(), 1, `départ « ${libelle} » attendu`);
  assert.equal(await page.locator(".action-depart .action-picto").count(), 4, "chaque départ porte son picto");
  // D-328 : les quatre départs ne sont plus égaux — un seul est RECOMMANDÉ,
  // et c'est celui qui remplit la bibliothèque en un geste.
  assert.equal(await page.locator(".depart-majeur").count(), 1, "un seul départ recommandé (D-328)");
  assert.ok((await page.locator(".depart-majeur").innerText()).includes("Installer un pack"), "le départ recommandé est le catalogue");
  assert.ok((await page.locator(".depart-majeur").innerText()).includes("connexion requise pour le téléchargement"),
    "la connexion est dite POUR CE QU'ELLE SERT (D-328)");
  // Pictos : des vignettes, jamais un emoji (D-328) ; illustrations fournies
  // par le porteur depuis D-332, donc des images et non plus des tracés.
  assert.equal(await page.locator(".action-depart .action-picto .depart-illu").count(), 4, "chaque départ porte son illustration (D-332)");
  assert.equal((await page.locator(".action-depart .action-picto").allInnerTexts()).join("").trim(), "", "aucun emoji ne subsiste dans les pictos (D-328)");
  // Une illustration qui ne charge pas laisserait une carte muette : on vérifie
  // qu'elles sont RÉELLEMENT décodées, pas seulement présentes dans le DOM.
  assert.equal(
    await page.evaluate(() => [...document.querySelectorAll(".depart-illu")].filter((i) => i.complete && i.naturalWidth > 0).length),
    5,
    "les cinq illustrations (quatre départs + le filet) doivent être chargées (D-332)",
  );
  // D-331 : chaque carte dit qu'elle MÈNE quelque part.
  assert.equal(await page.locator(".action-depart .depart-chevron").count(), 4, "chaque départ porte son chevron (D-331)");
  // D-331 : aucun tiret cadratin dans le texte visible. Règle du porteur —
  // c'est une marque de rédaction machine, et elle n'a rien à faire dans le
  // produit. Une règle sans garde exécutable n'est qu'une consigne (D-253).
  {
    const texte = await page.locator(".ecran-vierge").innerText();
    const fautifs = [...texte].filter((c) => c === "—" || c === "–");
    assert.equal(fautifs.length, 0, `tiret cadratin/demi-cadratin interdit dans le texte visible (D-331) : ${texte}`);
  }
  // le catalogue officiel est joignable dès la première ouverture (il vivait
  // uniquement dans Plus : invisible pour qui découvre l'application)
  await page.locator(".depart-majeur").click();
  await page.waitForSelector(".barre .contexte");
  assert.ok((await page.locator(".barre .contexte").innerText()).includes("Starter packs"), "« Installer un pack » ouvre le catalogue (D-335)");
  await page.click('.barre [aria-label="Retour"], .barre [aria-label="Fermer"]');
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click();
  await rendu(page);
  assert.equal(await page.locator(".action-douce", { hasText: "Créer ta première technique" }).count(), 1, "action « Créer ta première technique » attendue sur l'état vide");
  await page.locator(".action-douce", { hasText: "Créer ta première technique" }).click();
  await page.waitForSelector(".champ-nouveau-nom");
  await page.fill(".champ-nouveau-nom", "Crochet gauche");
  await page.fill(".champ-discipline", "Boxe"); // aucune discipline encore : créée à la volée
  await page.locator(".feuille .actions .bouton.principal", { hasText: "Créer la technique" }).click();
  // D-379 : après création on atterrit sur la fiche NORMALE (état incomplet
  // élégant), pas sur le gros formulaire — « son nom et sa discipline suffisent ».
  await page.locator(".fiche-entete h1", { hasText: "Crochet gauche" }).waitFor();
  assert.equal(await page.locator(".edition").count(), 0, "après création : fiche en LECTURE, pas le formulaire d'édition (D-379)");
  // sans média, un fallback actionnable est offert EN LECTURE — jamais un rectangle vide
  assert.equal(await page.locator(".action-douce", { hasText: "Ajouter un média" }).count(), 1, "fallback média actionnable sur la fiche (D-379)");
  // une note personnelle se pose directement sur la fiche (commentaire toujours visible)
  await page.fill(".commentaire-zone", "Crochet du gauche, coude bas.");
  await page.locator(".commentaire-zone").blur();
  await rendu(page);
  // l'onglet Bibliothèque mène à la racine ; la puce discipline FILTRE la grille (tuning post-V3)
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click();
  await page.waitForSelector(".chip-discipline");
  await page.locator(".chip-discipline", { hasText: "Boxe" }).click();
  assert.equal(await page.locator(".chip-discipline.actif", { hasText: "Boxe" }).count(), 1, "la puce discipline doit devenir un filtre actif (tuning post-V3)");
  assert.ok((await page.locator(".carte-nom").allInnerTexts()).some((t) => t.includes("Crochet gauche")), "la grille filtrée doit montrer la technique de la discipline");
  // La bibliothèque n'est plus vierge : l'action contextuelle « Ajouter »
  // REVIENT sur la racine (lot 4 §2, D-328) — panneau court, fermeture sans effet.
  assert.equal(await page.locator(".fab", { hasText: "Ajouter" }).count(), 1, "action contextuelle « Ajouter » attendue dès qu'un contenu existe (D-328)");
  await page.locator(".fab", { hasText: "Ajouter" }).click();
  await page.waitForSelector(".gestes-ajouter");
  assert.equal(await page.locator(".option-ajouter").count(), 2, "le panneau racine offre deux gestes");
  const textePanneauRacine = (await page.locator(".feuille").innerText()).toLowerCase();
  for (const interdit of ["identité", "contribution", "provenance", "pack", "manifeste"])
    assert.ok(!textePanneauRacine.includes(interdit), `vocabulaire interne « ${interdit} » dans le panneau Ajouter`);
  await page.locator(".voile").click(); // fermeture sans effet (lot 4 §3)
  await finit(async () => assert.equal(await page.locator(".feuille").count(), 0, "le panneau doit se fermer par le voile"));
  // D-071 : « Plus » remplace l'Atelier — un MENU (sections + lignes), jamais
  // d'accordéons ni de tableau de bord. La création de discipline vit dans
  // « Discipline ».
  // D-371 : CINQ groupes, et leur ORDRE est le propos — trois concepts (ce que
  // je possède, ce qui entre et sort, ce qui me protège) puis le confort, puis
  // Movenso. Sauvegardes et Sécurité ne sont plus rangées avec l'échange et
  // les préférences : c'est ce déplacement que ce pin tient.
  await page.locator(".barre-nav .nav-onglet", { hasText: "Plus" }).click();
  await page.waitForSelector(".ecran.plus");
  assert.deepEqual(
    (await page.locator(".menu-section-titre").allInnerTexts()).map((t) => t.trim().toLowerCase()),
    ["organiser ma bibliothèque", "entretenir ma bibliothèque", "packs & partage", "données & sécurité", "préférences", "movenso"],
    "les six groupes du menu Plus, dans l'ordre (Organiser / Entretenir séparés, D-399)",
  );
  assert.deepEqual(
    (await page.locator(".ligne-menu-titre").allInnerTexts()).map((t) => t.trim()),
    ["Disciplines & classement", "Techniques", "Types de relations",
     "À vérifier", "Corbeille",
     "Starter packs", "Importer un pack", "Créer / exporter un pack",
     "Sauvegardes", "Stockage", "Sécurité",
     "Apparence", "Fonctions avancées",
     "Aide & à propos"],
    "les quatorze entrées de Plus, dans l'ordre, hors mode avancé (Organiser puis Entretenir, D-399)",
  );
  // Chaque entrée porte SON illustration : quatorze fichiers, quatorze images
  // distinctes. Deux entrées qui partageraient un dessin se confondraient à
  // l'œil — c'est arrivé en construisant cet écran, et rien ne l'avait dit.
  const sources = await page.locator(".ligne-menu-icone").evaluateAll((n) => n.map((i) => i.getAttribute("src")));
  assert.equal(sources.length, 14, "chaque entrée de Plus porte une illustration");
  assert.equal(new Set(sources).size, 14, "aucune illustration de Plus n'est employée deux fois");
  assert.ok(sources.every((s) => s.startsWith("./img/plus-")), "les illustrations de Plus sont embarquées, aucune ne vient du réseau");
  assert.equal(await page.locator(".ligne-menu", { hasText: "Discipline" }).count(), 1, "la ligne « Discipline » doit exister");
  await page.locator(".ligne-menu", { hasText: "Discipline" }).click();
  await page.waitForSelector(".barre .contexte");
  assert.ok((await page.locator(".barre .contexte").innerText()).includes("Discipline"), "sous-écran « Discipline » attendu");
  // post-V3 : la création est derrière le ＋ de l'encart « Disciplines »
  await revelerCreation(page, "Ajouter dans Disciplines", ".creation-discipline input");
  await page.fill(".creation-discipline input", "Aïkido");
  await page.locator(".creation-discipline .bouton", { hasText: "Créer" }).click();
  await finit(async () => assert.equal(await page.locator('input.chip-gestion[title="Aïkido"]').count(), 1, "la discipline créée doit apparaître dans « Discipline » (D-309 : le nom vit dans le champ de sa ligne)"));
  // mémoire d'onglet (lot 1 §8) : le retour à la Bibliothèque conserve le
  // filtre discipline actif (tuning post-V3 : la puce est un filtre, pas une page)
  await page.locator(".barre-nav .nav-onglet", { hasText: "Bibliothèque" }).click();
  await page.waitForSelector(".chip-discipline");
  assert.equal(await page.locator(".chip-discipline.actif", { hasText: "Boxe" }).count(), 1, "mémoire d'onglet : filtre discipline perdu au retour de Plus");
  // Plus conserve son sous-écran ouvert pendant la session (mémoire d'onglet)
  await page.locator(".barre-nav .nav-onglet", { hasText: "Plus" }).click();
  await page.waitForSelector(".barre .contexte");
  assert.ok(
    (await page.locator(".barre .contexte").innerText()).includes("Discipline"),
    "Plus doit conserver son sous-écran pendant la session",
  );
  await page.locator(".barre-nav .nav-onglet", { hasText: "Bibliothèque" }).click(); // retour → grille filtrée Boxe (mémoire)
  await page.waitForSelector(".chip-discipline");
  await page.locator(".barre-nav .nav-onglet", { hasText: "Bibliothèque" }).click(); // second appui : racine
  await page.waitForSelector(".chip-discipline");
  assert.equal(await page.locator(".chip-discipline").count(), 2, "deux disciplines créées de zéro");
  // fermeture 1 (D-023) + lot 2 §11 : discipline vide = état spécifique, deux actions, aucune impasse
  await ouvrirDisc(page, "Aïkido");
  await page.waitForSelector(".discipline-vide");
  assert.ok((await page.locator(".discipline-vide").innerText()).includes("ne contient encore aucune technique"), "état vide de discipline inexplicite");
  assert.equal(await page.locator(".discipline-vide .action-douce", { hasText: "Importer" }).count(), 1, "action Importer absente de la discipline vide");
  await page.locator(".discipline-vide .bouton.principal", { hasText: "Créer la première technique" }).click();
  await page.fill(".actions-bibliotheque .creation-discipline input", "Ikkyo");
  await page.click(".actions-bibliotheque .creation-discipline .bouton");
  await page.locator(".fiche-entete h1", { hasText: "Ikkyo" }).waitFor(); // D-379 : fiche en LECTURE, pas le formulaire
  // D-337 : une fiche NEUVE n'a ni description ni points clés. Les sections
  // restent affichées avec leur invitation — une section qui disparaît laisse
  // croire que la fiche est complète. Vérifié ici parce que c'est le seul
  // endroit du parcours où une fiche est réellement vide.
  // (les titres sont mis en capitales par le CSS — on compare le sens, pas la casse)
  const titresVides = (await page.locator(".bloc-lecture .section-titre").allInnerTexts()).map((x) => x.toLowerCase());
  assert.ok(titresVides.includes("description"), "la section Description doit rester : " + titresVides.join(" | "));
  assert.ok(titresVides.includes("points clés"), "la section Points clés doit rester : " + titresVides.join(" | "));
  assert.equal(
    await page.locator(".bloc-lecture .section-vide").count(), 2,
    "chacune des deux sections vides doit porter son invitation",
  );
  assert.ok(
    (await page.locator(".bloc-lecture .section-vide").first().innerText()).includes("crayon"),
    "l'invitation doit dire PAR OÙ on remplit, sans nommer un mode « édition »",
  );
  await page.locator('.barre [aria-label="Retour"]').click(); // retour (pile) → explorateur Aïkido
  await page.locator(".carte-nom", { hasText: "Ikkyo" }).waitFor();

  // lot 4 §7.A (boucle 4.3) : la recherche de rattachement est CADRÉE à la
  // discipline présélectionnée, et s'élargit sur demande explicite
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // → racine Bibliothèque
  await page.waitForSelector(".chip-discipline");
  await ouvrirDisc(page, "Boxe"); // écran discipline : la capture y est cadrée sur Boxe
  await page.locator(".fab", { hasText: "Ajouter" }).click();
  await gesteCapture(page, "note");
  await page.fill(".champ-note", "Vu au stage — à ranger côté aïkido.");
  await page.click(".feuille .actions .bouton.principal");
  await page.fill(".feuille .recherche input", "ikkyo");
  await finit(async () => assert.equal(await page.locator(".feuille .resultat:not(.creer)").count(), 0, "la recherche doit d'abord rester cadrée à Boxe"));
  assert.ok((await page.locator(".feuille .fil-vide").innerText()).includes("dans Boxe"), "le cadre de la recherche doit être nommé");
  await page.locator(".feuille .action-douce", { hasText: "toutes les disciplines" }).click();
  await rendu(page);
  await page.locator(".feuille .resultat", { hasText: "Ikkyo" }).first().click();
  await page.locator(".fiche-entete h1", { hasText: "Ikkyo" }).waitFor();

  // lot 4 §6.B (boucle 4.3) : une vidéo choisie passe par l'APERÇU —
  // Utiliser / Choisir un autre fichier / Abandonner ; rien d'écrit avant la fin
  const miniVideo = join(tmpdir(), "movenso-mini-video.webm");
  writeFileSync(miniVideo, Buffer.alloc(2048, 7));
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // racine
  await page.waitForSelector(".chip-discipline");
  await ouvrirDisc(page, "Boxe"); // écran discipline : contexte de création présélectionné
  await page.locator(".fab", { hasText: "Ajouter" }).click();
  await page.locator(".option-ajouter", { hasText: "Capture rapide" }).click();
  await page.waitForSelector(".choix-double");
  const [choixVideo] = await Promise.all([
    page.waitForEvent("filechooser"),
    page.locator(".choix-secondaire .action-douce", { hasText: "Ajouter une vidéo existante" }).click(),
  ]);
  await choixVideo.setFiles(miniVideo);
  await page.waitForSelector(".feuille .media-video video");
  assert.ok((await page.locator(".apercu-infos").innerText()).includes("rien n'est encore enregistré"), "l'aperçu doit dire que rien n'est enregistré");
  assert.ok((await page.locator(".feuille .actions").innerText()).includes("Choisir un autre fichier"), "l'alternative au fichier choisi doit exister");
  await page.locator(".feuille .actions .bouton.principal", { hasText: "Utiliser" }).click();
  await finit(async () => assert.ok((await page.locator(".feuille").innerText()).includes("vidéo jointe"), "après Utiliser, la note doit porter la vidéo"));
  await page.locator(".feuille .actions .bouton", { hasText: "Annuler" }).click(); // rien n'est écrit
  await finit(async () => assert.equal(await page.locator(".feuille").count(), 0, "annuler ferme la capture sans rien créer"));

  // scénario D du lot 4 : créer une technique DEPUIS une capture vidéo —
  // parcours atomique : capture → nouvelle technique → rattachement → fiche
  await page.locator(".fab", { hasText: "Ajouter" }).click();
  await page.locator(".option-ajouter", { hasText: "Capture rapide" }).click();
  await page.waitForSelector(".choix-double");
  const [choixVideo2] = await Promise.all([
    page.waitForEvent("filechooser"),
    page.locator(".choix-secondaire .action-douce", { hasText: "Ajouter une vidéo existante" }).click(),
  ]);
  await choixVideo2.setFiles(miniVideo);
  await page.waitForSelector(".feuille .media-video video");
  await page.locator(".feuille .actions .bouton.principal", { hasText: "Utiliser" }).click();
  await page.fill(".champ-note", "Technique inconnue vue en sparring.");
  await page.click(".feuille .actions .bouton.principal"); // → sais-tu où le ranger ?
  await page.fill(".feuille .champ-nouveau-nom", "Uppercut");
  await rendu(page);
  await page.locator(".resultat.creer").click();
  await page.locator(".fiche-entete h1", { hasText: "Uppercut" }).waitFor();
  assert.ok((await page.locator("movenso-video-locale").count()) >= 1, "la vidéo capturée doit vivre sur la fiche créée");
  await page.click(".barre [aria-label=\"Fermer\"], .barre [aria-label=\"Retour\"]"); // retour → explorateur Boxe
  await page.locator(".carte-nom", { hasText: "Uppercut" }).waitFor(); // visible dans la grille

  // lot 6 §5-7 (boucle 6.2, scénario B) : gestion des disciplines dans Plus
  await ouvrirPlus(page, "Disciplines & classement");
  // créer Karaté (nom seul) — création derrière le ＋ de l'encart Disciplines
  await revelerCreation(page, "Ajouter dans Disciplines", ".creation-discipline input");
  await page.fill(".creation-discipline input", "Karaté");
  await page.click(".creation-discipline .bouton");
  await rendu(page);
  // On CHOISIT la discipline dans la rangée de puces (V2, D-072) ; la carte de
  // gestion qui s'affichait sous la rangée a été RETIRÉE par D-309, et la
  // sélection se voit désormais au liseré de la puce active (D-346).
  // D-309 : le nom s'édite EN LIGNE — la « puce » est un champ ; sa valeur
  // porte le nom. D-413 : **cliquer** la puce choisit la discipline ; y arriver
  // au CLAVIER ne choisit plus rien (WCAG 3.2.1 « On Focus »).
  const champDiscipline = (nom) => page.locator(`input.chip-gestion[title="${nom}"]`);
  const valeursGestion = () => page.locator(".chip-gestion").evaluateAll((els) => els.map((e) => e.value));
  const selGestion = async (nom) => { await champDiscipline(nom).click(); await rendu(page); };
  await selGestion("Karaté");
  // Les compteurs par discipline ont été RETIRÉS de cet écran par D-309, avec
  // l'assertion qui les vérifiait : ce commentaire décrivait un écran disparu
  // (verdict checker, D-348). La notion de « sources » l'avait quitté avant.
  // renommer → Karaté Shotokan : édition EN LIGNE dans le champ de la rangée
  // (D-309 : l'encart dédié a disparu) ; blur déclenche @change → majNomDiscipline.
  await champDiscipline("Karaté").fill("Karaté Shotokan");
  await champDiscipline("Karaté").blur();
  await rendu(page);
  assert.equal(await champDiscipline("Karaté Shotokan").count(), 1, "le renommage doit s'appliquer");
  await selGestion("Karaté Shotokan");
  // D-413 — LE FOCUS NE CHOISIT PLUS. Traverser la rangée au clavier
  // réaffectait `disciplineGestion`, donc le contenu des deux volets rendus
  // dessous : un changement de contexte au focus. Mesuré ici sur le liseré de
  // la puce active, dans les deux sens — le focus ne bouge rien, Entrée choisit.
  const disciplineAffichee = () => page.locator(".chips-disciplines .chip-glissable.actif .chip-gestion")
    .evaluate((e) => e.value);
  await finit(async () => assert.equal(await disciplineAffichee(), "Karaté Shotokan", "la puce cliquée est bien celle qui est affichée"));
  await champDiscipline("Aïkido").focus();
  await rendu(page);
  await finit(async () => assert.equal(await disciplineAffichee(), "Karaté Shotokan",
    "le FOCUS sur une autre discipline ne doit RIEN changer (WCAG 3.2.1 On Focus, D-413)"));
  await champDiscipline("Aïkido").press("Enter");
  await rendu(page);
  await finit(async () => assert.equal(await disciplineAffichee(), "Aïkido",
    "…mais Entrée, geste explicite, choisit bien la discipline (D-413)"));
  // D-416 — NI À LA SOURIS. Le @click posé sur la puce ENTIÈRE était hérité par
  // les ▲/▼ et la ✕ (aucun arrêt de propagation) : réordonner la troisième
  // discipline réaffectait le contexte, soit le changement non demandé retiré
  // au clavier, réintroduit au pointeur. Le geste vit sur le CHAMP.
  await page.locator('[aria-label="Monter Karaté Shotokan"]').click();
  await rendu(page);
  await finit(async () => assert.equal(await disciplineAffichee(), "Aïkido",
    "le ▲ réordonne SANS changer la discipline affichée (D-416)"));
  await page.locator('[aria-label="Descendre Karaté Shotokan"]').click();
  await rendu(page);
  await selGestion("Karaté Shotokan");
  // D-233 : le glisser-déposer a été RETIRÉ — les flèches ▲/▼ sont le seul
  // mécanisme de réordonnancement, ici comme partout.
  assert.equal(await page.locator(".poignee-glisser").count(), 0, "plus aucune poignée de glisser (D-233)");
  await page.locator('[aria-label="Monter Karaté Shotokan"]').click();
  await finit(async () => assert.deepEqual(await valeursGestion(), ["Boxe", "Karaté Shotokan", "Aïkido"], "le bouton ▲ doit monter la discipline d'un cran (S2.9)"));
  await page.locator('[aria-label="Monter Karaté Shotokan"]').click();
  await finit(async () => assert.deepEqual(await valeursGestion(), ["Karaté Shotokan", "Boxe", "Aïkido"], "…et encore d'un cran, jusqu'en tête"));
  await finit(async () => assert.ok(
    ((await page.locator(".annonce-lecteur[role=status]").textContent()) ?? "").includes("position 1 sur 3"),
    "le déplacement doit être annoncé aux lecteurs d'écran (aria-live) (S2.9)",
  ));
  // …et retour d'un cran par ▼ (ce sont des boutons : doigt, clavier, TalkBack)
  await page.locator('[aria-label="Descendre Karaté Shotokan"]').click();
  await finit(async () => assert.deepEqual(await valeursGestion(), ["Boxe", "Karaté Shotokan", "Aïkido"], "le bouton ▼ doit redescendre d'un cran (S2.9)"));
  // en butée : pas de déplacement, annonce honnête
  await page.locator('[aria-label="Monter Boxe"]').isDisabled().then((d) => assert.ok(d, "▲ doit être désactivé en première position (S2.9)"));
  // retirer la discipline vide : la ✕ de sa ligne déclenche directement la confirmation (D-308)
  // D-416 — LA ✕ NE CHOISIT PAS non plus. Le @click posé sur la puce ENTIÈRE
  // était hérité par la ✕ (aucun arrêt de propagation) : ouvrir la confirmation
  // de suppression réaffectait la discipline affichée, donc le contenu des deux
  // volets rendus dessous. Mesuré : « Boxe » devenait « Karaté Shotokan ».
  const avantSuppression = await disciplineAffichee();
  await page.locator('[aria-label="Supprimer « Karaté Shotokan »"]').click();
  await rendu(page);
  await finit(async () => assert.equal(await disciplineAffichee(), avantSuppression,
    "ouvrir la confirmation de suppression ne doit PAS changer la discipline affichée (D-416)"));
  await page.waitForSelector(".feuille-confirmation"); // C2 : feuille nommée
  await page.locator(".feuille-confirmation .bouton.danger").click();
  await finit(async () => assert.equal(await champDiscipline("Karaté Shotokan").count(), 0, "la discipline vide doit se retirer"));
  // discipline NON vide : jamais un clic — la ✕ ouvre directement le récap
  // guardé sous la carte de la discipline, qu'elle sélectionne d'office (D-308)
  await page.locator('[aria-label="Supprimer « Boxe »"]').click();
  await page.waitForSelector(".suppression-discipline");
  const recap = await page.locator(".suppression-discipline").innerText();
  assert.ok(recap.includes("2 techniques"), "le récap doit compter les techniques : " + recap);
  assert.ok(/point de restauration/i.test(recap), "le récap doit nommer le point de restauration (D-099 : plus de « snapshot »)");
  assert.ok(recap.includes("à rattacher"), "le récap doit dire que les notes personnelles survivent");
  // annuler : rien ne change
  await page.locator(".suppression-discipline .chip-filtre", { hasText: "Annuler" }).click();
  await finit(async () => assert.equal(await page.locator(".suppression-discipline").count(), 0, "annuler referme la préparation"));
  assert.equal(await champDiscipline("Boxe").count(), 1, "annuler ne supprime rien");
  // suppression réelle avec confirmation renforcée : les notes personnelles
  // reviennent « à rattacher », l'autre discipline ne bouge pas
  await page.locator('[aria-label="Supprimer « Boxe »"]').click();
  await page.waitForSelector(".suppression-discipline");
  await page.locator(".suppression-discipline .action-danger", { hasText: "Supprimer la discipline" }).click();
  await page.waitForSelector(".feuille-confirmation");
  await page.locator(".feuille-confirmation .bouton.danger").click();
  await page.waitForTimeout(lent(300));
  assert.equal(await champDiscipline("Boxe").count(), 0, "la discipline supprimée doit disparaître de Plus");
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click();
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // second appui : racine
  await page.waitForSelector(".chip-discipline");
  assert.equal(await page.locator(".chip-discipline").count(), 1, "seule Aïkido doit rester");
  // D-071 : les notes personnelles de Boxe reviennent « à rattacher » — désormais
  // dans Plus › Médias, en kpi « Captures à rattacher »
  await ouvrirPlus(page, "À vérifier");
  {
    const kpi = page.locator(".kpi").filter({ has: page.locator(".kpi-libelle", { hasText: "Captures à rattacher" }) });
    assert.ok(Number(await kpi.locator(".kpi-nombre").innerText()) >= 2, "les notes personnelles de Boxe doivent revenir « à rattacher »");
  }

  // lot 6 §8 (boucle 6.3, scénario C) : taxonomies — créer, ordonner,
  // utiliser, puis supprimer AVEC arbitrage (usages visibles, remplacer /
  // retirer la classification / annuler — jamais de référence invalide)
  await ouvrirPlus(page, "Disciplines & classement");
  const carteAikido = () => page.locator(".carte-discipline").filter({ hasText: "Aïkido" }).first();
  // tuning post-V3 : Catégories et Niveaux sont des sections DÉDIÉES, visibles
  // seulement après avoir choisi une discipline (« Toutes » les masque). « Familles »
  // est devenu « Catégories » (plus de <details> à déplier).
  await selGestion("Aïkido");
  const lignesFamilles = () => page.locator('input[aria-label="Nom de la catégorie"]');
  // création derrière le ＋ de l'encart Catégories (post-V3). Créer AUTO-FERME
  // le petit formulaire : on ré-ouvre le ＋ avant chaque ajout.
  for (const nom of ["Immobilisations", "Projections"]) {
    await ouvrirCreationSection(page, "Catégories", "Ajouter une catégorie", 'input[placeholder="Nom de la catégorie"]');
    await page.locator('input[placeholder="Nom de la catégorie"]').fill(nom);
    await page.locator('input[placeholder="Nom de la catégorie"]').press("Enter");
    await rendu(page);
  }
  // D-233 : réordonnancement des catégories par les seules flèches (aller-retour)
  const carteCategories = () => page.locator(".carte-atelier").filter({ has: page.locator(".titre-atelier", { hasText: "Catégories" }) });
  await carteCategories().locator('[aria-label="Monter Projections"]').click();
  await finit(async () => assert.deepEqual(
    await lignesFamilles().evaluateAll((els) => els.map((e) => e.value)),
    ["Projections", "Immobilisations"],
    "le bouton ▲ doit monter la catégorie d'un cran (S2.9)",
  ));
  await carteCategories().locator('[aria-label="Descendre Projections"]').click();
  await finit(async () => assert.deepEqual(
    await lignesFamilles().evaluateAll((els) => els.map((e) => e.value)),
    ["Immobilisations", "Projections"],
    "le bouton ▼ doit descendre la catégorie d'un cran (S2.9)",
  ));
  await carteCategories().locator('[aria-label="Monter Projections"]').click();
  await finit(async () => assert.deepEqual(
    await lignesFamilles().evaluateAll((els) => els.map((e) => e.value)),
    ["Projections", "Immobilisations"],
    "et retour à l'ordre de départ",
  ));
  // création d'un niveau derrière le ＋ de l'encart Niveaux (post-V3)
  await ouvrirCreationSection(page, "Niveaux", "Ajouter un niveau", 'input[placeholder="Nom du niveau"]');
  await page.locator('input[placeholder="Nom du niveau"]').fill("5e kyu");
  await page.locator('input[placeholder="Nom du niveau"]').press("Enter");
  await rendu(page);
  // classer Ikkyo avec la famille et le niveau
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click();
  await page.locator(".chip-discipline", { hasText: "Aïkido" }).click();
  await page.locator(".carte-technique", { hasText: "Ikkyo" }).first().click();
  await page.waitForSelector(".fiche-entete h1");
  await page.locator('.fab-fiche').click();
  await page.waitForSelector(".edition");
  await page.selectOption("#champ-categorie", { label: "Projections" }); // catégorie = menu déroulant
  await page.locator(".niveau-coche", { hasText: "5e kyu" }).locator("input").check(); // niveaux = cases à cocher
  await rendu(page);
  await page.locator('.fiche-actions [aria-label="Enregistrer"]').click();
  await finit(async () => assert.ok((await page.locator(".fiche-famille").innerText()).toLowerCase().includes("projections"), "la famille doit se voir sur la fiche"));
  // suppression d'une famille UTILISÉE : arbitrage, jamais un simple confirm
  await ouvrirPlus(page, "Disciplines & classement");
  await selGestion("Aïkido");
  await ouvrirSection(page, "Catégories");
  await page.locator('[aria-label="Retirer la catégorie"]').first().click(); // Projections (1re)
  await page.waitForSelector(".suppression-taxonomie");
  const arbitrage = await page.locator(".suppression-taxonomie").innerText();
  assert.ok(arbitrage.includes("1 technique") && arbitrage.includes("Ikkyo"), "l'arbitrage doit montrer les usages : " + arbitrage);
  await page.locator(".suppression-taxonomie .chip-filtre", { hasText: "Annuler" }).click();
  await finit(async () => assert.equal(await page.locator(".suppression-taxonomie").count(), 0, "annuler referme l'arbitrage"));
  assert.deepEqual(await lignesFamilles().evaluateAll((els) => els.map((e) => e.value)), ["Projections", "Immobilisations"], "annuler ne supprime rien");
  // remplacer : les fiches sont reclassées, la valeur disparaît
  await page.locator('[aria-label="Retirer la catégorie"]').first().click();
  await page.locator(".suppression-taxonomie .chip-filtre", { hasText: "Remplacer par « Immobilisations »" }).click();
  await finit(async () =>
    assert.deepEqual(await lignesFamilles().evaluateAll((els) => els.map((e) => e.value)), ["Immobilisations"], "la famille remplacée doit disparaître"));
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // mémoire : fiche Ikkyo
  await page.waitForSelector(".fiche-famille");
  assert.ok((await page.locator(".fiche-famille").innerText()).toLowerCase().includes("immobilisations"), "la fiche doit être reclassée vers la valeur de remplacement");
  // niveau utilisé : « retirer la classification » — la fiche reste intègre
  await ouvrirPlus(page, "Disciplines & classement");
  await selGestion("Aïkido");
  await ouvrirSection(page, "Niveaux");
  await page.locator('[aria-label="Retirer le niveau"]').first().click();
  await page.waitForSelector(".suppression-taxonomie");
  await page.locator(".suppression-taxonomie .action-danger", { hasText: "Retirer la classification" }).click();
  await rendu(page);
  await page.locator(".barre-nav .nav-onglet:nth-child(1)").click(); // fiche Ikkyo
  await page.waitForSelector(".fiche-entete h1");
  const ficheApres = await page.locator(".ecran").innerText();
  assert.ok(!ficheApres.includes("5e kyu"), "le niveau supprimé ne doit plus apparaître sur la fiche");
  assert.ok(ficheApres.toLowerCase().includes("immobilisations"), "la famille de remplacement doit rester");

  /* ---- D-224 : fiche SANS vidéo mais AVEC illustration — la couverture prend
     la place du média, l'invitation à ajouter reste (compacte et honnête). ---- */
  assert.equal(await page.locator(".media-absent").count(), 1, "témoin : sans couverture, le bloc « aucun média » est là");
  // La couverture se pose par le GESTE du produit (D-269 : elle devient un
  // fichier, et l'inventaire la déclare) — jamais en écrivant le champ à la
  // main, ce qui prouverait un chemin que personne n'emprunte.
  await page.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const t = app.bibliotheque.techniques.find((x) => x.nom === "Ikkyo");
    const gif = "R0lGODlhAQABAIAAAP7urwAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==";
    const octets = Uint8Array.from(atob(gif), (c) => c.charCodeAt(0));
    await app.definirCouvertureImage(t.id, new File([octets], "vignette.gif", { type: "image/gif" }));
  });
  await rendu(page);
  assert.equal(await page.locator(".couverture-fiche").count(), 1, "l'illustration s'affiche en tête de fiche (D-224)");
  /* ---- D-372 : PARTAGER une fiche ILLUSTRÉE. Le geste le plus banal, et il
     était cassé en production — l'extrait n'emportait pas l'inventaire des
     images, donc la validation refusait « l'image … n'est déclarée nulle part
     dans l'inventaire ». Ce pin se joue ICI, juste après la pose de la
     couverture, parce que c'est le seul endroit du parcours où une fiche EST
     illustrée : sans couverture, le partage passait, et c'est bien pour ça que
     rien ne l'avait vu. ---- */
  await page.evaluate(() => { document.querySelector("movenso-app").toast = null; });
  await page.locator('button[aria-label="Partager"]').first().click();
  // Le toast s'EFFACE seul après 3,4 s : la boucle d'attente ne sert qu'à
  // guetter son APPARITION, et le verdict se prononce dehors. Écrit d'abord
  // avec les deux assertions DANS la boucle, il expirait sur « aucun toast »
  // alors qu'un toast d'échec était bien passé — un rouge obtenu pour la
  // mauvaise raison, ce qui vaut à peine mieux qu'un vert (D-249).
  const reponse = await finit(async () => {
    const t = await page.evaluate(() => document.querySelector("movenso-app").toast);
    assert.ok(t, "partager une fiche illustrée répond quelque chose — le silence serait un défaut");
    return t;
  }, 6000);
  assert.ok(!/impossible/i.test(reponse), `partager une fiche illustrée ABOUTIT (réponse reçue : « ${reponse} »)`);
  assert.equal(await page.locator(".media-absent").count(), 0, "le bloc « aucun média » s'efface devant l'illustration");
  assert.ok((await page.locator(".couverture-fiche-pied").innerText()).includes("aucune vidéo"), "l'honnêteté reste dite : « aucune vidéo pour l'instant »");
  await page.locator(".couverture-fiche-pied .chip-filtre", { hasText: "Ajouter un média" }).click();
  await page.waitForSelector(".feuille");
  assert.ok((await page.locator(".feuille").innerText()).toLowerCase().includes("média"), "le CTA compact ouvre bien l'ajout de média");
}
await ctxA.close();
}
