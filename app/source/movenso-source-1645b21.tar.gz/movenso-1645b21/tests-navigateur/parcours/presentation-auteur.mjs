/**
 * CHAPITRE e2e (D-420) — le pratiquant rédige la présentation de SA technique.
 *
 * Le défaut d'origine : une technique créée À LA MAIN n'a aucune contribution ;
 * la fiche liait Description/Points clés à une contribution non personnelle
 * (`presentation`), donc en ÉDITION elle n'affichait qu'une invitation morte —
 * aucun champ où écrire, même le crayon en main. Ce chapitre prouve le chemin
 * réel : créer une technique, l'éditer, écrire une description, la revoir.
 *
 * Les DEUX moitiés du contrat (D-251) sont tenues ici :
 *   - la Description devient éditable et crée une contribution d'AUTEUR ;
 *   - le Commentaire (note personnelle) reste DISTINCT — écrire l'un ne
 *     touche pas l'autre.
 */
import assert from "node:assert/strict";
import { surveiller, navigateur, rendu, finit } from "../harnais.mjs";

export async function run() {
  const ctx = await navigateur.newContext({ viewport: { width: 420, height: 800 } });
  const p = await ctx.newPage();
  surveiller(p);
  await p.goto("http://localhost:4517/");
  await p.waitForSelector(".action-douce");

  // Création MANUELLE : discipline + technique, sans capture ni pack → aucune
  // contribution. C'est exactement le cas qui n'était pas éditable.
  const id = await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const d = await app.creerDiscipline("Judo");
    await app.creerTechnique(d, "Uchi-mata");
    const t = app.bibliotheque.techniques.find((x) => x.nom === "Uchi-mata");
    app.ouvrirFiche(t.id);
    await app.updateComplete;
    return t.id;
  });

  // On entre en édition — SANS pseudo encore renseigné.
  await p.evaluate((tid) => document.querySelector("movenso-app").entrerEditionFiche(tid), id);
  await rendu(p);

  // LE CORRECTIF : le champ Description existe en édition (avant, il n'y avait
  // qu'une invitation non éditable). C'est la ligne qui rougit sans le correctif.
  await p.waitForSelector('textarea[aria-label="Description"]', { timeout: 5000 });
  assert.equal(await p.locator(".rappel-pseudo").count(), 1, "sans pseudo, le rappel « signe ton travail » est présent");

  // Le pratiquant écrit sa description (change = perte de focus).
  await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const zone = document.querySelector('textarea[aria-label="Description"]');
    zone.value = "Ma description perso";
    zone.dispatchEvent(new Event("change", { bubbles: true }));
    await app.updateComplete;
  });
  await rendu(p);

  const etat = () => p.evaluate((tid) => {
    const app = document.querySelector("movenso-app");
    const contribs = app.bibliotheque.contributions.filter((c) => c.techniqueId === tid);
    const auteur = contribs.find((c) => c.provenance === "auteur");
    const perso = contribs.find((c) => c.provenance === "personnel");
    return {
      nbContribs: contribs.length,
      descAuteur: auteur?.description ?? null,
      provAuteur: auteur?.provenance ?? null,
      attribution: auteur?.attribution ?? null,
      carnet: perso?.description ?? null,
    };
  }, id);

  await finit(async () => {
    const e = await etat();
    assert.equal(e.descAuteur, "Ma description perso", "la description saisie crée une contribution d'auteur");
    assert.equal(e.provAuteur, "auteur", "la contribution rédigée est de provenance 'auteur'");
    assert.equal(e.attribution, null, "sans pseudo, pas d'attribution imposée localement");
    assert.equal(e.carnet, null, "voisin (D-251) : le Commentaire reste vide — rédiger la description ne le touche pas");
  });

  // On sort d'édition : la description s'affiche en lecture (plus d'invitation).
  await p.evaluate(() => document.querySelector("movenso-app").validerEditionFiche());
  await rendu(p);
  assert.equal(await p.locator("section.bloc-lecture p").filter({ hasText: "Ma description perso" }).count(), 1,
    "en lecture, la description rédigée s'affiche");

  // L'AUTRE VOISIN : le Commentaire personnel reste un champ à part et
  // s'enregistre bien, sans se confondre avec la description d'auteur.
  await p.evaluate((tid) => document.querySelector("movenso-app").entrerEditionFiche(tid), id);
  await rendu(p);
  await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const zone = document.querySelector(".commentaire-zone");
    zone.value = "Ma note privée";
    zone.dispatchEvent(new Event("change", { bubbles: true }));
    await app.updateComplete;
  });
  await finit(async () => {
    const e = await etat();
    assert.equal(e.carnet, "Ma note privée", "le Commentaire s'enregistre comme note personnelle");
    assert.equal(e.descAuteur, "Ma description perso", "et n'écrase pas la description d'auteur");
  });

  // Avec un pseudo, une nouvelle contribution d'auteur est SIGNÉE, et le rappel disparaît.
  const id2 = await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    app.validerEditionFiche();
    await app.changerPseudo("Alice");
    const d = app.bibliotheque.disciplines[0];
    await app.creerTechnique(d.id, "Seoi-nage");
    const t = app.bibliotheque.techniques.find((x) => x.nom === "Seoi-nage");
    app.ouvrirFiche(t.id);
    app.entrerEditionFiche(t.id);
    await app.updateComplete;
    return t.id;
  });
  await rendu(p);
  assert.equal(await p.locator(".rappel-pseudo").count(), 0, "avec un pseudo, le rappel ne s'affiche plus");
  await p.evaluate(async () => {
    const app = document.querySelector("movenso-app");
    const zone = document.querySelector('textarea[aria-label="Description"]');
    zone.value = "Décrite par Alice";
    zone.dispatchEvent(new Event("change", { bubbles: true }));
    await app.updateComplete;
  });
  await finit(async () => {
    const signee = await p.evaluate((tid) => {
      const app = document.querySelector("movenso-app");
      return app.bibliotheque.contributions.find((c) => c.techniqueId === tid && c.provenance === "auteur")?.attribution ?? null;
    }, id2);
    assert.equal(signee, "Alice", "avec un pseudo, la contribution d'auteur est signée");
  });

  await ctx.close();
}
