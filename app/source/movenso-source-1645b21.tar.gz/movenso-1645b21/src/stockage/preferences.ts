/**
 * PRÉFÉRENCES D'APPAREIL (D-020.4) — hors bibliothèque, et c'est tout le sujet :
 * elles ne voyagent JAMAIS dans un pack, un export ou une sauvegarde. C'est
 * l'appareil qui choisit, pas le savoir.
 *
 * Sorties de `opfs.ts` (audit externe du 2026-08-21) : le fichier des
 * transactions d'état n'avait aucune raison de porter aussi le catalogue des
 * réglages. Deux cycles distincts (D-251) : l'état métier passe par la bascule
 * protégée et la file d'écriture, un réglage s'écrit à plat et se reperd sans
 * conséquence. La lecture reste chez `StockageOpfs` — c'est elle qui touche le
 * disque ; ici vivent la FORME et sa migration, pures et testables en Node.
 */

export interface Preferences {
  version: 1;
  /** Comportement de démarrage (lot 1 §3) : la Bibliothèque par défaut,
   *  la dernière discipline consultée, ou une discipline choisie. */
  demarrage: { mode: "bibliotheque" | "compositions" | "relations" | "derniere" | "discipline"; disciplineId?: string };
  derniereDisciplineId?: string;
  /** Apparence (D-025) : thème et tonalité d'accent — choix d'appareil. */
  theme?: "auto" | "clair" | "sombre";
  tonalite?: "vermillon" | "indigo" | "foret" | "ocre" | "prune" | "acier";
  /** Pseudo local (D-072) : signe le contenu créé sur cet appareil (« Mon
   *  contenu » → le pseudo). Réglage d'appareil — jamais exporté. */
  pseudo?: string;
  /** Mode avancé (D-084) : révèle les outils de curation/maintenance (doublons,
   *  relations, médias, diagnostic) — masqués par défaut pour garder la surface
   *  du pratiquant sobre. Réglage d'appareil, off par défaut. */
  modeAvance?: boolean;
  /** Vignettes distantes (S4.3/D-260) : quand une fiche n'a pas d'illustration
   *  locale, on PEUT afficher la miniature fournie par YouTube — ce qui
   *  suppose de contacter un tiers SANS que l'utilisateur l'ait demandé.
   *  **Off par défaut** : la promesse « rien ne part sans geste » prime sur
   *  la richesse visuelle. Réglage d'appareil, jamais exporté. */
  vignettesDistantes?: boolean;
  /** Vue relation en bêta (D-084) : quand active, le bouton « Voir en graphe »
   *  apparaît sur les fiches. Remplace l'ancien onglet permanent. Off par défaut. */
  vueRelationBeta?: boolean;
  /** Compositions en bêta (D-223) : quand actif, l'onglet Compositions et ses
   *  points d'entrée apparaissent. Off par défaut — la CAPACITÉ reste entière
   *  (données, packs, sauvegardes), seule la visibilité est optionnelle. */
  compositionsBeta?: boolean;
  /** Écran Relations (D-137) — réglage d'APPAREIL, jamais exporté : centre,
   *  onglet et disposition restaurés entre sessions (absents = point de départ). */
  relationsCentreId?: string;
  relationsVue?: "liste" | "mindmap" | "explorer"; // D-383 : trois onglets ; un ancien « classique » persisté se replie sur Graphe/structure à la lecture.
  relationsDisposition?: "structure" | "reseau"; // D-383 : disposition du Graphe (radial / pan-zoom), réglage d'appareil, absent = défaut responsive.
  /** Densité de la grille Bibliothèque (D-087) : nombre de colonnes choisi
   *  (1 à 4). Absent = grille responsive par défaut. Réglage d'appareil. */
  densiteBibliotheque?: number;
  /** Limite d'espace volontaire pour les vidéos locales (D-097), en Mo.
   *  Absent = défaut 5 Go. `0` = illimité (plafonné seulement par le quota
   *  système). Réglage d'appareil, jamais exporté. */
  limiteEspaceMo?: number;
  /** Transition de préparation avant un pas minuté dans le pas-à-pas (D-125),
   *  en secondes. Absent = défaut 3 s ; `0` = aucune. Réglage d'appareil. */
  transitionSec?: number;
  /** Retour sonore du pas-à-pas (D-125) : voix + bips (défaut), voix seule,
   *  bips seuls, ou muet. Réglage d'appareil. */
  sonSeance?: "les-deux" | "voix" | "bips" | "muet";
  /** Dernière position de lecture (UI-6, D-324) — **UNE** entrée, écrite par le
   *  lecteur sans geste de l'utilisateur. Vivant ici, elle ne voyage ni dans un
   *  pack ni dans une sauvegarde (D-020.4) : on ne restaure pas une position, on
   *  reprend la séance. Cycle complet dans D-324. */
  derniereLecture?: { compositionId: string; index: number; quand: string };
  /** Protections facultatives (lot 7) — réglage d'APPAREIL : jamais
   *  exporté (les préférences ne voyagent dans aucune sauvegarde), le PIN
   *  n'existe que dérivé (sel + empreinte PBKDF2, src/securite/pin.ts). */
  protections?: {
    modifications: boolean;
    suppressions: boolean;
    /** Durée de la session curateur (§8) — 5 min par défaut. */
    verrouillage?: "5min" | "15min" | "arriere-plan";
    verification?: import("../securite/pin.ts").VerificationPin;
  };
}

export function preferencesDefaut(): Preferences {
  return { version: 1, demarrage: { mode: "bibliotheque" } };
}

/** Migration des préférences (lot 1 §2-3) — pure, testable en Node.
 *  « accueil » et « favoris » (D-336) visent des écrans SUPPRIMÉS : y pointer
 *  ouvrirait l'app sur du vide. Inconnu ou illisible → défauts. */
export function migrerPreferences(brut: unknown): Preferences {
  if (typeof brut !== "object" || brut === null) return preferencesDefaut();
  const p = brut as Preferences & { demarrage?: { mode?: string } };
  if (p.version !== 1 || !p.demarrage?.mode) return preferencesDefaut();
  if (["accueil", "favoris"].includes(p.demarrage.mode as string)) return { ...p, demarrage: { mode: "bibliotheque" } };
  return p;
}
