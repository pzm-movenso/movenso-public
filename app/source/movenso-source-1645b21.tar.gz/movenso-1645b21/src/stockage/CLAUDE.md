# `src/stockage/` — un seul écrivain, jamais d'état à moitié écrit

Ce dossier est le seul endroit où une donnée peut être **perdue**. D'où :

- **`bibliotheque.json` a UN seul écrivain : `sauvegarder()`.** Toute mutation
  persistante y passe. La restauration avait son propre chemin, sans bascule
  ni file — le seul chemin non protégé, et il s'exerçait quand l'utilisateur
  récupérait d'un problème (D-258). `verifier:sources` refuse désormais toute
  écriture directe hors de `sauvegarder`.
- **« Je n'ai pas pu lire » n'est JAMAIS « il n'y a rien ».** Le lecteur de
  l'état ne rend `null` que sur `NotFoundError`. Le `catch` muet d'avant rendait
  `null` pour n'importe quelle panne — permission perdue, `UnknownError`,
  support en défaut — et la couche au-dessus lit `null` comme « première
  installation » : elle fabriquait une bibliothèque VIDE et la SAUVEGARDAIT
  par-dessus des données intactes (audit externe du 2026-08-21, D-407). Une
  panne du support n'est pas une autorisation d'effacer. Corollaire : ce qui se
  reperd sans conséquence (préférences d'appareil) a son lecteur TOLÉRANT,
  nommé comme tel ; l'état de vérité n'en a pas.
- **Un état migré ne se persiste qu'avec les octets qu'il déclare.** La
  migration 5 → 6 sort les images du JSON et les remplace par des références
  de fichiers : persister le nouveau schéma alors qu'une seule image n'a pas
  pu être écrite détruit le base64 d'origine ET laisse la référence dans le
  vide — la vignette est perdue pour de bon. Le chemin de MIGRATION exige donc
  zéro échec, là où la pose d'images reçues d'un conteneur reste dégradable
  (D-408). Le commentaire de `charger()` affirmait déjà cet invariant : il
  était FAUX, `poserImages` rendant ses échecs au lieu de les lever. Un
  commentaire qui promet ce que le code ne fait pas est pire que pas de
  commentaire — c'est ce qui a empêché de voir le défaut.
- **Écriture transactionnelle, dans cet ordre** : temporaire → **relecture** →
  revalidation → bascule. Un résidu `.tmp` au démarrage est un commit
  interrompu : on l'écarte, l'état courant reste la vérité.
- **Les écritures sont sérialisées** (`#chaineSauvegarde`) : deux persistances
  ne s'entrelacent jamais sur le temporaire. Et le **payload est FIGÉ** à
  l'entrée dans la file, dans le même tour synchrone que la validation : la
  bibliothèque est un objet mutable que l'application modifie en place, donc
  valider un objet puis sérialiser le MÊME objet après l'attente écrivait un
  état que personne n'avait validé (D-409).
- **Les octets AVANT l'état qui les déclare.** Les images se posent d'abord,
  la bascule ensuite. C'est sûr sans transaction multi-fichiers parce que le
  nom est l'empreinte : l'écriture est **idempotente**, une interruption
  laisse au pire des octets en trop (D-269).
- **Un fichier PRÉSENT n'est pas un fichier ÉCRIT.** `getFileHandle(create)`
  crée l'entrée AVANT que les octets arrivent : un `close()` en échec laisse
  0 octet sous l'empreinte. Tester la présence par le NOM seul déclarait donc
  l'image posée pour toujours, et la migration basculait en schéma 6 après avoir
  perdu le base64 — la promesse « la prochaine ouverture réessaiera » était
  fausse à la SECONDE ouverture (D-415). Présence = **nom + taille des OCTETS
  qu'on tient**, jamais la taille que l'appelant DÉCLARE : se fier à `taille`
  faisait réécrire une image déjà valide, et l'échec de cette réécriture
  inutile SUPPRIMAIT le fichier d'avant — une panne devenue autorisation
  d'effacer, l'exact inverse de la règle (D-416). Un échec ne retire donc que ce
  qui a été **ÉTABLI** absent ou de mauvaise taille — et si la taille n'a pas pu
  être LUE, on s'abstient : ni écriture, ni retrait, l'échec est rendu (D-417).
  La version d'avant rendait `-1` pour toute panne de lecture, donc un fichier
  valide et illisible passait pour absent : une seule panne suffisait à le
  détruire. C'était le catch universel de D-407 réintroduit par le correctif qui
  l'invoquait. Le nom étant l'empreinte du contenu,
  la taille suffit à décider : seule la troncature est plausible, pas la
  collision. Cette puce et la suivante disent **la même chose** — la valeur
  digne de foi est celle qu'on a vérifiée, pas celle qu'on a reçue.
- **Ne jamais recalculer une identité fournie — la vérifier.** `poserImages`
  recalcule l'empreinte avant d'écrire : ici le nom devient l'identité pour
  toute la suite, le stockage ne croit pas son appelant (D-271).
- **Supprimer est irréversible, pas écrire.** Le balayage des fichiers
  orphelins est une opération SÉPARÉE et plus prudente que l'épuration de
  l'inventaire : un fichier en trop coûte de la place, un fichier manquant
  coûte une illustration. La corbeille et les fusions réversibles gardent des
  références — les oublier efface ce qui était encore restaurable.
- **Rien de personnel ne voyage.** Carnet, favoris, préférences d'appareil ne
  sortent jamais dans un pack.
- **Un rollback ne reconstruit jamais partiellement l'état** : il rend l'état
  d'avant, entier, ou il échoue en le disant.
