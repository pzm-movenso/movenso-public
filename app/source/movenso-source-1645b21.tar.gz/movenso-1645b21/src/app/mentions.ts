/**
 * Mentions RÉDIGÉES du produit — texte engageant (confidentialité) validé par
 * le porteur. Source UNIQUE (D-253) : ces gabarits sont réutilisés tels quels
 * partout où l'on parle du pseudo (Réglages, À-propos, Aide) et à la rédaction.
 * Une copie divergente serait un défaut — on importe, on ne recopie pas.
 */

import { html, type TemplateResult } from "lit";

/** Ce que le pseudo engage — affiché en permanence là où il se renseigne
 *  (Réglages), et rappelé dans À-propos et l'Aide. */
export const MENTION_PSEUDO: TemplateResult = html`<p class="mention-pseudo">
  <b>Ton pseudo t'identifie comme auteur.</b> Il <b>signe</b> les fiches que tu
  crées et modifies, et il <b>accompagne</b> le contenu que tu publies (pack) ou
  partages (technique individuelle). Tu peux le laisser vide et tout utiliser ;
  il te sera <b>demandé avant de partager ton propre contenu</b>.
</p>`;

/** Rappel court, NON bloquant, montré à la rédaction d'une fiche UNIQUEMENT
 *  quand aucun pseudo n'est encore renseigné (demande porteur). */
export const RAPPEL_PSEUDO: TemplateResult = html`<p class="rappel-pseudo">
  Pense à <b>signer ton travail</b> : ajoute ton pseudo dans Réglages. Il
  apparaîtra sur tes créations et dans ce que tu partages.
</p>`;
