/**
 * L'Atelier (D-020.3) — l'espace où l'on CONSTRUIT et GOUVERNE le corpus,
 * distinct de l'usage quotidien : diagnostics actionnables, taxonomies,
 * types de relation, packs, export/restauration, sauvegardes, réglages.
 * Adapté au grand écran, même code partout.
 * Règle : aucun indicateur sans action associée (D-020.3).
 */

import { html, nothing, type TemplateResult } from "lit";
import type { Discipline, Media, Technique } from "../domaine/modele.ts";
import { compositionsUtilisant } from "../domaine/composition.ts";
import { boutonsMonterDescendre, type ReordreParGlisser } from "./glisser.ts";
import { extrairePackDiscipline } from "../echange/extraction-pack.ts";
import { sourceDe } from "../domaine/modele.ts";
import { chercherTechniques } from "../domaine/recherche.ts";
import { urlSure, domaineDe } from "../securite/liens.ts";
import { clePaire, differencesDoublon, fusionnerDoublons, type CoteDoublon, type PaireDoublon } from "../domaine/doublons.ts";
import type { MovensoApp } from "./racine.ts";
import { nomEditorialSource, nomSource, vignetteTechnique } from "./vues.ts";
import { RELATIONS_VISUELLES } from "./fonctionnalites.ts";
import { VERSION } from "./version.ts";

export { ecranMedias, ecranATraiter, ecranRelations, ecranCorbeille, ecranDoublons, reinitialiserMediatheque } from "./atelier-medias.ts";
export { ecranPublier, ecranSauvegardes, ecranStockage, ecranSecurite, ecranApparence, ecranAvance, ecranDiagnostic } from "./atelier-reglages.ts";
export { ecranAide, ecranAideSujet } from "./aide.ts";
export { ecranApropos } from "./apropos.ts";
import { creationOuverte, enteteEncart, etatGestion } from "./atelier-commun.ts";
import { sectionCreerDiscipline, demanderSuppressionDiscipline, panneauSuppressionDiscipline, sectionCategories, sectionNiveaux, sectionTechniques } from "./atelier-taxonomies.ts";

/** Choisit la discipline dont on règle les catégories et les niveaux —
 *  JAMAIS au focus (D-413). Le `@focus` d'avant faisait de « tabuler » un
 *  « choisir » : traverser la rangée au clavier réaffectait la sélection, donc
 *  le contenu des deux volets rendus dessous — un changement de contexte au
 *  clavier (WCAG 3.2.1 « On Focus »). Le geste est désormais explicite : toucher
 *  le NOM de la puce, ou Entrée dessus. Le geste vit sur le CHAMP, pas sur la
 *  puce entière : posé sur la puce, il était hérité par les ▲/▼ et la ✕ faute
 *  d'arrêt de propagation, donc réordonner ou supprimer la troisième discipline
 *  réaffectait aussi le contexte — le changement non demandé retiré au clavier,
 *  réintroduit à la souris (D-416). */
function choisirDiscipline(app: MovensoApp, id: string): void {
  if (app.disciplineGestion === id) return;
  app.disciplineGestion = id;
  app.requestUpdate();
}

/** Sous-écran « Discipline » (Plus) — tuning post-V3 : sections Discipline,
 *  Catégories, Niveaux (les techniques ont leur propre entrée ; les packs se
 *  gèrent à l'import/export ; la source n'est plus affichée). Une discipline est
 *  toujours sélectionnée pour que Catégories/Niveaux restent visibles. */
export function ecranPacksDisciplines(app: MovensoApp): TemplateResult {
  const b = app.bibliotheque!;
  if (b.disciplines.length === 0)
    return html`
      <div class="carte-atelier">
        ${enteteEncart("Disciplines", "discipline", app)}
        ${creationOuverte.has("discipline") ? sectionCreerDiscipline(app) : nothing}
        <p class="fil-vide" style="padding:6px 2px 0">Aucune discipline — touche ＋ pour en créer une, ou importe un pack.</p>
      </div>
    `;
  const selId = app.disciplineGestion && b.disciplines.some((d) => d.id === app.disciplineGestion) ? app.disciplineGestion : b.disciplines[0]!.id;
  const sel = b.disciplines.find((d) => d.id === selId)!;
  const optsDisc: ReordreParGlisser = {
    reordonner: (id, cible) => app.deplacerDisciplineVers(id, cible),
    enregistrer: () => void app.enregistrerReordre(),
    ordre: () => b.disciplines.map((x) => x.id),
    nom: (id) => b.disciplines.find((x) => x.id === id)?.nom ?? "la discipline",
  };
  return html`
    <div class="carte-atelier">
      ${enteteEncart("Disciplines", "discipline", app)}
      ${creationOuverte.has("discipline") ? sectionCreerDiscipline(app) : nothing}
      <div class="chips-glissables chips-disciplines" aria-label="Disciplines">
        ${b.disciplines.map(
          (d) => html`<span class="chip-glissable ${d.id === sel.id ? "actif" : ""}">
            ${boutonsMonterDescendre(app, d.id, optsDisc)}
            <input class="champ-mini chip-gestion" .value=${d.nom} title=${d.nom}
              @click=${() => choisirDiscipline(app, d.id)}
              aria-label="Discipline « ${d.nom} »${d.id === sel.id ? ", affichée" : " — Entrée pour afficher ses catégories et niveaux"}"
              @keydown=${(e: KeyboardEvent) => { if (e.key === "Enter") choisirDiscipline(app, d.id); }}
              @change=${(e: Event) => void app.majNomDiscipline(d.id, (e.target as HTMLInputElement).value)}>
            <button class="bouton-icone" aria-label="Supprimer « ${d.nom} »" title="Supprimer"
              @click=${() => demanderSuppressionDiscipline(app, d)}>✕</button>
          </span>
          ${panneauSuppressionDiscipline(app, d)}`,
        )}
      </div>
    </div>
    ${sectionCategories(app, sel)}
    ${sectionNiveaux(app, sel)}
  `;
}

/** Sous-écran « Techniques » (Plus, tuning post-V3) : promu au niveau du menu,
 *  hors de « Discipline ». Filtre par discipline, recherche, À compléter /
 *  Problèmes ; ouvre la fiche ou retire une technique. */
export function ecranTechniques(app: MovensoApp): TemplateResult {
  const b = app.bibliotheque!;
  if (b.techniques.length === 0)
    return html`<p class="fil-vide" style="padding-top:10px">Aucune technique pour l'instant.</p>`;
  return sectionTechniques(app, etatGestion.disciplineId);
}

/* ---------- Doublons potentiels (D-068) : AIDE non bloquante ---------- */

/* ---------- 1. CONSTRUIRE le corpus (composé dans ecranPacksDisciplines) ---------- */

/* ---------- types de relation (données du graphe, D-020.2) ---------- */

/* ---------- Techniques : liste orientée GESTION (lot 6 §9) — jamais une
   seconde Bibliothèque : repérer l'incomplet, ouvrir la fiche ---------- */

/* ---------- Sources et auteurs (lot 6 §11) : CONSULTATION éditoriale —
   le manifeste d'un pack tiers ne se modifie jamais ici ---------- */

/* ---------- 3. PUBLIER une sélection maîtrisée (lot 6 §19-20) ---------- */

/* ---------- Sauvegardes (composées dans ecranSauvegardes) ---------- */

/* sauvegardes locales : snapshots automatiques MOTIVÉS (rollback éclairé, §22/§24) */

/* ---------- réglages : démarrage, jour/nuit, tonalité (D-020.4, D-025) ---------- */

/* Thème, tonalité, démarrage sont composés dans ecranApparence ;
   protections dans ecranSecurite ; diagnostic/réinitialisation dans
   ecranDiagnostic. */

/* ---------- réinitialisation complète (lot 7 §22) ---------- */

/* ---------- protections facultatives (lot 7 §2-3, §12, §14) ---------- */
