/** <movenso-video-locale> — lit une vidéo capturée depuis OPFS (URL objet,
 *  flux disque, jamais chargée en mémoire). Absente → message dégradé. */

import { LitElement, html, nothing } from "lit";
import type { MovensoApp } from "./racine.ts";

export class MovensoVideoLocale extends LitElement {
  static properties = { app: { attribute: false }, mediaId: { attribute: false }, url: { state: true } };

  // cf. racine.ts : initialisation dans le constructeur, jamais en champ de classe.
  declare app: MovensoApp;
  declare mediaId: string;
  declare url: string | null | undefined; // undefined = chargement, null = introuvable

  constructor() {
    super();
    this.mediaId = "";
    this.url = undefined;
  }

  override createRenderRoot() {
    return this;
  }

  // D-422 : l'URL suit `mediaId`, pas la connexion. Lit RÉUTILISE ce lecteur
  // quand la fiche passe d'un média local à un autre (sélecteur sous l'image) :
  // chargée au seul connectedCallback, l'URL restait celle du premier média —
  // la puce changeait, la vidéo non.
  override willUpdate(changes: Map<PropertyKey, unknown>): void {
    if (changes.has("mediaId")) this.#charger();
  }

  override connectedCallback(): void {
    super.connectedCallback();
    // Reconnexion du même lecteur : son URL a été révoquée au détachement.
    if (this.hasUpdated) this.#charger();
  }

  override disconnectedCallback(): void {
    super.disconnectedCallback();
    this.#liberer();
  }

  #jeton = 0;

  #charger(): void {
    this.#liberer();
    const jeton = ++this.#jeton;
    void this.app.stockage.urlVideo(this.mediaId).then((u) => {
      // Réponse d'un chargement dépassé (choix rapide, lecteur détaché puis
      // rattaché) : elle n'écrase pas le média courant, et son URL ne fuit pas.
      if (jeton !== this.#jeton || !this.isConnected) {
        if (u) URL.revokeObjectURL(u);
        return;
      }
      this.url = u;
    });
  }

  #liberer(): void {
    if (this.url) URL.revokeObjectURL(this.url);
    this.url = undefined;
  }

  override render() {
    if (this.url === undefined) return nothing;
    if (this.url === null)
      return html`<div class="video-absente" style="font-size:12.5px;color:var(--sourdine)">
        Vidéo introuvable sur cet appareil.
        <button class="action-douce" style="margin-top:4px" @click=${() => this.app.ouvrirPlusSection("medias")}>
          Vérifier <span>(Plus — Médias)</span>
        </button>
      </div>`;
    // Un seul lecteur actif à la fois (NR-003-002) : lancer cette vidéo met
    // en pause les autres et replie les lecteurs en ligne dépliés.
    return html`<div class="media-video"><video src=${this.url} controls playsinline preload="metadata"
      @play=${(e: Event) => {
        document.querySelectorAll("video").forEach((v) => { if (v !== e.target) v.pause(); });
        if (this.app.mediasDeplies.size) {
          this.app.mediasDeplies = new Set();
          this.app.requestUpdate();
        }
      }}></video></div>`;
  }
}

customElements.define("movenso-video-locale", MovensoVideoLocale);
