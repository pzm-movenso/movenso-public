/**
 * Invariants de la bibliothèque — validés avant toute écriture (contrat §2.3).
 * Leçon V2 conservée pour sa valeur : « jamais d'écrasement silencieux » —
 * une donnée invalide est rejetée avec un message actionnable, pas corrigée
 * en silence.
 */

import type {
  Bibliotheque,
  Composition,
  Contribution,
  Couverture,
  Discipline,
  Media,
  Technique,
  TypeRelationDef,
} from "./modele.ts";
import { LIENS_HERITES, ORIGINES_MEDIA, PROVENANCES, SERVICES_MEDIA, TYPES_BLOC, TYPES_MEDIA, VERSION_SCHEMA } from "./modele.ts";
import { estUlid } from "./ulid.ts";

export class ErreurValidation extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ErreurValidation";
  }
}

function exiger(condition: boolean, message: string): asserts condition {
  if (!condition) throw new ErreurValidation(message);
}

/* ---------- structures OPTIONNELLES (D-255) ----------
 *
 * Un pack tiers n'est pas produit par notre outil : il peut porter n'importe
 * quoi dans un champ facultatif. Ces champs n'étaient pas validés, donc un
 * conteneur au demeurant intègre pouvait INSTALLER un état que l'affichage ne
 * sait pas lire — `alertes: {}` passait la validation puis cassait la fiche
 * sur `alertes.map`. Un défaut ne doit jamais franchir l'import : il se refuse
 * avec un message, il ne s'installe pas pour planter plus tard.
 */

function estObjet(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

/** Un champ qu'on PARCOURT doit être un tableau — sinon l'itération jette une
 *  erreur technique au lieu d'un refus lisible. */
function exigerTableau(v: unknown, quoi: string): asserts v is unknown[] {
  exiger(Array.isArray(v), `${quoi} : un tableau est attendu`);
}

function exigerTexteNonVide(v: unknown, quoi: string): void {
  exiger(typeof v === "string" && v.trim() !== "", `${quoi} : texte non vide attendu`);
}

function exigerTexteSiPresent(v: unknown, quoi: string): void {
  if (v !== undefined) exiger(typeof v === "string", `${quoi} : texte attendu`);
}

/** Un entier — pas « 3 », pas 3.5, pas NaN. `min` permet d'exiger un compte
 *  positif là où zéro n'a pas de sens (une priorité commence à 1). */
function exigerEntierSiPresent(v: unknown, quoi: string, min = 0): void {
  if (v === undefined) return;
  exiger(typeof v === "number" && Number.isInteger(v) && v >= min,
    `${quoi} : entier ≥ ${min} attendu, reçu « ${String(v)} »`);
}

function exigerParmiSiPresent(v: unknown, valeurs: readonly string[], quoi: string): void {
  if (v === undefined) return;
  exiger(typeof v === "string" && valeurs.includes(v),
    `${quoi} : valeur « ${String(v)} » inconnue (${valeurs.join(", ")})`);
}

const NIVEAUX_ALERTE = ["info", "warning", "danger"] as const;

function validerAlertes(v: unknown, quoi: string): void {
  if (v === undefined) return;
  exigerTableau(v, `${quoi}, alertes`);
  for (const [i, a] of v.entries()) {
    const ou = `${quoi}, alerte ${i + 1}`;
    exiger(estObjet(a), `${ou} : objet attendu`);
    exigerTexteNonVide(a.type, `${ou}, type`);
    exigerTexteNonVide(a.libelle, `${ou}, libellé`);
    exiger(
      typeof a.niveau === "string" && (NIVEAUX_ALERTE as readonly string[]).includes(a.niveau),
      `${ou} : niveau « ${String(a.niveau)} » inconnu (${NIVEAUX_ALERTE.join(", ")})`,
    );
    exigerTexteSiPresent(a.icone, `${ou}, icône`);
    exigerTexteSiPresent(a.detail, `${ou}, détail`);
    if (a.bloquante !== undefined) exiger(typeof a.bloquante === "boolean", `${ou} : « bloquante » booléen attendu`);
    if (a.reference !== undefined) {
      exiger(estObjet(a.reference), `${ou}, référence : objet attendu`);
      for (const champ of ["organisation", "article", "url", "verifieLe"])
        exigerTexteSiPresent(a.reference[champ], `${ou}, référence ${champ}`);
    }
  }
}

/** Une empreinte SHA-256 hexadécimale — l'identité d'une image (schéma 6). */
function estEmpreinte(v: unknown): boolean {
  return typeof v === "string" && /^[0-9a-f]{64}$/.test(v);
}

function validerCouverture(v: unknown, quoi: string): void {
  if (v === undefined) return;
  exiger(estObjet(v), `${quoi}, couverture : objet attendu`);
  if (v.type === "fichier") exiger(estEmpreinte(v.imageId), `${quoi}, couverture : image « ${String(v.imageId)} » mal formée (empreinte SHA-256 attendue)`);
  else if (v.type === "media") exiger(estUlid(v.mediaId as string), `${quoi}, couverture : média « ${String(v.mediaId)} » mal formé`);
  else exiger(false, `${quoi}, couverture : type « ${String(v.type)} » inconnu (fichier, media)`);
}

/** Inventaire des images (schéma 6) : des empreintes uniques, une taille et un
 *  MIME d'image. L'id ÉTANT le contenu, un doublon d'id serait une
 *  contradiction — deux déclarations différentes des mêmes octets. */
function validerImages(images: unknown, quoi: string): void {
  if (images === undefined) return;
  exigerTableau(images, quoi);
  const vus = new Set<string>();
  for (const i of images as unknown[]) {
    exiger(estObjet(i), `${quoi} : objet attendu`);
    const img = i as Record<string, unknown>;
    exiger(estEmpreinte(img.id), `${quoi} : identité « ${String(img.id)} » mal formée (empreinte SHA-256 attendue)`);
    exiger(!vus.has(img.id as string), `${quoi} : l'image « ${String(img.id)} » est déclarée deux fois`);
    vus.add(img.id as string);
    exiger(typeof img.mime === "string" && img.mime.startsWith("image/"), `${quoi} « ${String(img.id)} » : MIME d'image attendu, reçu « ${String(img.mime)} »`);
    exiger(typeof img.taille === "number" && Number.isInteger(img.taille) && img.taille > 0, `${quoi} « ${String(img.id)} » : taille en octets attendue`);
  }
}

/** L'origine dit de quel PACK vient un élément : `sourceDe` en dérive la
 *  source affichée, et le rapprochement s'en sert pour ne pas dupliquer. Mal
 *  formée, elle fausse les deux en silence. */
function validerOrigine(v: unknown, quoi: string): void {
  if (v === undefined) return;
  exiger(estObjet(v), `${quoi}, origine : objet attendu ({ pack, element })`);
  exigerTexteNonVide(v.pack, `${quoi}, origine.pack`);
  exigerTexteNonVide(v.element, `${quoi}, origine.element`);
}

function exigerIdsUniques(ids: string[], quoi: string): void {
  const vus = new Set<string>();
  for (const id of ids) {
    exiger(estUlid(id), `${quoi} : id « ${id} » n'est pas un ULID valide`);
    exiger(!vus.has(id), `${quoi} : id « ${id} » en double`);
    vus.add(id);
  }
}

/** Un chemin de média local doit rester relatif et sûr (contrat §8). */
export function estCheminRelatifSur(chemin: string): boolean {
  if (chemin === "" || chemin.startsWith("/") || chemin.includes("\\")) return false;
  if (/^[a-zA-Z]:/.test(chemin)) return false;
  return !chemin.split("/").some((seg) => seg === ".." || seg === "");
}

/** Les types de relation sont des données (D-020.2) — mais des données validées. */
function validerTypesRelation(types: TypeRelationDef[]): void {
  const vus = new Set<string>();
  for (const t of types) {
    exiger(t.id.trim() !== "", "Type de relation : id vide");
    exiger(!vus.has(t.id), `Type de relation « ${t.id} » en double`);
    vus.add(t.id);
    exiger(t.libelle.trim() !== "", `Type de relation « ${t.id} » : libellé vide`);
    exiger(
      t.symetrique === true || (t.libelleInverse ?? "").trim() !== "",
      `Type de relation « ${t.id} » : un type orienté déclare son libellé inverse (ou sa symétrie)`,
    );
  }
}

/** Une couleur de niveau part telle quelle dans `style="background:…"`
 *  (`vignette.ts`). Une chaîne libre y fait donc entrer des DÉCLARATIONS CSS :
 *  `red;position:fixed;inset:0;z-index:9999` recouvre l'écran depuis un pack
 *  importé. Ce n'est pas du JS — la CSP n'y peut rien, le style est produit par
 *  l'application elle-même — mais c'est un déni d'usage et un spoofing visuel
 *  (audit 2026-08-13, P1-2).
 *
 *  La frontière n'accepte donc que ce dont le produit a besoin : `#RRGGBB`,
 *  exactement ce que produit `<input type="color">` de l'éditeur, et la seule
 *  forme présente dans les six packs publiés (11 valeurs sur 11, mesuré). */
function validerCouleur(v: string | undefined, quoi: string): void {
  if (v === undefined) return;
  exiger(/^#[0-9A-Fa-f]{6}$/.test(v), `${quoi} : couleur « ${v} » — attendu #RRGGBB`);
}

function validerDiscipline(d: Discipline): void {
  exigerTexteNonVide(d.nom, `Discipline ${d.id}, nom`);
  exigerTableau(d.familles, `Discipline « ${d.nom} », familles`);
  for (const f of d.familles) validerCouverture(f.couverture, `Discipline « ${d.nom} », famille « ${f.nom} »`);
  exigerTableau(d.niveaux, `Discipline « ${d.nom} », niveaux`);
  for (const n of d.niveaux) {
    validerCouleur(n.couleur, `Discipline « ${d.nom} », niveau « ${n.nom} »`);
    validerCouleur(n.couleur2, `Discipline « ${d.nom} », niveau « ${n.nom} », seconde couleur`);
  }
  const idsTaxo = [...d.familles.map((f) => f.id), ...d.niveaux.map((n) => n.id)];
  const vus = new Set<string>();
  for (const id of idsTaxo) {
    exiger(id.trim() !== "", `Discipline « ${d.nom} » : id de taxonomie vide`);
    exiger(!vus.has(id), `Discipline « ${d.nom} » : id de taxonomie « ${id} » en double`);
    vus.add(id);
  }
}

function validerTechnique(t: Technique, disciplines: Map<string, Discipline>, typesRelation: Set<string>): void {
  exigerTexteNonVide(t.nom, `Technique ${t.id}, nom`);
  const d = disciplines.get(t.disciplineId);
  exiger(d !== undefined, `Technique « ${t.nom} » : discipline ${t.disciplineId} inconnue`);
  exigerTexteSiPresent(t.nomTraditionnel, `Technique « ${t.nom} », appellation`);
  exigerTableau(t.niveauxIds, `Technique « ${t.nom} », niveaux`);
  exigerTableau(t.relations, `Technique « ${t.nom} », relations`);
  validerAlertes(t.alertes, `Technique « ${t.nom} »`);
  validerCouverture(t.couverture, `Technique « ${t.nom} »`);
  validerOrigine(t.origine, `Technique « ${t.nom} »`);
  if (t.familleId !== undefined) {
    exiger(
      d.familles.some((f) => f.id === t.familleId),
      `Technique « ${t.nom} » : famille « ${t.familleId} » absente de la discipline « ${d.nom} »`,
    );
  }
  for (const nid of t.niveauxIds) {
    exiger(
      d.niveaux.some((n) => n.id === nid),
      `Technique « ${t.nom} » : niveau « ${nid} » absent de la discipline « ${d.nom} »`,
    );
  }
  for (const r of t.relations) {
    exiger(estObjet(r), `Technique « ${t.nom} » : relation — objet attendu`);
    exiger(typesRelation.has(r.type), `Technique « ${t.nom} » : type de relation « ${r.type} » non déclaré`);
    exiger(estUlid(r.cibleId), `Technique « ${t.nom} » : cible de relation « ${r.cibleId} » mal formée`);
    // Une cible absente de la bibliothèque est tolérée (contrat §2.1) : pas de contrôle d'existence.
    // Ces deux-là sont AFFICHÉS et TRIÉS : une note objet s'affiche
    // « [object Object] », une priorité texte fausse l'ordre en silence.
    exigerTexteSiPresent(r.note, `Technique « ${t.nom} », note de relation`);
    exigerEntierSiPresent(r.priorite, `Technique « ${t.nom} », priorité de relation`, 1);
  }
  if (t.mediaPrincipalId !== undefined) {
    exiger(estUlid(t.mediaPrincipalId), `Technique « ${t.nom} » : média principal « ${t.mediaPrincipalId} » mal formé`);
    // Un média principal disparu est toléré (l'affichage retombe sur le premier média sourcé).
  }
}

function validerMedias(medias: Media[], porteur: string): void {
  exigerIdsUniques(medias.map((m) => m.id), `${porteur}, médias`);
  for (const m of medias) {
    exiger((TYPES_MEDIA as readonly string[]).includes(m.type), `Média ${m.id} : type « ${m.type} » inconnu`);
    exiger(m.ref.trim() !== "", `Média ${m.id} : référence vide`);
    if (m.type === "local") {
      exiger(estCheminRelatifSur(m.ref), `Média ${m.id} : chemin local « ${m.ref} » non relatif ou dangereux`);
    }
    if (m.type === "plateforme") {
      exiger(
        m.service !== undefined && (SERVICES_MEDIA as readonly string[]).includes(m.service),
        `Média ${m.id} : un média de plateforme déclare son service (${SERVICES_MEDIA.join(", ")})`,
      );
    }
    // Les métadonnées sont FACULTATIVES, pas libres : `taille` est comparée à
    // celle du fichier réel et sert au calcul d'espace, `sha256` sert à la
    // déduplication (D-020 §5), `extension` compose le NOM PHYSIQUE du
    // fichier. Un texte là où un nombre est attendu, et l'espace annoncé
    // devient faux ; une extension objet, et le nom de fichier devient
    // « [object Object] ».
    exigerTexteSiPresent(m.label, `Média ${m.id}, libellé`);
    exigerTexteSiPresent(m.mime, `Média ${m.id}, MIME`);
    exigerTexteSiPresent(m.nomOriginal, `Média ${m.id}, nom d'origine`);
    exigerTexteSiPresent(m.ajouteLe, `Média ${m.id}, date d'ajout`);
    exigerEntierSiPresent(m.taille, `Média ${m.id}, taille`);
    exigerParmiSiPresent(m.origineMedia, ORIGINES_MEDIA, `Média ${m.id}, origine`);
    if (m.extension !== undefined)
      exiger(typeof m.extension === "string" && /^[a-z0-9]{1,5}$/i.test(m.extension),
        `Média ${m.id} : extension « ${String(m.extension)} » mal formée — elle compose le nom du fichier`);
    if (m.sha256 !== undefined)
      exiger(estEmpreinte(m.sha256), `Média ${m.id} : empreinte « ${String(m.sha256)} » mal formée`);
  }
}

/** Types d'alerte déclarés par la bibliothèque (D-136) — jamais validés
 *  jusqu'ici, alors qu'ils voyagent dans les packs et que l'affichage les
 *  parcourt. `typesAlerte: {}` passait, puis cassait au premier `.find`. */
function validerTypesAlerte(v: unknown): void {
  if (v === undefined) return;
  exigerTableau(v, "Bibliothèque, typesAlerte");
  const vus = new Set<string>();
  for (const [i, t] of v.entries()) {
    const ou = `Bibliothèque, type d'alerte ${i + 1}`;
    exiger(estObjet(t), `${ou} : objet attendu`);
    exigerTexteNonVide(t.id, `${ou}, id`);
    exiger(!vus.has(t.id as string), `${ou} : id « ${String(t.id)} » en double`);
    vus.add(t.id as string);
    exigerTexteNonVide(t.libelle, `${ou}, libellé`);
    exiger(
      typeof t.niveau === "string" && (NIVEAUX_ALERTE as readonly string[]).includes(t.niveau),
      `${ou} : niveau « ${String(t.niveau)} » inconnu (${NIVEAUX_ALERTE.join(", ")})`,
    );
    exigerTexteSiPresent(t.icone, `${ou}, icône`);
  }
}

/** Conflits proposés par un pack (D-157/D-243/D-298) — métadonnée locale,
 *  mais elle VOYAGE : une sauvegarde « complet » l'emporte et la restauration
 *  la rapporte, puis « À vérifier » la parcourt. Même classe de défaut que
 *  `typesAlerte` (D-271) : `conflitsLiaisons: {}` passait la frontière, puis
 *  cassait au premier parcours. */
function validerConflitsLiaisons(v: unknown): void {
  if (v === undefined) return;
  exigerTableau(v, "Bibliothèque, conflitsLiaisons");
  for (const [i, c] of v.entries()) {
    const ou = `Bibliothèque, conflit de liaison ${i + 1}`;
    exiger(estObjet(c), `${ou} : objet attendu`);
    for (const champ of ["pack", "sourceId", "cibleId", "type", "detecteLe"] as const)
      exigerTexteNonVide(c[champ], `${ou}, ${champ}`);
    exigerParmiSiPresent(c.sens, ["contenu", "retrait"], `${ou}, sens`);
    exigerTexteSiPresent(c.note, `${ou}, note`);
    exigerEntierSiPresent(c.priorite, `${ou}, priorité`, 1);
  }
}

/** Éditions installées (D-307) — même frontière que les conflits : le champ
 *  voyage dans une sauvegarde complète et revient par la restauration. */
function validerEditionsPacks(v: unknown): void {
  if (v === undefined) return;
  exigerTableau(v, "Bibliothèque, editionsPacks");
  const vus = new Set<string>();
  for (const [i, e] of v.entries()) {
    const ou = `Bibliothèque, édition de pack ${i + 1}`;
    exiger(estObjet(e), `${ou} : objet attendu`);
    exigerTexteNonVide(e.pack, `${ou}, pack`);
    exiger(!vus.has(e.pack as string), `${ou} : le pack « ${String(e.pack)} » a deux éditions — une seule entrée par pack`);
    vus.add(e.pack as string);
    exiger(
      typeof e.versionEditoriale === "number" && Number.isInteger(e.versionEditoriale) && e.versionEditoriale >= 1,
      `${ou} : versionEditoriale entière ≥ 1 attendue`,
    );
    exigerTexteNonVide(e.majLe, `${ou}, majLe`);
  }
}

function validerConflitsContributions(v: unknown): void {
  if (v === undefined) return;
  exigerTableau(v, "Bibliothèque, conflitsContributions");
  for (const [i, c] of v.entries()) {
    const ou = `Bibliothèque, conflit de contribution ${i + 1}`;
    exiger(estObjet(c), `${ou} : objet attendu`);
    for (const champ of ["pack", "element", "contributionId", "detecteLe"] as const)
      exigerTexteNonVide(c[champ], `${ou}, ${champ}`);
    exigerTableau(c.pointsCles, `${ou}, pointsCles`);
    for (const p of c.pointsCles) exiger(typeof p === "string", `${ou} : point clé texte attendu`);
    exigerTexteSiPresent(c.description, `${ou}, description`);
    exigerTexteSiPresent(c.variantes, `${ou}, variantes`);
    exigerTexteSiPresent(c.attribution, `${ou}, attribution`);
  }
}

/** Une provenance sourcée exige une attribution (vision §7.2) — même règle partout. */
function exigerAttributionSiSourcee(provenance: string, attribution: string | undefined, quoi: string): void {
  exiger((PROVENANCES as readonly string[]).includes(provenance), `${quoi} : provenance « ${provenance} » inconnue`);
  if (provenance === "referentiel" || provenance === "ressource") {
    exiger(
      (attribution ?? "").trim() !== "",
      `${quoi} : une provenance « ${provenance} » exige une attribution (savoir sourcé)`,
    );
  }
}

function validerContribution(c: Contribution, techniques: Set<string>): void {
  exigerAttributionSiSourcee(c.provenance, c.attribution, `Contribution ${c.id}`);
  exigerTableau(c.pointsCles, `Contribution ${c.id}, points clés`);
  exigerTableau(c.medias, `Contribution ${c.id}, médias`);
  exigerTexteSiPresent(c.description, `Contribution ${c.id}, description`);
  validerOrigine(c.origine, `Contribution ${c.id}`);
  if (c.techniqueId !== null) {
    exiger(techniques.has(c.techniqueId), `Contribution ${c.id} : technique ${c.techniqueId} inconnue`);
  }
  // « À rattacher » (techniqueId null) : ouvert à toute provenance depuis le
  // lot 4 §9 (remplace increment-1.md §2 « personnel seulement ») — une
  // capture d'enseignement ou de ressource gardée pour plus tard conserve sa
  // provenance et se reprend ; l'attribution reste exigée pour le sourcé.
  exiger(!Number.isNaN(Date.parse(c.creeLe)), `Contribution ${c.id} : date « ${c.creeLe} » invalide`);
  validerMedias(c.medias, `Contribution ${c.id}`);
}

/** Une composition référence des identités, elle ne les duplique jamais (D-020.1). */
function validerComposition(co: Composition): void {
  exigerTexteNonVide(co.nom, `Composition ${co.id}, nom`);
  exigerTableau(co.blocs, `Composition « ${co.nom} », blocs`);
  validerOrigine(co.origine, `Composition « ${co.nom} »`);
  exigerAttributionSiSourcee(co.provenance, co.attribution, `Composition « ${co.nom} »`);
  exiger(!Number.isNaN(Date.parse(co.creeLe)), `Composition « ${co.nom} » : date « ${co.creeLe} » invalide`);
  exigerIdsUniques(co.blocs.map((x) => x.id), `Composition « ${co.nom} », blocs`);
  // Acteurs (D-227) : ids uniques, noms non vides. Un bloc qui référence un
  // acteur disparu reste VALIDE (il redevient neutre) — même tolérance que les
  // relations vers une cible absente : un import ne casse jamais.
  if (co.acteurs?.length) {
    // Un id d'acteur est un EMPLACEMENT local à la composition (« r1 », « r2 »),
    // pas une identité globale : on exige l'unicité, jamais le format ULID.
    const vus = new Set<string>();
    for (const a of co.acteurs) {
      exiger(a.id.trim() !== "", `Composition « ${co.nom} » : un acteur porte un identifiant`);
      exiger(!vus.has(a.id), `Composition « ${co.nom} » : acteur « ${a.id} » en double`);
      vus.add(a.id);
      exiger(a.nom.trim() !== "", `Composition « ${co.nom} » : un acteur porte un nom`);
    }
  }
  for (const bloc of co.blocs) {
    exiger(
      (TYPES_BLOC as readonly string[]).includes(bloc.type),
      `Composition « ${co.nom} » : bloc de type « ${bloc.type} » inconnu`,
    );
    // Lien avec le pas précédent (D-235) : un booléen — « rejoint le temps ».
    // Les valeurs héritées de D-229 restent ACCEPTÉES en entrée (un import ne
    // casse jamais) ; elles sont réinterprétées à la lecture et normalisées à
    // la première écriture. Un lien posé sur le premier pas est TOLÉRÉ et
    // ignoré (`decouperEnTemps`) plutôt que refusé : supprimer un pas ne doit
    // jamais rendre une bibliothèque invalide (garde-fou porteur D-235).
    if (bloc.lien !== undefined) {
      exiger(
        typeof bloc.lien === "boolean" || (LIENS_HERITES as readonly string[]).includes(bloc.lien),
        `Composition « ${co.nom} » : lien « ${String(bloc.lien)} » inconnu`,
      );
    }
    if (bloc.type === "technique") {
      exiger(
        bloc.techniqueId !== undefined && estUlid(bloc.techniqueId),
        `Composition « ${co.nom} » : un bloc technique référence une identité`,
      );
      // Une identité absente est tolérée (l'export/import de composition ne casse jamais).
    } else {
      // Un bloc de contenu porte au moins UNE substance : texte, média ou durée (D-124).
      exiger(
        (bloc.texte ?? "").trim() !== "" || bloc.medias.length > 0 || bloc.dureeSec !== undefined,
        `Composition « ${co.nom} » : un bloc « ${bloc.type} » porte un texte, un média ou une durée`,
      );
    }
    // Durée facultative (D-124) : un temps positif fini, jamais absurde.
    if (bloc.dureeSec !== undefined) {
      exiger(
        Number.isFinite(bloc.dureeSec) && bloc.dureeSec >= 0,
        `Composition « ${co.nom} » : durée « ${bloc.dureeSec} » invalide`,
      );
    }
    validerMedias(bloc.medias, `Composition « ${co.nom} », bloc ${bloc.id}`);
  }
  // Présentation (D-124) : médias de niveau composition, validés comme les autres.
  if (co.presentation) validerMedias(co.presentation.medias, `Composition « ${co.nom} », présentation`);
}

/** Valide tous les invariants ; lève ErreurValidation au premier manquement. */
export function validerBibliotheque(b: Bibliotheque): void {
  exiger(
    b.versionSchema === VERSION_SCHEMA,
    `Version de schéma ${b.versionSchema} inattendue (courante : ${VERSION_SCHEMA}) — passer par les migrations avant validation`,
  );
  // Les collections se PARCOURENT juste après : si l'une n'est pas un tableau,
  // on veut un refus lisible, pas un « x.map is not a function » (D-255).
  for (const [nom, v] of [
    ["typesRelation", b.typesRelation], ["disciplines", b.disciplines], ["techniques", b.techniques],
    ["contributions", b.contributions], ["compositions", b.compositions], ["favoris", b.favoris],
  ] as const) exigerTableau(v, `Bibliothèque, ${nom}`);
  validerTypesRelation(b.typesRelation);
  validerTypesAlerte(b.typesAlerte);
  validerConflitsLiaisons(b.conflitsLiaisons);
  validerConflitsContributions(b.conflitsContributions);
  validerEditionsPacks(b.editionsPacks);
  exigerIdsUniques(b.disciplines.map((d) => d.id), "Disciplines");
  exigerIdsUniques(b.techniques.map((t) => t.id), "Techniques");
  exigerIdsUniques(b.contributions.map((c) => c.id), "Contributions");
  exigerIdsUniques(b.compositions.map((c) => c.id), "Compositions");

  const disciplines = new Map(b.disciplines.map((d) => [d.id, d]));
  const techniques = new Set(b.techniques.map((t) => t.id));
  const typesRelation = new Set(b.typesRelation.map((t) => t.id));

  b.disciplines.forEach(validerDiscipline);
  b.techniques.forEach((t) => validerTechnique(t, disciplines, typesRelation));
  b.contributions.forEach((c) => validerContribution(c, techniques));
  b.compositions.forEach(validerComposition);

  // Images (schéma 6, D-269) : l'inventaire est le SEUL lieu qui déclare une
  // image. Une couverture qui désigne une image absente de l'inventaire n'est
  // pas une référence tolérée comme un favori orphelin — c'est une
  // incohérence produite par l'écrivain (nous, ou un pack mal formé), et on la
  // refuse au moment où elle est écrite plutôt que de la découvrir en vignette
  // vide plus tard. Les OCTETS manquants sont un autre sujet : le fichier
  // absent se dégrade à l'affichage, il n'invalide pas l'état.
  validerImages(b.images, "Bibliothèque, images");
  const declarees = new Set((b.images ?? []).map((i) => i.id));
  const verifierRenvoi = (c: Couverture | undefined, quoi: string) => {
    if (c?.type === "fichier")
      exiger(declarees.has(c.imageId), `${quoi} : l'image « ${c.imageId} » n'est déclarée nulle part dans l'inventaire`);
  };
  for (const d of b.disciplines)
    for (const f of d.familles) verifierRenvoi(f.couverture, `Discipline « ${d.nom} », famille « ${f.nom} »`);
  for (const t of b.techniques) verifierRenvoi(t.couverture, `Technique « ${t.nom} »`);
  for (const e of b.corbeille ?? []) verifierRenvoi(e.technique?.couverture, `Corbeille, « ${e.technique?.nom} »`);

  // Favoris (lot 5 §4) : des ULID uniques. La référence peut devenir
  // orpheline (technique retirée par un réimport) : l'affichage l'ignore et
  // le retrait local la nettoie — jamais de technique fantôme recréée.
  exigerIdsUniques(b.favoris, "Favoris");
  for (const id of b.favoris) exiger(estUlid(id), `Favori « ${id} » mal formé`);
}
