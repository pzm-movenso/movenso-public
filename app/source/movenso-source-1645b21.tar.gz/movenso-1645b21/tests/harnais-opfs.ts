/**
 * HARNAIS OPFS — un stockage en mémoire dont on peut CASSER chaque opération.
 *
 * Pourquoi il existe (audit externe du 2026-08-21, §3). Le dépôt teste
 * énormément le domaine, les conteneurs et les parcours, mais le chemin
 * heureux d'OPFS uniquement : aucune épreuve n'injectait de panne dans
 * `StockageOpfs`. Deux défauts de perte silencieuse ont traversé le dépôt par
 * ce trou précis — une lecture en échec prise pour « aucune donnée », et une
 * migration persistée sans les octets qu'elle déclare. Ce ne sont pas des
 * étourderies de code : ce sont des comportements que RIEN ne regardait.
 *
 * Ce que le harnais permet de dire, et qu'aucun test navigateur ne dit : ce
 * que fait le stockage quand le support REFUSE. Le vrai OPFS ne se met pas en
 * panne sur commande ; le harnais, si.
 *
 * Périmètre assumé (D-324 — la version la plus simple qui répond au besoin) :
 * fichiers, dossiers, écriture par `createWritable`, énumération, suppression.
 * `stream()`/`pipeTo` (promotion des vidéos) n'est PAS simulé — les médias en
 * flux ont leurs propres épreuves navigateur, et les inventer ici donnerait
 * une preuve sur un chemin qui n'est pas celui du produit.
 */

/** Une panne injectée. `chemin` est le chemin COMPLET dans l'arborescence
 *  OPFS (`bibliotheque.json`, `images/<sha>`, `sauvegardes/…`). */
export interface Panne {
  /** `lire` = `getFile()` ; `ecrire` = premier `write()` ; `fermer` = `close()`
   *  (bascule : l'ancien contenu reste, comme sur le vrai OPFS) ;
   *  `ouvrir` = `getFileHandle`/`getDirectoryHandle` ; `supprimer` =
   *  `removeEntry`. */
  op: "lire" | "ecrire" | "fermer" | "ouvrir" | "supprimer";
  chemin: string;
  /** Nom de la `DOMException` levée. Défaut : `NotAllowedError` — une panne
   *  qui n'est PAS une absence, ce qui est justement ce qu'on veut éprouver. */
  nom?: string;
  /** Nombre de déclenchements. Défaut : illimité. */
  fois?: number;
}

class Fichier {
  octets: Uint8Array = new Uint8Array();
}

type Entree = Fichier | Dossier;
class Dossier {
  entrees = new Map<string, Entree>();
}

/** Le disque simulé, et les assertions qu'on écrit dessus. */
export interface Disque {
  /** Pose un contenu initial, dossiers créés au besoin. */
  poser(chemin: string, contenu: string | Uint8Array): void;
  /** Contenu texte, ou `null` si le fichier n'existe pas. */
  lire(chemin: string): string | null;
  existe(chemin: string): boolean;
  /** Noms triés des entrées d'un dossier (`""` = racine). */
  lister(chemin: string): string[];
  /** Injecte une panne. */
  casser(panne: Panne): void;
  /** Retire toutes les pannes — pour observer l'état après l'incident. */
  reparer(): void;
  /** Rend `navigator` à son état d'avant. À appeler en fin de test. */
  demonter(): void;
}

function echec(nom: string, chemin: string): DOMException {
  return new DOMException(`OPFS simulé : ${nom} sur « ${chemin} »`, nom);
}

/**
 * Monte un OPFS simulé sur `navigator.storage.getDirectory()`.
 *
 * `navigator` est un accesseur CONFIGURABLE de `globalThis` en Node : on le
 * remplace le temps du test, et `demonter()` le rend. Aucun test ne doit
 * laisser le global modifié derrière lui — un stockage fantôme ferait passer
 * ou échouer les suivants pour une raison invisible.
 */
export function monterOpfs(): Disque {
  const racine = new Dossier();
  const pannes: Panne[] = [];

  const declencher = (op: Panne["op"], chemin: string): void => {
    const i = pannes.findIndex((p) => p.op === op && p.chemin === chemin);
    if (i < 0) return;
    const p = pannes[i]!;
    if (p.fois !== undefined) {
      if (p.fois <= 0) return;
      p.fois--;
      if (p.fois === 0) pannes.splice(i, 1);
    }
    throw echec(p.nom ?? "NotAllowedError", chemin);
  };

  const joindre = (base: string, nom: string) => (base ? `${base}/${nom}` : nom);

  /** Résout un chemin sans jamais créer : `null` si une marche manque. */
  const resoudre = (chemin: string): Entree | null => {
    let courant: Entree = racine;
    for (const pas of chemin.split("/").filter(Boolean)) {
      if (!(courant instanceof Dossier)) return null;
      const suivant = courant.entrees.get(pas);
      if (!suivant) return null;
      courant = suivant;
    }
    return courant;
  };

  const poigneeFichier = (fichier: Fichier, nom: string, chemin: string) => ({
    kind: "file" as const,
    name: nom,
    async getFile() {
      declencher("lire", chemin);
      const octets = fichier.octets;
      return {
        size: octets.length,
        async text() {
          return new TextDecoder().decode(octets);
        },
        async arrayBuffer() {
          return octets.buffer.slice(octets.byteOffset, octets.byteOffset + octets.byteLength);
        },
      };
    },
    async createWritable() {
      const morceaux: Uint8Array[] = [];
      return {
        async write(donnee: unknown) {
          declencher("ecrire", chemin);
          morceaux.push(
            typeof donnee === "string"
              ? new TextEncoder().encode(donnee)
              : donnee instanceof Uint8Array
                ? donnee
                : new Uint8Array(donnee as ArrayBuffer),
          );
        },
        async close() {
          // La bascule n'a lieu qu'ICI : un `close` en échec laisse le contenu
          // PRÉCÉDENT intact, comme le swap atomique du vrai OPFS.
          declencher("fermer", chemin);
          const total = morceaux.reduce((n, m) => n + m.length, 0);
          const assemble = new Uint8Array(total);
          let i = 0;
          for (const m of morceaux) {
            assemble.set(m, i);
            i += m.length;
          }
          fichier.octets = assemble;
        },
      };
    },
  });

  const poigneeDossier = (dossier: Dossier, nom: string, chemin: string): Record<string, unknown> => ({
    kind: "directory" as const,
    name: nom,
    async getFileHandle(n: string, options?: { create?: boolean }) {
      const sous = joindre(chemin, n);
      declencher("ouvrir", sous);
      let e = dossier.entrees.get(n);
      if (!e) {
        if (!options?.create) throw echec("NotFoundError", sous);
        e = new Fichier();
        dossier.entrees.set(n, e);
      }
      if (!(e instanceof Fichier)) throw echec("TypeMismatchError", sous);
      return poigneeFichier(e, n, sous);
    },
    async getDirectoryHandle(n: string, options?: { create?: boolean }) {
      const sous = joindre(chemin, n);
      declencher("ouvrir", sous);
      let e = dossier.entrees.get(n);
      if (!e) {
        if (!options?.create) throw echec("NotFoundError", sous);
        e = new Dossier();
        dossier.entrees.set(n, e);
      }
      if (!(e instanceof Dossier)) throw echec("TypeMismatchError", sous);
      return poigneeDossier(e, n, sous);
    },
    async removeEntry(n: string) {
      const sous = joindre(chemin, n);
      declencher("supprimer", sous);
      if (!dossier.entrees.delete(n)) throw echec("NotFoundError", sous);
    },
    async *[Symbol.asyncIterator]() {
      for (const [n, e] of [...dossier.entrees].sort(([a], [b]) => (a < b ? -1 : 1))) {
        yield [n, e instanceof Fichier ? poigneeFichier(e, n, joindre(chemin, n)) : poigneeDossier(e, n, joindre(chemin, n))];
      }
    },
  });

  const precedent = Object.getOwnPropertyDescriptor(globalThis, "navigator");
  Object.defineProperty(globalThis, "navigator", {
    configurable: true,
    value: {
      storage: {
        async getDirectory() {
          return poigneeDossier(racine, "", "");
        },
      },
    },
  });

  return {
    poser(chemin, contenu) {
      const pas = chemin.split("/").filter(Boolean);
      const nom = pas.pop()!;
      let dossier = racine;
      for (const p of pas) {
        let e = dossier.entrees.get(p);
        if (!(e instanceof Dossier)) {
          e = new Dossier();
          dossier.entrees.set(p, e);
        }
        dossier = e;
      }
      const f = new Fichier();
      f.octets = typeof contenu === "string" ? new TextEncoder().encode(contenu) : contenu;
      dossier.entrees.set(nom, f);
    },
    lire(chemin) {
      const e = resoudre(chemin);
      return e instanceof Fichier ? new TextDecoder().decode(e.octets) : null;
    },
    existe(chemin) {
      return resoudre(chemin) !== null;
    },
    lister(chemin) {
      const e = resoudre(chemin);
      return e instanceof Dossier ? [...e.entrees.keys()].sort() : [];
    },
    casser(panne) {
      pannes.push({ ...panne });
    },
    reparer() {
      pannes.length = 0;
    },
    demonter() {
      if (precedent) Object.defineProperty(globalThis, "navigator", precedent);
      else delete (globalThis as { navigator?: unknown }).navigator;
    },
  };
}
