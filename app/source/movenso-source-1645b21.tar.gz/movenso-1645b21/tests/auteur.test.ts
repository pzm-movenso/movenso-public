/**
 * Contenu d'AUTEUR (D-420) — le pratiquant rédige la présentation de SA
 * technique. Trois garanties se tiennent ensemble :
 *   1. la dérivation `presentationDe` inclut l'auteur (donc l'écran l'édite) ;
 *   2. à l'export, « auteur » est normalisé en `referentiel` sourcé — et REFUSÉ
 *      sans identité (publier son contenu exige de se nommer) ;
 *   3. à l'import, un `.movpack` ne peut PAS porter « auteur » (frontière).
 */

import { test } from "node:test";
import assert from "node:assert/strict";
import { presentationDe } from "../src/domaine/modele.ts";
import { extrairePackTechnique } from "../src/echange/extraction-pack.ts";
import { exporterMovpack, lireMovpack } from "../src/echange/movpack.ts";
import { ErreurMovpack } from "../src/echange/movpack-contrat.ts";
import { bibliotheque, contribution, disciplineJudo, technique } from "./aide.ts";
import { ecrirePresentationAuteur } from "../src/app/services/edition-fiche.ts";
import type { MovensoApp } from "../src/app/racine.ts";
import type { Bibliotheque } from "../src/domaine/modele.ts";

test("presentationDe : une contribution d'auteur EST la présentation quand aucune source n'existe", () => {
  const judo = disciplineJudo();
  const t = technique(judo.id);
  const b = bibliotheque({
    disciplines: [judo],
    techniques: [t],
    contributions: [contribution(t.id, { provenance: "auteur", attribution: "Moi", description: "Mon geste" })],
  });
  assert.equal(presentationDe(b, t.id)?.description, "Mon geste");
});

test("presentationDe : le contenu sourcé prime sur l'auteur ; le carnet personnel n'est jamais présentation", () => {
  const judo = disciplineJudo();
  const t = technique(judo.id);
  const source = contribution(t.id, { provenance: "referentiel", attribution: "Kodokan", description: "Source" });
  const mien = contribution(t.id, { provenance: "auteur", attribution: "Moi", description: "Moi" });
  const note = contribution(t.id, { provenance: "personnel", description: "Note privée" });
  const b = bibliotheque({ disciplines: [judo], techniques: [t], contributions: [note, mien, source] });
  assert.equal(presentationDe(b, t.id)?.provenance, "referentiel");

  const b2 = bibliotheque({ disciplines: [judo], techniques: [t], contributions: [note] });
  assert.equal(presentationDe(b2, t.id), undefined, "une note personnelle ne fait pas une présentation");
});

test("export : une contribution d'auteur signée part comme referentiel sourcé (jamais 'auteur' dans le pack)", () => {
  const judo = disciplineJudo();
  const t = technique(judo.id);
  const b = bibliotheque({
    disciplines: [judo],
    techniques: [t],
    contributions: [contribution(t.id, { provenance: "auteur", attribution: "Alice", description: "Mon geste" })],
  });
  const { extrait } = extrairePackTechnique(b, t.id);
  const c = extrait.contributions.find((x) => x.description === "Mon geste")!;
  assert.equal(c.provenance, "referentiel");
  assert.equal(c.attribution, "Alice");
  assert.ok(!extrait.contributions.some((x) => x.provenance === "auteur"), "aucune provenance locale ne voyage");
});

test("export : sans identité, publier son propre contenu est REFUSÉ ; le pseudo par défaut débloque", () => {
  const judo = disciplineJudo();
  const t = technique(judo.id);
  const b = bibliotheque({
    disciplines: [judo],
    techniques: [t],
    contributions: [contribution(t.id, { provenance: "auteur", description: "Sans nom" })],
  });
  assert.throws(() => extrairePackTechnique(b, t.id), ErreurMovpack, "sans attribution ni auteur par défaut → refus");
  const { extrait } = extrairePackTechnique(b, t.id, "Bob");
  assert.equal(extrait.contributions.find((x) => x.description === "Sans nom")!.attribution, "Bob");
});

test("import : un .movpack ne peut PAS porter la provenance locale 'auteur' (frontière hostile)", async () => {
  const judo = disciplineJudo();
  const t = technique(judo.id);
  // Conteneur FORGÉ : on emballe directement une biblio qui porte « auteur »
  // (l'app ne le fait jamais — elle normalise en amont) pour prouver le refus.
  const b = bibliotheque({
    disciplines: [judo],
    techniques: [t],
    contributions: [contribution(t.id, { provenance: "auteur", attribution: "Alice", description: "Forgé" })],
  });
  const octets = await exporterMovpack(b, { id: "x", nom: "X", portee: "complet" }, new Map());
  await assert.rejects(() => lireMovpack(octets), ErreurMovpack, "un pack portant 'auteur' est refusé à la lecture");
});

/* ---------- l'écriture de la contribution d'auteur dit son échec (fusion D-420 × D-417) ----------
   La garde des écritures (D-417) est née en parallèle de D-420 : `ecrirePresentationAuteur`
   est appelée en `void` depuis la fiche, donc une panne de `persister` doit être DITE et
   ne laisser AUCUNE contribution fantôme en mémoire — sinon le prochain geste réussi
   persisterait un contenu que l'utilisateur croit perdu, ou l'inverse. */

function fauxAppAuteur(b: Bibliotheque, panne: boolean) {
  const toasts: string[] = [];
  const app = {
    bibliotheque: b,
    preferences: { pseudo: "Moi" },
    garde: () => true, // pas de PIN : ce chapitre porte sur l'écriture
    afficherToast: (texte: string) => toasts.push(texte),
    persister: async () => {
      if (panne) throw new Error("Disque plein");
    },
  } as unknown as MovensoApp;
  return { app, toasts };
}

test("ecrirePresentationAuteur : une panne d'écriture est DITE et ne laisse aucune contribution en mémoire", async () => {
  const judo = disciplineJudo();
  const t = technique(judo.id);
  const b = bibliotheque({ disciplines: [judo], techniques: [t], contributions: [] });
  const { app, toasts } = fauxAppAuteur(b, true);
  await ecrirePresentationAuteur(app, t.id, { description: "Mon geste" });
  assert.equal(b.contributions.length, 0, "le geste refusé ne laisse pas de trace en mémoire");
  assert.deepEqual(toasts, ["Disque plein"], "la panne est dite, jamais un ✓ silencieux");
});

test("ecrirePresentationAuteur : l'écriture qui réussit crée bien la contribution d'auteur signée", async () => {
  const judo = disciplineJudo();
  const t = technique(judo.id);
  const b = bibliotheque({ disciplines: [judo], techniques: [t], contributions: [] });
  const { app, toasts } = fauxAppAuteur(b, false);
  await ecrirePresentationAuteur(app, t.id, { description: "Mon geste" });
  assert.equal(b.contributions.length, 1);
  assert.equal(b.contributions[0]!.provenance, "auteur");
  assert.equal(b.contributions[0]!.attribution, "Moi");
  assert.deepEqual(toasts, []);
});
