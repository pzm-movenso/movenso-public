/**
 * CE QUE LA CORBEILLE FAIT QUAND L'ÉCRITURE ÉCHOUE (verdict checker, D-416 ④).
 *
 * Le verdict précédent (D-415) a corrigé trois écritures qui ne disaient pas
 * leur échec — `restaurerTechnique`, `supprimerDefinitivement`,
 * `viderCorbeille` — et les a corrigées **sans un seul test**. Or `CLAUDE.md`
 * est explicite : un correctif se démontre dans les DEUX sens, mesurés. Retirer
 * le rollback ne rougissait alors nulle part, et la garde de `verifier:sources`
 * ne mesurait que la présence du mot `catch`.
 *
 * Ce chapitre tient donc les trois invariants du geste destructif :
 *  - une panne d'écriture est DITE (message, jamais un ✓ mensonger) ;
 *  - la mémoire ne garde AUCUNE trace du geste refusé — sinon le prochain
 *    geste réussi persisterait un état à demi appliqué ;
 *  - le geste qui réussit, lui, applique bien tout ce qu'il promet.
 *
 * Le faux `app` n'imite pas Lit : il porte exactement la surface que ces trois
 * fonctions consomment. Fabriquer plus serait fabriquer un chemin que le
 * produit n'emprunte pas (D-231/D-251).
 */

import test from "node:test";
import assert from "node:assert/strict";
import { restaurerTechnique, supprimerDefinitivement, viderCorbeille } from "../src/app/services/edition-graphe.ts";
import type { MovensoApp } from "../src/app/racine.ts";
import type { Bibliotheque, EntreeCorbeille } from "../src/domaine/modele.ts";
import { validerBibliotheque } from "../src/domaine/validation.ts";
import { bibliotheque, technique, contribution } from "./aide.ts";

/** Une bibliothèque dont UNE fiche est à la corbeille, et dont une VOISINE
 *  pointe vers elle : c'est ce lien entrant que la purge doit couper — et
 *  qu'un rollback naïf ne saurait pas remettre. */
function avecCorbeille() {
  const b = bibliotheque();
  const disciplineId = b.disciplines[0]!.id;
  const jetee = technique(disciplineId, { nom: "Jetée" });
  const voisine = technique(disciplineId, { nom: "Voisine" });
  voisine.relations = [{ type: "similaire", cibleId: jetee.id }];
  const entree: EntreeCorbeille = {
    supprimeeLe: new Date(0).toISOString(),
    technique: jetee,
    contributions: [contribution(jetee.id, { provenance: "personnel" })],
    etaitFavori: true,
  };
  return { ...b, techniques: [...b.techniques, voisine], corbeille: [entree] } as Bibliotheque;
}

interface Journal { toasts: { texte: string; niveau: string | undefined }[]; ecrit: Bibliotheque | null }

/** Faux `app` : `persister` réussit ou lève, selon `panne`. */
function fauxApp(b: Bibliotheque, panne: "aucune" | "persister" | "snapshot"): { app: MovensoApp; journal: Journal } {
  const journal: Journal = { toasts: [], ecrit: null };
  const app = {
    bibliotheque: b,
    garde: () => true, // pas de PIN : ce chapitre porte sur l'écriture
    afficherToast: (texte: string, niveau?: string) => journal.toasts.push({ texte, niveau }),
    stockage: {
      snapshot: async () => {
        if (panne === "snapshot") throw new Error("Snapshot impossible");
      },
    },
    persister: async (suivant: Bibliotheque) => {
      if (panne === "persister") throw new Error("Espace insuffisant");
      validerBibliotheque(suivant); // ce qu'on prétend écrire doit être valide
      journal.ecrit = suivant;
      app.bibliotheque = suivant;
    },
  };
  return { app: app as unknown as MovensoApp, journal };
}

const liensVers = (b: Bibliotheque, id: string) =>
  b.techniques.flatMap((t) => t.relations.filter((r) => r.cibleId === id)).length;

/* ---------- restaurer ---------- */

test("restaurer : une panne d'écriture est DITE, et la mémoire ne garde rien du geste", async () => {
  const b = avecCorbeille();
  const id = b.corbeille![0]!.technique.id;
  const { app, journal } = fauxApp(b, "persister");

  await restaurerTechnique(app, id);

  assert.match(journal.toasts.at(-1)?.texte ?? "", /Espace insuffisant/, "l'échec se dit");
  assert.equal(journal.toasts.at(-1)?.niveau, "alerte");
  assert.equal(b.corbeille!.length, 1, "la fiche est TOUJOURS à la corbeille");
  assert.equal(b.techniques.filter((t) => t.id === id).length, 0, "et pas dans les techniques");
  assert.deepEqual(b.favoris, [], "ni dans les favoris");
});

test("restaurer : quand l'écriture réussit, tout est appliqué", async () => {
  const b = avecCorbeille();
  const id = b.corbeille![0]!.technique.id;
  const { app, journal } = fauxApp(b, "aucune");

  await restaurerTechnique(app, id);

  assert.match(journal.toasts.at(-1)?.texte ?? "", /restaurée/);
  assert.equal(b.corbeille!.length, 0);
  assert.equal(b.techniques.filter((t) => t.id === id).length, 1);
  assert.deepEqual(b.favoris, [id], "le favori d'avant la suppression revient");
});

/* ---------- purger ---------- */

test("supprimer définitivement : une panne laisse la corbeille ET les liens entrants intacts", async () => {
  const b = avecCorbeille();
  const id = b.corbeille![0]!.technique.id;
  const { app, journal } = fauxApp(b, "persister");

  await supprimerDefinitivement(app, id);

  assert.match(journal.toasts.at(-1)?.texte ?? "", /Espace insuffisant|refusée/);
  assert.equal(b.corbeille!.length, 1, "la fiche est toujours à la corbeille — on a dit « refusée »");
  assert.equal(liensVers(b, id), 1, "et le lien entrant de la voisine n'a PAS été coupé");
  assert.equal(b.contributions.filter((c) => c.techniqueId === null).length, 0, "aucune note détachée");
});

test("supprimer définitivement : une panne de SNAPSHOT refuse la purge (pas de destruction sans filet)", async () => {
  const b = avecCorbeille();
  const id = b.corbeille![0]!.technique.id;
  const { app, journal } = fauxApp(b, "snapshot");

  await supprimerDefinitivement(app, id);

  assert.match(journal.toasts.at(-1)?.texte ?? "", /Snapshot impossible/);
  assert.equal(b.corbeille!.length, 1);
  assert.equal(liensVers(b, id), 1);
});

test("supprimer définitivement : la purge réussie coupe le lien entrant et détache la note", async () => {
  const b = avecCorbeille();
  const id = b.corbeille![0]!.technique.id;
  const { app, journal } = fauxApp(b, "aucune");

  await supprimerDefinitivement(app, id);

  assert.match(journal.toasts.at(-1)?.texte ?? "", /définitivement/);
  const ecrit = journal.ecrit!;
  assert.equal(ecrit.corbeille!.length, 0);
  assert.equal(liensVers(ecrit, id), 0, "les liens entrants sont nettoyés (la cascade D-081)");
  assert.equal(ecrit.contributions.filter((c) => c.techniqueId === null).length, 1, "la note personnelle revient « à rattacher »");
});

test("vider la corbeille : une panne ne vide RIEN en mémoire", async () => {
  const b = avecCorbeille();
  const id = b.corbeille![0]!.technique.id;
  const { app, journal } = fauxApp(b, "persister");

  await viderCorbeille(app);

  assert.match(journal.toasts.at(-1)?.texte ?? "", /Espace insuffisant|refusé/);
  assert.equal(b.corbeille!.length, 1, "la corbeille n'est pas vidée après un « Vidage refusé »");
  assert.equal(liensVers(b, id), 1);
});

test("vider la corbeille : le vidage réussi applique la cascade", async () => {
  const b = avecCorbeille();
  const { app, journal } = fauxApp(b, "aucune");
  await viderCorbeille(app);
  assert.match(journal.toasts.at(-1)?.texte ?? "", /vidée/);
  assert.equal(journal.ecrit!.corbeille!.length, 0);
});
