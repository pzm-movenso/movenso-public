/**
 * STOCKAGE — CE QU'IL FAIT QUAND LE SUPPORT REFUSE (audit externe 2026-08-21).
 *
 * La dernière frontière de Movenso n'est plus l'import hostile : c'est le
 * stockage local lui-même. Le produit promet qu'une donnée écrite reste
 * écrite ; la seule façon de le démontrer est de faire échouer le support et
 * de regarder ce que le code en conclut.
 *
 * L'invariant que ce chapitre tient, et qui n'était tenu par AUCUN test :
 * **une panne matérielle ou navigateur n'est jamais l'autorisation d'effacer.**
 *
 * Ce que le harnais ne simule PAS : les vidéos en flux (`stream()`/`pipeTo`).
 * Leur promotion a ses épreuves navigateur — fabriquer ici un chemin que le
 * produit n'emprunte pas ne prouverait rien (leçon D-231/D-251).
 */

import test from "node:test";
import assert from "node:assert/strict";
import { StockageOpfs } from "../src/stockage/opfs.ts";
import { monterOpfs, type Disque } from "./harnais-opfs.ts";
import { bibliotheque, technique } from "./aide.ts";
import { sha256Hex } from "../src/domaine/sha256.ts";

/** Monte un disque, joue le corps, démonte quoi qu'il arrive : un `navigator`
 *  laissé en place ferait passer ou échouer les tests suivants pour une raison
 *  invisible. */
async function surDisque(corps: (d: Disque, s: StockageOpfs) => Promise<void>): Promise<void> {
  const disque = monterOpfs();
  try {
    await corps(disque, new StockageOpfs());
  } finally {
    disque.demonter();
  }
}

const ETAT = () => JSON.stringify(bibliotheque());

/* ---------- lire : « je n'ai pas pu » n'est pas « il n'y a rien » ---------- */

test("une VRAIE absence reste une première installation", async () => {
  await surDisque(async (_d, stockage) => {
    assert.equal(await stockage.charger(), null, "aucun fichier : null, et c'est le seul cas légitime");
  });
});

test("une panne de lecture de l'état REFUSE de démarrer au lieu de conclure « aucune donnée »", async () => {
  await surDisque(async (disque, stockage) => {
    const avant = ETAT();
    disque.poser("bibliotheque.json", avant);
    disque.casser({ op: "lire", chemin: "bibliotheque.json", nom: "NotAllowedError" });

    await assert.rejects(
      () => stockage.charger(),
      /NotAllowedError/,
      "la panne doit remonter : c'est elle qui déclenche l'écran « Movenso n'a pas pu lire ses données »",
    );
    disque.reparer();
    assert.equal(disque.lire("bibliotheque.json"), avant, "et le disque n'a pas bougé d'un octet");
  });
});

test("chaque panne de lecture est refusée, pas seulement celle qu'on a en tête", async () => {
  for (const nom of ["NotAllowedError", "UnknownError", "AbortError", "SecurityError", "InvalidStateError"]) {
    await surDisque(async (disque, stockage) => {
      disque.poser("bibliotheque.json", ETAT());
      disque.casser({ op: "lire", chemin: "bibliotheque.json", nom });
      await assert.rejects(() => stockage.charger(), new RegExp(nom), `${nom} n'est pas une absence`);
    });
  }
});

test("les PRÉFÉRENCES, elles, restent tolérantes — un thème illisible vaut défauts", async () => {
  // Frontière assumée : ce qui se reconstruit sans perte se lit sans exiger.
  // Refuser de démarrer parce qu'un réglage d'appareil est illisible coûterait
  // plus que le réglage lui-même.
  await surDisque(async (disque, stockage) => {
    disque.poser("preferences.json", JSON.stringify({ version: 1, demarrage: { mode: "compositions" } }));
    disque.casser({ op: "lire", chemin: "preferences.json", nom: "NotAllowedError" });
    const p = await stockage.chargerPreferences();
    assert.equal(p.demarrage.mode, "bibliotheque", "défauts, sans exception");
  });
});

/* ---------- snapshot : la protection ne se perd pas en silence ---------- */

test("une panne de lecture au snapshot REFUSE la mutation au lieu de muter sans point de retour", async () => {
  await surDisque(async (disque, stockage) => {
    const avant = ETAT();
    disque.poser("bibliotheque.json", avant);
    // La première sauvegarde de la session prend un snapshot (contrat §4).
    // S'il ne peut pas lire l'état courant, il n'y a PAS de point de retour :
    // écrire quand même reviendrait à retirer la protection en silence.
    disque.casser({ op: "lire", chemin: "bibliotheque.json", nom: "NotAllowedError" });
    const suivant = bibliotheque();
    suivant.favoris = [suivant.techniques[0]!.id]; // une mutation ordinaire, et valide

    await assert.rejects(() => stockage.sauvegarder(suivant), /NotAllowedError/);
    disque.reparer();
    assert.equal(disque.lire("bibliotheque.json"), avant, "l'état courant est intact");
    assert.deepEqual(disque.lister("sauvegardes"), [], "et aucun snapshot fantôme n'a été créé");
  });
});

test("la première ouverture, elle, n'a rien à protéger et écrit normalement", async () => {
  await surDisque(async (disque, stockage) => {
    await stockage.sauvegarder(bibliotheque());
    assert.ok(disque.existe("bibliotheque.json"), "l'état est écrit");
    assert.deepEqual(disque.lister("sauvegardes"), [], "aucun snapshot : il n'y avait rien à sauver");
    assert.ok(!disque.existe("bibliotheque.json.tmp"), "le temporaire de bascule est retiré");
  });
});

/* ---------- migrer : jamais un inventaire sans ses octets ---------- */

/** Une bibliothèque en schéma 5 : les couvertures sont des data-URL base64,
 *  DANS le JSON. La migration 5 → 6 les sort et les remplace par des
 *  références de fichiers (D-269) — c'est ce basculement qu'on éprouve. */
function enSchema5(): { texte: string; ids: string[] } {
  const b = bibliotheque();
  const judo = b.disciplines[0]!;
  const deux = [b.techniques[0]!, technique(judo.id, { nom: "Deuxième" })];
  const octetsDe = (n: string) => new TextEncoder().encode(`image-${n}`);
  const enData = (n: string) => `data:image/jpeg;base64,${Buffer.from(`image-${n}`).toString("base64")}`;
  const techniques = deux.map((t, i) => ({ ...t, couverture: { type: "image" as const, dataUrl: enData(String(i)) } }));
  const texte = JSON.stringify({ ...b, versionSchema: 5, disciplines: [judo], techniques });
  return { texte, ids: [sha256Hex(octetsDe("0")), sha256Hex(octetsDe("1"))] };
}

test("la migration 5 → 6 écrit les images PUIS bascule — chemin nominal", async () => {
  await surDisque(async (disque, stockage) => {
    const { texte, ids } = enSchema5();
    disque.poser("bibliotheque.json", texte);

    const b = await stockage.charger();
    assert.equal(b?.versionSchema, 6);
    assert.deepEqual(disque.lister("images"), [...ids].sort(), "les deux fichiers sont posés");
    assert.equal(JSON.parse(disque.lire("bibliotheque.json")!).versionSchema, 6, "et l'inventaire a basculé");
  });
});

test("une seule image non écrite ANNULE la bascule — le disque reste en schéma 5", async () => {
  await surDisque(async (disque, stockage) => {
    const { texte, ids } = enSchema5();
    disque.poser("bibliotheque.json", texte);
    // Espace insuffisant sur la SECONDE image : la première est déjà posée.
    // Si le schéma 6 se persistait quand même, le base64 de la seconde
    // aurait disparu du JSON sans qu'aucun fichier ne le remplace — vignette
    // perdue, définitivement.
    disque.casser({ op: "fermer", chemin: `images/${ids[1]}`, nom: "QuotaExceededError" });

    const b = await stockage.charger();
    assert.equal(b?.versionSchema, 6, "l'application s'ouvre quand même, sur l'état migré EN MÉMOIRE");

    disque.reparer();
    const surDisqueApres = JSON.parse(disque.lire("bibliotheque.json")!);
    assert.equal(surDisqueApres.versionSchema, 5, "le disque n'a PAS basculé");
    assert.equal(
      surDisqueApres.techniques[1].couverture.type,
      "image",
      "et le base64 d'origine est toujours là : la prochaine ouverture réessaiera",
    );
  });
});

test("les images REÇUES d'un conteneur, elles, restent dégradables", async () => {
  // Régime opposé, et c'est voulu (D-269) : à l'import, une vignette qui ne
  // s'écrit pas ne bloque rien — l'appelant décide sur le NOMBRE d'échecs.
  // Aucun base64 ne disparaît sur ce chemin : il n'y en a pas.
  await surDisque(async (disque, stockage) => {
    const octets = new TextEncoder().encode("recue");
    const id = sha256Hex(octets);
    disque.casser({ op: "fermer", chemin: `images/${id}`, nom: "QuotaExceededError" });
    assert.equal(await stockage.poserImagesRecues([{ id, mime: "image/jpeg", taille: octets.length, octets }]), 1,
      "l'échec est RENDU, pas levé — c'est l'appelant qui arbitre");
  });
});

/* ---------- la file d'écriture : un payload FIGÉ ---------- */

test("ce qui est écrit est ce qui a été VALIDÉ, même si l'objet change entre-temps", async () => {
  await surDisque(async (disque, stockage) => {
    // `bibliotheque` est un objet MUTABLE que l'application modifie en place.
    // La sauvegarde attend la précédente avant de toucher le temporaire : si la
    // sérialisation avait lieu APRÈS cette attente, elle écrirait un état que
    // personne n'a validé — celui d'après la mutation.
    const b = bibliotheque();
    const enVol = stockage.sauvegarder(b);
    b.favoris = [b.techniques[0]!.id]; // mutation pendant que l'écriture est en file
    await enVol;

    const ecrit = JSON.parse(disque.lire("bibliotheque.json")!);
    assert.deepEqual(ecrit.favoris, [], "l'état écrit est celui de l'appel, pas celui d'après");
  });
});

test("et la mutation suivante s'écrit bien, elle — la file n'avale rien", async () => {
  await surDisque(async (disque, stockage) => {
    const b = bibliotheque();
    await stockage.sauvegarder(b);
    b.favoris = [b.techniques[0]!.id];
    await stockage.sauvegarder(b);
    assert.deepEqual(JSON.parse(disque.lire("bibliotheque.json")!).favoris, [b.techniques[0]!.id]);
  });
});

/* ---------- le NOM d'une image ne prouve pas qu'elle est là ---------- */

test("une écriture d'image interrompue ne fait pas passer la vignette pour posée à l'ouverture SUIVANTE", async () => {
  // Verdict checker sur D-408 : le correctif tenait à la PREMIÈRE ouverture,
  // et c'est la SECONDE qui perdait l'image. `getFileHandle(create:true)` crée
  // l'entrée AVANT d'écrire : un `close()` en échec laisse donc un fichier de
  // 0 octet sous l'empreinte. La présence n'étant testée que par le NOM, la
  // reprise sautait cette image, ne rendait aucun échec, et persistait le
  // schéma 6 — le base64 d'origine disparaissait pour de bon.
  await surDisque(async (disque, stockage) => {
    const { texte, ids } = enSchema5();
    disque.poser("bibliotheque.json", texte);
    disque.casser({ op: "fermer", chemin: `images/${ids[1]}`, nom: "QuotaExceededError", fois: 1 });

    await stockage.charger(); // ouverture 1 : la panne se produit
    assert.equal(JSON.parse(disque.lire("bibliotheque.json")!).versionSchema, 5, "ouverture 1 : le disque reste en schéma 5");

    // La panne a disparu (place libérée, permission rendue). Ouverture 2, session
    // neuve. `fois: 1` garantit que la seconde tentative RÉUSSIT : l'épreuve est
    // donc déterministe et n'a pas de branche « acceptable ». La première version
    // en avait une (`assert.ok(true)`) et elle était MORTE — remplacée par
    // `assert.fail`, le chapitre restait vert (relecture D-416 ⑧). Une branche
    // qu'on ne peut pas atteindre absoudrait n'importe quelle régression future.
    await new StockageOpfs().charger();
    const apres = JSON.parse(disque.lire("bibliotheque.json")!);
    assert.equal(apres.versionSchema, 6, "la seconde ouverture, elle, réussit à migrer");
    assert.equal(disque.lire(`images/${ids[1]}`), "image-1",
      "et le fichier de l'image porte ses octets — jamais 0 (verdict checker sur D-408)");
  });
});

test("un fichier d'image vide est réparé, pas déclaré présent", async () => {
  await surDisque(async (disque, stockage) => {
    const octets = new TextEncoder().encode("vraie-image");
    const id = sha256Hex(octets);
    disque.poser(`images/${id}`, new Uint8Array()); // résidu d'écriture interrompue
    assert.equal(await stockage.poserImagesRecues([{ id, mime: "image/jpeg", taille: octets.length, octets }]), 0,
      "aucun échec : l'image s'écrit");
    assert.equal(disque.lire(`images/${id}`), "vraie-image", "et le fichier vide a été REMPLACÉ, pas sauté");
  });
});

/* ---------- une panne n'efface JAMAIS une image valide ---------- */

/** Une image dont la TAILLE DÉCLARÉE est fausse — ce que peut contenir le
 *  `bibliotheque.json` d'un conteneur reçu, où rien ne la confronte aux octets. */
function imageAuTailleMenteuse() {
  const octets = new TextEncoder().encode("contenu-authentique");
  return { id: sha256Hex(octets), mime: "image/jpeg", taille: 999, octets };
}

test("une taille DÉCLARÉE fausse ne fait pas réécrire une image déjà posée (idempotence)", async () => {
  await surDisque(async (disque, stockage) => {
    const img = imageAuTailleMenteuse();
    disque.poser(`images/${img.id}`, img.octets); // déjà posée, et VALIDE
    disque.casser({ op: "ecrire", chemin: `images/${img.id}`, nom: "QuotaExceededError" });
    // Si la présence se juge sur `taille`, on réécrit — et on échoue.
    assert.equal(await stockage.poserImagesRecues([img]), 0,
      "l'image est là et authentique : rien à écrire, donc aucun échec (JSDoc « idempotent »)");
    assert.equal(disque.lire(`images/${img.id}`), "contenu-authentique", "et le fichier est intact");
  });
});

test("une panne pendant une réécriture inutile ne SUPPRIME pas le fichier valide", async () => {
  await surDisque(async (disque, stockage) => {
    const img = imageAuTailleMenteuse();
    disque.poser(`images/${img.id}`, img.octets);
    disque.casser({ op: "fermer", chemin: `images/${img.id}`, nom: "QuotaExceededError" });
    await stockage.poserImagesRecues([img]);
    // Les images sont dédupliquées par empreinte : ce fichier peut être celui
    // de la bibliothèque personnelle de l'utilisateur, pas seulement du pack.
    assert.equal(disque.lire(`images/${img.id}`), "contenu-authentique",
      "une panne n'est jamais l'autorisation d'effacer (en-tête de ce chapitre)");
    assert.ok((await stockage.lireImage(img.id)) !== null, "et l'image reste lisible");
  });
});

test("un résidu de 0 octet, lui, est bien remplacé — la réparation reste possible", async () => {
  await surDisque(async (disque, stockage) => {
    const img = imageAuTailleMenteuse();
    disque.poser(`images/${img.id}`, new Uint8Array());
    assert.equal(await stockage.poserImagesRecues([img]), 0);
    assert.equal(disque.lire(`images/${img.id}`), "contenu-authentique");
  });
});

/* ---------- une PANNE de lecture n'est pas une absence, ici non plus ---------- */

test("un fichier valide dont le handle ne s'ouvre PAS n'est ni réécrit ni supprimé", async () => {
  // Sabotage du checker (3ᵈ tour). `tailleFichier` attrapait TOUTE erreur et
  // rendait -1, c'est-à-dire « absent » : le catch universel que D-407 existe
  // pour interdire, réintroduit par le correctif de D-416 dans une fonction que
  // cette passe venait de créer. Une seule panne suffisait : le fichier paraît
  // absent → réécriture → échec sur la même panne → `removeEntry` d'un fichier
  // VALIDE. Les images étant dédupliquées par empreinte, ce fichier peut être
  // celui de la bibliothèque personnelle de l'utilisateur.
  await surDisque(async (disque, stockage) => {
    const octets = new TextEncoder().encode("contenu-authentique");
    const id = sha256Hex(octets);
    disque.poser(`images/${id}`, octets);
    disque.casser({ op: "ouvrir", chemin: `images/${id}`, nom: "NotAllowedError" });

    const echecs = await stockage.poserImagesRecues([{ id, mime: "image/jpeg", taille: octets.length, octets }]);

    disque.reparer();
    assert.equal(disque.lire(`images/${id}`), "contenu-authentique",
      "une panne n'est JAMAIS l'autorisation d'effacer (en-tête de ce chapitre)");
    assert.equal(echecs, 1, "et l'échec est RENDU : on n'a pas pu vérifier, donc on ne prétend pas avoir posé");
  });
});

test("la même panne sur la LECTURE des octets ne détruit pas davantage", async () => {
  await surDisque(async (disque, stockage) => {
    const octets = new TextEncoder().encode("contenu-authentique");
    const id = sha256Hex(octets);
    disque.poser(`images/${id}`, octets);
    disque.casser({ op: "lire", chemin: `images/${id}`, nom: "NotAllowedError" });
    await stockage.poserImagesRecues([{ id, mime: "image/jpeg", taille: octets.length, octets }]);
    disque.reparer();
    assert.equal(disque.lire(`images/${id}`), "contenu-authentique");
  });
});

test("une VRAIE absence, elle, s'écrit toujours normalement", async () => {
  await surDisque(async (disque, stockage) => {
    const octets = new TextEncoder().encode("neuve");
    const id = sha256Hex(octets);
    assert.equal(await stockage.poserImagesRecues([{ id, mime: "image/jpeg", taille: octets.length, octets }]), 0);
    assert.equal(disque.lire(`images/${id}`), "neuve");
  });
});
